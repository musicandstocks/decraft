/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.util.ResourceLocation
 */
package com.MrVorgan.peashootersmod.entity.render;

import com.MrVorgan.peashootersmod.entity.EntityAllStarZombie;
import com.MrVorgan.peashootersmod.entity.model.ModelAllStarZombie;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderAllStarZombie
extends RenderLiving<EntityAllStarZombie> {
    public static final ResourceLocation TEXTURES = new ResourceLocation("pm:textures/entity/all_star_zombie.png");

    public RenderAllStarZombie(RenderManager manager) {
        super(manager, (ModelBase)new ModelAllStarZombie(), 0.5f);
    }

    protected ResourceLocation getEntityTexture(EntityAllStarZombie entity) {
        return TEXTURES;
    }
}

