/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.MathHelper
 */
package com.MrVorgan.peashootersmod.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class ModelVaseWeed
extends ModelBase {
    public ModelRenderer LongLeg_3;
    public ModelRenderer LongLeg_1;
    public ModelRenderer LongLeg_2;
    public ModelRenderer Stem;
    public ModelRenderer LongLeg;
    public ModelRenderer Head;
    public ModelRenderer Stem_Cover;
    public ModelRenderer LeftArm;
    public ModelRenderer LeftArm_2;
    public ModelRenderer LeftArm_3;
    public ModelRenderer LeftArm_1;
    public ModelRenderer VaseWideBottom;
    public ModelRenderer VaseShortBottom;
    public ModelRenderer Headleft;
    public ModelRenderer Headright;
    public ModelRenderer Headback;
    public ModelRenderer Top;
    public ModelRenderer VaseLidTop;

    public ModelVaseWeed() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        this.LongLeg_2 = new ModelRenderer((ModelBase)this, 0, 26);
        this.LongLeg_2.func_78793_a(1.0f, 20.0f, -3.0f);
        this.LongLeg_2.func_78790_a(0.0f, 0.0f, 0.0f, 2, 4, 2, 0.0f);
        this.Stem = new ModelRenderer((ModelBase)this, 0, 22);
        this.Stem.func_78793_a(-1.0f, 18.0f, -1.0f);
        this.Stem.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 2, 0.0f);
        this.Headback = new ModelRenderer((ModelBase)this, 23, 24);
        this.Headback.func_78793_a(-4.0f, 0.0f, 4.0f);
        this.Headback.func_78790_a(0.0f, 0.0f, 0.0f, 8, 6, 2, 0.0f);
        this.Headleft = new ModelRenderer((ModelBase)this, 16, 14);
        this.Headleft.func_78793_a(4.0f, 0.0f, -6.0f);
        this.Headleft.func_78790_a(0.0f, 0.0f, 0.0f, 2, 6, 12, 0.0f);
        this.VaseWideBottom = new ModelRenderer((ModelBase)this, 10, 15);
        this.VaseWideBottom.func_78793_a(-5.0f, 5.0f, -5.0f);
        this.VaseWideBottom.func_78790_a(0.0f, 0.0f, 0.0f, 10, 7, 10, 0.0f);
        this.LongLeg_3 = new ModelRenderer((ModelBase)this, 0, 26);
        this.LongLeg_3.func_78793_a(-3.0f, 20.0f, 1.0f);
        this.LongLeg_3.func_78790_a(0.0f, 0.0f, 0.0f, 2, 4, 2, 0.0f);
        this.VaseLidTop = new ModelRenderer((ModelBase)this, 0, 7);
        this.VaseLidTop.func_78793_a(-3.0f, -3.0f, -3.0f);
        this.VaseLidTop.func_78790_a(0.0f, 0.0f, 0.0f, 6, 1, 6, 0.0f);
        this.Head = new ModelRenderer((ModelBase)this, 32, 0);
        this.Head.func_78793_a(0.0f, 0.4f, 0.0f);
        this.Head.func_78790_a(-4.0f, -0.4f, -4.0f, 8, 6, 8, -4.4703484E-8f);
        this.LeftArm_1 = new ModelRenderer((ModelBase)this, 5, 14);
        this.LeftArm_1.func_78793_a(3.0f, 11.0f, 4.0f);
        this.LeftArm_1.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 5, 0.0f);
        this.LongLeg_1 = new ModelRenderer((ModelBase)this, 0, 26);
        this.LongLeg_1.func_78793_a(-3.0f, 20.0f, -3.0f);
        this.LongLeg_1.func_78790_a(0.0f, 0.0f, 0.0f, 2, 4, 2, 0.0f);
        this.Top = new ModelRenderer((ModelBase)this, 10, 20);
        this.Top.func_78793_a(-5.0f, -2.0f, -5.0f);
        this.Top.func_78790_a(0.0f, 0.0f, 0.0f, 10, 2, 10, 0.0f);
        this.LongLeg = new ModelRenderer((ModelBase)this, 0, 26);
        this.LongLeg.func_78793_a(1.0f, 20.0f, 1.0f);
        this.LongLeg.func_78790_a(0.0f, 0.0f, 0.0f, 2, 4, 2, 0.0f);
        this.LeftArm_3 = new ModelRenderer((ModelBase)this, 0, 0);
        this.LeftArm_3.func_78793_a(-6.0f, 10.0f, 9.0f);
        this.LeftArm_3.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 3, 0.0f);
        this.Stem_Cover = new ModelRenderer((ModelBase)this, 48, 14);
        this.Stem_Cover.func_78793_a(2.0f, 6.0f, 0.0f);
        this.Stem_Cover.func_78790_a(-4.0f, 0.0f, -2.0f, 4, 2, 4, 0.0f);
        this.VaseShortBottom = new ModelRenderer((ModelBase)this, 15, 18);
        this.VaseShortBottom.func_78793_a(-4.0f, 12.0f, -4.0f);
        this.VaseShortBottom.func_78790_a(0.0f, 0.0f, 0.0f, 8, 6, 8, 0.0f);
        this.LeftArm = new ModelRenderer((ModelBase)this, 50, 21);
        this.LeftArm.func_78793_a(-5.0f, 11.0f, 4.0f);
        this.LeftArm.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 5, 0.0f);
        this.Headright = new ModelRenderer((ModelBase)this, 16, 14);
        this.Headright.func_78793_a(-6.0f, 0.0f, -6.0f);
        this.Headright.func_78790_a(0.0f, 0.0f, 0.0f, 2, 6, 12, 0.0f);
        this.LeftArm_2 = new ModelRenderer((ModelBase)this, 14, 0);
        this.LeftArm_2.func_78793_a(4.0f, 10.0f, 9.0f);
        this.LeftArm_2.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 3, 0.0f);
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        this.LongLeg_2.func_78785_a(f5);
        this.Stem.func_78785_a(f5);
        this.Headback.func_78785_a(f5);
        this.Headleft.func_78785_a(f5);
        this.VaseWideBottom.func_78785_a(f5);
        this.LongLeg_3.func_78785_a(f5);
        this.VaseLidTop.func_78785_a(f5);
        this.Head.func_78785_a(f5);
        this.LeftArm_1.func_78785_a(f5);
        this.LongLeg_1.func_78785_a(f5);
        this.Top.func_78785_a(f5);
        this.LongLeg.func_78785_a(f5);
        this.LeftArm_3.func_78785_a(f5);
        this.Stem_Cover.func_78785_a(f5);
        this.VaseShortBottom.func_78785_a(f5);
        this.LeftArm.func_78785_a(f5);
        this.Headright.func_78785_a(f5);
        this.LeftArm_2.func_78785_a(f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }

    public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        this.LongLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
        this.LongLeg_2.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
        this.LongLeg_3.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.LongLeg_1.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
    }
}

