/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.MathHelper
 */
package com.MrVorgan.peashootersmod.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class ModelGargantuar
extends ModelBase {
    public ModelRenderer Body;
    public ModelRenderer Waist;
    public ModelRenderer LeftShoulder;
    public ModelRenderer RightShoulder;
    public ModelRenderer RightLeg;
    public ModelRenderer Head;
    public ModelRenderer LeftLeg;
    public ModelRenderer TrashCan;
    public ModelRenderer RightArm;
    public ModelRenderer LeftArm;

    public ModelGargantuar() {
        this.field_78090_t = 128;
        this.field_78089_u = 128;
        this.Body = new ModelRenderer((ModelBase)this, 0, 40);
        this.Body.func_78793_a(0.0f, -10.0f, 0.0f);
        this.Body.func_78790_a(-9.0f, -2.0f, -6.0f, 18, 14, 11, 0.0f);
        this.RightShoulder = new ModelRenderer((ModelBase)this, 64, 27);
        this.RightShoulder.func_78793_a(0.0f, -4.0f, 0.0f);
        this.RightShoulder.func_78790_a(-15.0f, -8.5f, -4.0f, 7, 10, 8, 0.0f);
        this.Waist = new ModelRenderer((ModelBase)this, 0, 70);
        this.Waist.func_78793_a(0.0f, -10.0f, 0.0f);
        this.Waist.func_78790_a(-6.5f, 11.0f, -4.0f, 13, 7, 7, 0.5f);
        this.RightArm = new ModelRenderer((ModelBase)this, 49, 93);
        this.RightArm.func_78793_a(0.0f, -10.0f, 0.0f);
        this.RightArm.func_78790_a(10.0f, 7.0f, -12.0f, 6, 6, 14, 0.0f);
        this.LeftLeg = new ModelRenderer((ModelBase)this, 60, 0);
        this.LeftLeg.field_78809_i = true;
        this.LeftLeg.func_78793_a(5.0f, 11.0f, 0.0f);
        this.LeftLeg.func_78790_a(-3.5f, -3.0f, -4.0f, 6, 16, 5, 0.0f);
        this.TrashCan = new ModelRenderer((ModelBase)this, 0, 0);
        this.TrashCan.func_78793_a(0.0f, -10.0f, 0.0f);
        this.TrashCan.func_78790_a(-4.0f, -4.0f, 4.0f, 8, 12, 8, 0.0f);
        this.Head = new ModelRenderer((ModelBase)this, 90, 0);
        this.Head.func_78793_a(0.0f, -6.0f, -6.0f);
        this.Head.func_78790_a(-4.0f, -12.0f, -5.5f, 8, 10, 8, 0.0f);
        this.LeftArm = new ModelRenderer((ModelBase)this, 5, 106);
        this.LeftArm.func_78793_a(0.0f, -8.0f, 0.0f);
        this.LeftArm.func_78790_a(-16.0f, 5.0f, -12.0f, 6, 6, 14, 0.0f);
        this.RightLeg = new ModelRenderer((ModelBase)this, 37, 0);
        this.RightLeg.func_78793_a(-4.0f, 11.0f, 0.0f);
        this.RightLeg.func_78790_a(-3.5f, -3.0f, -4.0f, 6, 16, 5, 0.0f);
        this.LeftShoulder = new ModelRenderer((ModelBase)this, 60, 58);
        this.LeftShoulder.func_78793_a(0.0f, -4.0f, 0.0f);
        this.LeftShoulder.func_78790_a(8.0f, -8.5f, -4.0f, 7, 10, 8, 0.0f);
        this.RightShoulder.func_78792_a(this.RightArm);
        this.LeftShoulder.func_78792_a(this.LeftArm);
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        this.Body.func_78785_a(f5);
        this.RightShoulder.func_78785_a(f5);
        this.Waist.func_78785_a(f5);
        this.LeftLeg.func_78785_a(f5);
        this.TrashCan.func_78785_a(f5);
        this.Head.func_78785_a(f5);
        this.RightLeg.func_78785_a(f5);
        this.LeftShoulder.func_78785_a(f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }

    public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        this.LeftLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f)) * 1.4f * limbSwingAmount;
        this.LeftShoulder.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.2f)) * 1.4f * limbSwingAmount;
        this.RightLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.RightShoulder.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.2f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.Head.field_78796_g = netHeadYaw * ((float)Math.PI / 180);
        this.Head.field_78795_f = headPitch * ((float)Math.PI / 180);
    }
}

