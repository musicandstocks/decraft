/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.MathHelper
 */
package com.MrVorgan.peashootersmod.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class ModelWeed
extends ModelBiped {
    public ModelRenderer Stem_Cover;
    public ModelRenderer LongLeg;
    public ModelRenderer LongLeg_1;
    public ModelRenderer LongLeg_2;
    public ModelRenderer Head;
    public ModelRenderer LongLeg_3;
    public ModelRenderer Head_leaf;
    public ModelRenderer Head_leaf_1;
    public ModelRenderer Head_leaf_2;
    public ModelRenderer Head_leaf_3;
    public ModelRenderer Head_leaf_4;
    public ModelRenderer Head_leaf_5;
    public ModelRenderer Head_leaf_6;
    public ModelRenderer Head_leaf_7;
    public ModelRenderer Stem;
    public ModelRenderer RoseBud;
    public ModelRenderer ArmBeggining;
    public ModelRenderer ArmBeggining_1;
    public ModelRenderer DoubleArm;
    public ModelRenderer LeftArm;
    public ModelRenderer LeftArm_1;
    public ModelRenderer LeftArm_2;
    public ModelRenderer LeftArm_3;

    public ModelWeed() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        this.ArmBeggining = new ModelRenderer((ModelBase)this, 58, 0);
        this.ArmBeggining.func_78793_a(1.0f, 13.0f, 0.0f);
        this.ArmBeggining.func_78790_a(0.0f, 0.0f, 0.0f, 1, 2, 1, 0.0f);
        this.LeftArm = new ModelRenderer((ModelBase)this, 38, 16);
        this.LeftArm.func_78793_a(-3.0f, 11.0f, 2.0f);
        this.LeftArm.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 5, 0.0f);
        this.LeftArm_2 = new ModelRenderer((ModelBase)this, 14, 0);
        this.LeftArm_2.func_78793_a(2.0f, 10.0f, 7.0f);
        this.LeftArm_2.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 3, 0.0f);
        this.Head = new ModelRenderer((ModelBase)this, 32, 0);
        this.Head.func_78793_a(0.0f, 0.4f, 0.0f);
        this.Head.func_78790_a(-4.0f, -0.4f, -4.0f, 8, 6, 8, 0.0f);
        this.LeftArm_3 = new ModelRenderer((ModelBase)this, 0, 0);
        this.LeftArm_3.func_78793_a(-4.0f, 10.0f, 7.0f);
        this.LeftArm_3.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 3, 0.0f);
        this.Head_leaf_5 = new ModelRenderer((ModelBase)this, 20, 17);
        this.Head_leaf_5.func_78793_a(-5.0f, -2.0f, -5.0f);
        this.Head_leaf_5.func_78790_a(0.0f, 0.0f, 0.0f, 3, 1, 3, 0.0f);
        this.ArmBeggining_1 = new ModelRenderer((ModelBase)this, 58, 4);
        this.ArmBeggining_1.func_78793_a(-2.0f, 13.0f, 0.0f);
        this.ArmBeggining_1.func_78790_a(0.0f, 0.0f, 0.0f, 1, 2, 1, 0.0f);
        this.RoseBud = new ModelRenderer((ModelBase)this, 20, 22);
        this.RoseBud.func_78793_a(-1.0f, -1.0f, -1.0f);
        this.RoseBud.func_78790_a(0.0f, 0.0f, 0.0f, 2, 1, 2, 0.0f);
        this.LongLeg_2 = new ModelRenderer((ModelBase)this, 24, 26);
        this.LongLeg_2.func_78793_a(1.0f, 20.0f, -3.0f);
        this.LongLeg_2.func_78790_a(0.0f, 0.0f, 0.0f, 2, 4, 2, 0.0f);
        this.Stem = new ModelRenderer((ModelBase)this, 0, 12);
        this.Stem.func_78793_a(-1.0f, 8.0f, -1.0f);
        this.Stem.func_78790_a(0.0f, 0.0f, 0.0f, 2, 12, 2, 0.0f);
        this.LeftArm_1 = new ModelRenderer((ModelBase)this, 8, 10);
        this.LeftArm_1.func_78793_a(1.0f, 11.0f, 2.0f);
        this.LeftArm_1.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 5, 0.0f);
        this.Head_leaf = new ModelRenderer((ModelBase)this, 24, 21);
        this.Head_leaf.func_78793_a(1.0f, -1.0f, 1.0f);
        this.Head_leaf.func_78790_a(0.0f, 0.0f, 0.0f, 4, 1, 4, 0.0f);
        this.Head_leaf_6 = new ModelRenderer((ModelBase)this, 28, 0);
        this.Head_leaf_6.func_78793_a(2.0f, -2.0f, -5.0f);
        this.Head_leaf_6.func_78790_a(0.0f, 0.0f, 0.0f, 3, 1, 3, 0.0f);
        this.LongLeg_1 = new ModelRenderer((ModelBase)this, 16, 26);
        this.LongLeg_1.func_78793_a(-3.0f, 20.0f, -3.0f);
        this.LongLeg_1.func_78790_a(0.0f, 0.0f, 0.0f, 2, 4, 2, 0.0f);
        this.Head_leaf_7 = new ModelRenderer((ModelBase)this, 8, 17);
        this.Head_leaf_7.func_78793_a(-5.0f, -2.0f, 2.0f);
        this.Head_leaf_7.func_78790_a(0.0f, 0.0f, 0.0f, 3, 1, 3, 0.0f);
        this.Head_leaf_4 = new ModelRenderer((ModelBase)this, 28, 4);
        this.Head_leaf_4.func_78793_a(2.0f, -2.0f, 2.0f);
        this.Head_leaf_4.func_78790_a(0.0f, 0.0f, 0.0f, 3, 1, 3, 0.0f);
        this.DoubleArm = new ModelRenderer((ModelBase)this, 54, 24);
        this.DoubleArm.func_78793_a(-2.0f, 12.0f, 1.0f);
        this.DoubleArm.func_78790_a(0.0f, 0.0f, 0.0f, 4, 2, 1, 0.0f);
        this.Head_leaf_2 = new ModelRenderer((ModelBase)this, 48, 27);
        this.Head_leaf_2.func_78793_a(0.0f, -1.0f, 0.0f);
        this.Head_leaf_2.func_78790_a(1.0f, 0.0f, -5.0f, 4, 1, 4, 0.0f);
        this.Stem_Cover = new ModelRenderer((ModelBase)this, 48, 14);
        this.Stem_Cover.func_78793_a(2.0f, 6.0f, 0.0f);
        this.Stem_Cover.func_78790_a(-4.0f, 0.0f, -2.0f, 4, 2, 4, 0.0f);
        this.Head_leaf_3 = new ModelRenderer((ModelBase)this, 32, 27);
        this.Head_leaf_3.func_78793_a(-5.0f, -1.0f, -5.0f);
        this.Head_leaf_3.func_78790_a(0.0f, 0.0f, 0.0f, 4, 1, 4, 0.0f);
        this.LongLeg = new ModelRenderer((ModelBase)this, 0, 26);
        this.LongLeg.func_78793_a(1.0f, 20.0f, 1.0f);
        this.LongLeg.func_78790_a(0.0f, 0.0f, 0.0f, 2, 4, 2, 0.0f);
        this.LongLeg_3 = new ModelRenderer((ModelBase)this, 8, 26);
        this.LongLeg_3.func_78793_a(-3.0f, 20.0f, 1.0f);
        this.LongLeg_3.func_78790_a(0.0f, 0.0f, 0.0f, 2, 4, 2, 0.0f);
        this.Head_leaf_1 = new ModelRenderer((ModelBase)this, 8, 21);
        this.Head_leaf_1.func_78793_a(-5.0f, -1.0f, 1.0f);
        this.Head_leaf_1.func_78790_a(0.0f, 0.0f, 0.0f, 4, 1, 4, 0.0f);
        this.Head.func_78792_a(this.Head_leaf);
        this.Head.func_78792_a(this.Head_leaf_1);
        this.Head.func_78792_a(this.Head_leaf_2);
        this.Head.func_78792_a(this.Head_leaf_3);
        this.Head.func_78792_a(this.Head_leaf_4);
        this.Head.func_78792_a(this.Head_leaf_5);
        this.Head.func_78792_a(this.Head_leaf_6);
        this.Head.func_78792_a(this.Head_leaf_7);
        this.Head.func_78792_a(this.RoseBud);
        this.Head = this.bipedHead();
    }

    private ModelRenderer bipedHead() {
        return this.Head;
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        this.LongLeg_2.func_78785_a(f5);
        this.LeftArm.func_78785_a(f5);
        this.Head.func_78785_a(f5);
        this.LongLeg_1.func_78785_a(f5);
        this.LongLeg_3.func_78785_a(f5);
        this.ArmBeggining_1.func_78785_a(f5);
        this.LeftArm_1.func_78785_a(f5);
        this.DoubleArm.func_78785_a(f5);
        this.Stem_Cover.func_78785_a(f5);
        this.LongLeg.func_78785_a(f5);
        this.LeftArm_3.func_78785_a(f5);
        this.Stem.func_78785_a(f5);
        this.LeftArm_2.func_78785_a(f5);
        this.ArmBeggining.func_78785_a(f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }

    public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        this.LongLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
        this.LongLeg_2.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
        this.LongLeg_3.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.LongLeg_1.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.Head.field_78796_g = netHeadYaw * ((float)Math.PI / 180);
    }
}

