/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.MathHelper
 */
package com.MrVorgan.peashootersmod.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class ModelConeZombie
extends ModelBiped {
    public ModelRenderer Right_Arm;
    public ModelRenderer RightLeg;
    public ModelRenderer Head;
    public ModelRenderer Body;
    public ModelRenderer LeftArm;
    public ModelRenderer LeftLeg;
    public ModelRenderer Cone_Base;
    public ModelRenderer Cone_Start_Bottom;
    public ModelRenderer Cone_Part_Middle;
    public ModelRenderer Top_2;
    public ModelRenderer Top_1;

    public ModelConeZombie() {
        this.field_78090_t = 128;
        this.field_78089_u = 128;
        this.LeftLeg = new ModelRenderer((ModelBase)this, 104, 0);
        this.LeftLeg.field_78809_i = true;
        this.LeftLeg.func_78793_a(1.9f, 14.0f, 0.1f);
        this.LeftLeg.func_78790_a(-2.0f, 0.0f, -2.0f, 4, 10, 4, 0.0f);
        this.Cone_Start_Bottom = new ModelRenderer((ModelBase)this, 0, 15);
        this.Cone_Start_Bottom.func_78793_a(-4.0f, -8.0f, -4.0f);
        this.Cone_Start_Bottom.func_78790_a(0.0f, 0.0f, 0.0f, 8, 5, 8, 0.0f);
        this.Top_1 = new ModelRenderer((ModelBase)this, 32, 0);
        this.Top_1.func_78793_a(-1.0f, -18.0f, -1.0f);
        this.Top_1.func_78790_a(0.0f, 0.0f, 0.0f, 2, 4, 2, 0.0f);
        this.Body = new ModelRenderer((ModelBase)this, 64, 0);
        this.Body.func_78793_a(0.0f, 4.0f, 0.0f);
        this.Body.func_78790_a(-4.0f, 0.0f, -2.0f, 8, 10, 4, 0.0f);
        this.Right_Arm = new ModelRenderer((ModelBase)this, 0, 0);
        this.Right_Arm.func_78793_a(-5.0f, 6.0f, 0.0f);
        this.Right_Arm.func_78790_a(-3.0f, -2.0f, -2.0f, 4, 10, 4, 0.0f);
        this.setRotateAngle(this.Right_Arm, -0.17453292f, -0.10000736f, 0.10000736f);
        this.RightLeg = new ModelRenderer((ModelBase)this, 16, 0);
        this.RightLeg.func_78793_a(-1.9f, 14.0f, 0.1f);
        this.RightLeg.func_78790_a(-2.0f, 0.0f, -2.0f, 4, 10, 4, 0.0f);
        this.Head = new ModelRenderer((ModelBase)this, 32, 0);
        this.Head.func_78793_a(0.0f, -1.0f, 0.0f);
        this.Head.func_78790_a(-4.0f, -3.0f, -4.0f, 8, 8, 8, 0.0f);
        this.LeftArm = new ModelRenderer((ModelBase)this, 88, 0);
        this.LeftArm.field_78809_i = true;
        this.LeftArm.func_78793_a(5.0f, 6.0f, 0.0f);
        this.LeftArm.func_78790_a(-1.0f, -2.0f, -2.0f, 4, 10, 4, 0.0f);
        this.setRotateAngle(this.LeftArm, 0.0f, 0.10000736f, -0.10000736f);
        this.Cone_Part_Middle = new ModelRenderer((ModelBase)this, 88, 14);
        this.Cone_Part_Middle.func_78793_a(-3.0f, -11.0f, -3.0f);
        this.Cone_Part_Middle.func_78790_a(0.0f, 0.0f, 0.0f, 6, 3, 6, 0.0f);
        this.Top_2 = new ModelRenderer((ModelBase)this, 32, 16);
        this.Top_2.func_78793_a(-2.0f, -15.0f, -2.0f);
        this.Top_2.func_78790_a(0.0f, 0.0f, 0.0f, 4, 4, 4, 0.0f);
        this.Cone_Base = new ModelRenderer((ModelBase)this, 50, 28);
        this.Cone_Base.func_78793_a(-6.0f, -4.0f, -6.0f);
        this.Cone_Base.func_78790_a(0.0f, 0.0f, 0.0f, 12, 1, 12, 0.0f);
        this.Head = this.bipedHead();
        this.Head.func_78792_a(this.Cone_Base);
        this.Head.func_78792_a(this.Cone_Part_Middle);
        this.Head.func_78792_a(this.Cone_Start_Bottom);
        this.Head.func_78792_a(this.Top_2);
        this.Head.func_78792_a(this.Top_1);
    }

    private ModelRenderer bipedHead() {
        return this.Head;
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        this.LeftLeg.func_78785_a(f5);
        this.Body.func_78785_a(f5);
        this.Right_Arm.func_78785_a(f5);
        this.RightLeg.func_78785_a(f5);
        this.Head.func_78785_a(f5);
        this.LeftArm.func_78785_a(f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }

    public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        this.LeftLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f)) * 1.4f * limbSwingAmount;
        this.LeftArm.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.2f)) * 1.4f * limbSwingAmount;
        this.RightLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.Right_Arm.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.2f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.Head.field_78796_g = netHeadYaw * ((float)Math.PI / 180);
        this.Head.field_78795_f = headPitch * ((float)Math.PI / 180);
    }
}

