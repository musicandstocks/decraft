/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.MathHelper
 */
package com.MrVorgan.peashootersmod.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class ModelOutHouseZombie
extends ModelBase {
    public ModelRenderer LeftLeg;
    public ModelRenderer Head;
    public ModelRenderer RightLeg;
    public ModelRenderer LeftArm;
    public ModelRenderer Right_Arm;
    public ModelRenderer Bottom;
    public ModelRenderer Side_Left;
    public ModelRenderer Side_Right;
    public ModelRenderer Back;
    public ModelRenderer Top1;
    public ModelRenderer Top2;
    public ModelRenderer Top;

    public ModelOutHouseZombie() {
        this.field_78090_t = 64;
        this.field_78089_u = 64;
        this.Top2 = new ModelRenderer((ModelBase)this, 32, 0);
        this.Top2.func_78793_a(-3.0f, -11.0f, -5.0f);
        this.Top2.func_78790_a(0.0f, 0.0f, 0.0f, 6, 1, 10, 0.0f);
        this.LeftArm = new ModelRenderer((ModelBase)this, 3, 48);
        this.LeftArm.field_78809_i = true;
        this.LeftArm.func_78793_a(6.0f, 2.0f, 0.0f);
        this.LeftArm.func_78790_a(0.0f, -2.0f, -2.0f, 3, 12, 3, 0.0f);
        this.setRotateAngle(this.LeftArm, 0.0f, 0.10000736f, -0.10000736f);
        this.Head = new ModelRenderer((ModelBase)this, 32, 14);
        this.Head.func_78793_a(0.0f, 2.0f, 0.0f);
        this.Head.func_78790_a(-4.0f, -8.0f, -4.0f, 8, 8, 8, 0.0f);
        this.Back = new ModelRenderer((ModelBase)this, 6, 14);
        this.Back.func_78793_a(-6.0f, -6.0f, 4.0f);
        this.Back.func_78790_a(0.0f, 0.0f, 0.0f, 12, 4, 1, 0.0f);
        this.Right_Arm = new ModelRenderer((ModelBase)this, 3, 48);
        this.Right_Arm.func_78793_a(-6.0f, 2.0f, 0.0f);
        this.Right_Arm.func_78790_a(-3.0f, -2.0f, -2.0f, 3, 12, 3, 0.0f);
        this.setRotateAngle(this.Right_Arm, -0.0f, -0.10000736f, 0.10000736f);
        this.Bottom = new ModelRenderer((ModelBase)this, 20, 32);
        this.Bottom.func_78793_a(-6.0f, -2.0f, -5.0f);
        this.Bottom.func_78790_a(0.0f, 0.0f, 0.0f, 12, 22, 10, 0.0f);
        this.Top = new ModelRenderer((ModelBase)this, 20, 0);
        this.Top.func_78793_a(-6.0f, -8.0f, -5.0f);
        this.Top.func_78790_a(0.0f, 0.0f, 0.0f, 12, 2, 10, 0.0f);
        this.Top1 = new ModelRenderer((ModelBase)this, 24, 1);
        this.Top1.func_78793_a(-5.0f, -10.0f, -5.0f);
        this.Top1.func_78790_a(0.0f, 0.0f, 0.0f, 10, 2, 10, 0.0f);
        this.RightLeg = new ModelRenderer((ModelBase)this, 0, 32);
        this.RightLeg.func_78793_a(-2.3f, 14.0f, 0.1f);
        this.RightLeg.func_78790_a(-2.0f, 0.0f, -2.0f, 4, 10, 4, 0.0f);
        this.LeftLeg = new ModelRenderer((ModelBase)this, 0, 32);
        this.LeftLeg.field_78809_i = true;
        this.LeftLeg.func_78793_a(2.2f, 14.0f, 0.1f);
        this.LeftLeg.func_78790_a(-2.0f, 0.0f, -2.0f, 4, 10, 4, 0.0f);
        this.Side_Right = new ModelRenderer((ModelBase)this, 0, 18);
        this.Side_Right.func_78793_a(4.0f, -6.0f, -5.0f);
        this.Side_Right.func_78790_a(0.0f, 0.0f, 0.0f, 2, 4, 9, 0.0f);
        this.Side_Left = new ModelRenderer((ModelBase)this, 0, 18);
        this.Side_Left.func_78793_a(-6.0f, -6.0f, -5.0f);
        this.Side_Left.func_78790_a(0.0f, 0.0f, 0.0f, 2, 4, 9, 0.0f);
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        this.Top2.func_78785_a(f5);
        this.LeftArm.func_78785_a(f5);
        this.Head.func_78785_a(f5);
        this.Back.func_78785_a(f5);
        this.Right_Arm.func_78785_a(f5);
        this.Bottom.func_78785_a(f5);
        this.Top.func_78785_a(f5);
        this.Top1.func_78785_a(f5);
        this.RightLeg.func_78785_a(f5);
        this.LeftLeg.func_78785_a(f5);
        this.Side_Right.func_78785_a(f5);
        this.Side_Left.func_78785_a(f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }

    public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        this.LeftLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f)) * 1.4f * limbSwingAmount;
        this.LeftArm.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.2f)) * 1.4f * limbSwingAmount;
        this.RightLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.Right_Arm.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.2f + (float)Math.PI)) * 1.4f * limbSwingAmount;
    }
}

