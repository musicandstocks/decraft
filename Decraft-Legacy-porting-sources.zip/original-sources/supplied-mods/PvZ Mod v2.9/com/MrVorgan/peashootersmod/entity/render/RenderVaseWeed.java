/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.util.ResourceLocation
 */
package com.MrVorgan.peashootersmod.entity.render;

import com.MrVorgan.peashootersmod.entity.EntityVaseWeed;
import com.MrVorgan.peashootersmod.entity.model.ModelVaseWeed;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;

public class RenderVaseWeed
extends RenderLiving<EntityVaseWeed> {
    public static final ResourceLocation TEXTURES = new ResourceLocation("pm:textures/entity/vaseweed.png");

    public RenderVaseWeed(RenderManager manager) {
        super(manager, (ModelBase)new ModelVaseWeed(), 0.5f);
    }

    protected ResourceLocation getEntityTexture(EntityVaseWeed entity) {
        return TEXTURES;
    }

    protected void applyRotations(EntityVaseWeed entityLiving, float p_77043_2_, float rotationYaw, float partialTicks) {
        super.func_77043_a((EntityLivingBase)entityLiving, p_77043_2_, rotationYaw, partialTicks);
    }
}

