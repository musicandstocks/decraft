/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 */
package com.MrVorgan.peashootersmod.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelWalnut
extends ModelBase {
    public ModelRenderer Bottom;
    public ModelRenderer Body;
    public ModelRenderer Top;
    public ModelRenderer Tip;
    public ModelRenderer RimRight;
    public ModelRenderer RimLeft;
    public ModelRenderer RimTopLeft;
    public ModelRenderer RimTopRight;
    public ModelRenderer shape10;
    public ModelRenderer shape10_1;
    public ModelRenderer shape12;
    public ModelRenderer shape13;
    public ModelRenderer shape13_1;

    public ModelWalnut() {
        this.field_78090_t = 128;
        this.field_78089_u = 64;
        this.shape13 = new ModelRenderer((ModelBase)this, 37, 0);
        this.shape13.func_78793_a(6.0f, 22.0f, -1.0f);
        this.shape13.func_78790_a(0.0f, 0.0f, 0.0f, 1, 1, 2, 0.0f);
        this.Bottom = new ModelRenderer((ModelBase)this, 0, 0);
        this.Bottom.func_78793_a(-6.0f, 22.0f, -6.0f);
        this.Bottom.func_78790_a(0.0f, 0.0f, 0.0f, 12, 2, 12, 0.0f);
        this.shape13_1 = new ModelRenderer((ModelBase)this, 0, 0);
        this.shape13_1.func_78793_a(-7.0f, 22.0f, -1.0f);
        this.shape13_1.func_78790_a(0.0f, 0.0f, 0.0f, 1, 1, 2, 0.0f);
        this.RimRight = new ModelRenderer((ModelBase)this, 90, 14);
        this.RimRight.func_78793_a(-8.0f, 7.0f, -1.0f);
        this.RimRight.func_78790_a(0.0f, 0.0f, 0.0f, 1, 15, 2, 0.0f);
        this.shape10_1 = new ModelRenderer((ModelBase)this, 36, 0);
        this.shape10_1.func_78793_a(4.0f, 4.0f, -1.0f);
        this.shape10_1.func_78790_a(0.0f, 0.0f, 0.0f, 2, 1, 2, 0.0f);
        this.Top = new ModelRenderer((ModelBase)this, 76, 0);
        this.Top.func_78793_a(-6.0f, 5.0f, -6.0f);
        this.Top.func_78790_a(0.0f, 0.0f, 0.0f, 12, 2, 12, 0.0f);
        this.shape12 = new ModelRenderer((ModelBase)this, 102, 14);
        this.shape12.func_78793_a(-4.0f, 3.0f, -1.0f);
        this.shape12.func_78790_a(0.0f, 0.0f, 0.0f, 8, 1, 2, 0.0f);
        this.shape10 = new ModelRenderer((ModelBase)this, 36, 0);
        this.shape10.func_78793_a(-6.0f, 4.0f, -1.0f);
        this.shape10.func_78790_a(0.0f, 0.0f, 0.0f, 2, 1, 2, 0.0f);
        this.Tip = new ModelRenderer((ModelBase)this, 0, 14);
        this.Tip.func_78793_a(-4.0f, 4.0f, -4.0f);
        this.Tip.func_78790_a(0.0f, 0.0f, 0.0f, 8, 1, 8, 0.0f);
        this.RimTopRight = new ModelRenderer((ModelBase)this, 6, 0);
        this.RimTopRight.func_78793_a(-7.0f, 5.0f, -1.0f);
        this.RimTopRight.func_78790_a(0.0f, 0.0f, 0.0f, 1, 2, 2, 0.0f);
        this.RimLeft = new ModelRenderer((ModelBase)this, 96, 14);
        this.RimLeft.func_78793_a(7.0f, 7.0f, -1.0f);
        this.RimLeft.func_78790_a(0.0f, 0.0f, 0.0f, 1, 15, 2, 0.0f);
        this.RimTopLeft = new ModelRenderer((ModelBase)this, 0, 0);
        this.RimTopLeft.func_78793_a(6.0f, 5.0f, -1.0f);
        this.RimTopLeft.func_78790_a(0.0f, 0.0f, 0.0f, 1, 2, 2, 0.0f);
        this.Body = new ModelRenderer((ModelBase)this, 34, 0);
        this.Body.func_78793_a(-7.0f, 7.0f, -7.0f);
        this.Body.func_78790_a(0.0f, 0.0f, 0.0f, 14, 15, 14, 0.0f);
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        this.shape13.func_78785_a(f5);
        this.Bottom.func_78785_a(f5);
        this.shape13_1.func_78785_a(f5);
        this.RimRight.func_78785_a(f5);
        this.shape10_1.func_78785_a(f5);
        this.Top.func_78785_a(f5);
        this.shape12.func_78785_a(f5);
        this.shape10.func_78785_a(f5);
        this.Tip.func_78785_a(f5);
        this.RimTopRight.func_78785_a(f5);
        this.RimLeft.func_78785_a(f5);
        this.RimTopLeft.func_78785_a(f5);
        this.Body.func_78785_a(f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }
}

