/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.MathHelper
 */
package com.MrVorgan.peashootersmod.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class ModelFlagZombie
extends ModelBase {
    public ModelRenderer Head;
    public ModelRenderer Body;
    public ModelRenderer RightLeg;
    public ModelRenderer LeftLeg;
    public ModelRenderer RightArm;
    public ModelRenderer LeftArm;
    public ModelRenderer FlagPole;
    public ModelRenderer Flag;

    public ModelFlagZombie() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        this.Head = new ModelRenderer((ModelBase)this, 0, 0);
        this.Head.func_78793_a(0.0f, 4.0f, 0.0f);
        this.Head.func_78790_a(-4.0f, -8.0f, -4.0f, 8, 8, 8, 0.0f);
        this.RightArm = new ModelRenderer((ModelBase)this, 16, 18);
        this.RightArm.func_78793_a(-5.0f, 6.0f, 0.0f);
        this.RightArm.func_78790_a(-3.0f, -2.0f, -2.0f, 4, 10, 4, 0.0f);
        this.setRotateAngle(this.RightArm, -1.5707964f, 0.0f, 0.0f);
        this.RightLeg = new ModelRenderer((ModelBase)this, 0, 18);
        this.RightLeg.func_78793_a(-1.9f, 14.0f, 0.1f);
        this.RightLeg.func_78790_a(-2.0f, 0.0f, -2.0f, 4, 10, 4, 0.0f);
        this.LeftLeg = new ModelRenderer((ModelBase)this, 0, 18);
        this.LeftLeg.func_78793_a(1.9f, 14.0f, 0.1f);
        this.LeftLeg.func_78790_a(-2.0f, 0.0f, -2.0f, 4, 10, 4, 0.0f);
        this.Body = new ModelRenderer((ModelBase)this, 40, 1);
        this.Body.func_78793_a(0.0f, 4.0f, 0.0f);
        this.Body.func_78790_a(-4.0f, 0.0f, -2.0f, 8, 10, 4, 0.0f);
        this.LeftArm = new ModelRenderer((ModelBase)this, 16, 18);
        this.LeftArm.field_78809_i = true;
        this.LeftArm.func_78793_a(5.0f, 6.0f, 0.0f);
        this.LeftArm.func_78790_a(-1.0f, -2.0f, -2.0f, 4, 10, 4, 0.0f);
        this.Flag = new ModelRenderer((ModelBase)this, 34, 16);
        this.Flag.func_78793_a(-13.5f, -6.5f, -10.5f);
        this.Flag.func_78790_a(0.0f, 0.0f, 0.0f, 8, 6, 1, 0.0f);
        this.setRotateAngle(this.Flag, 0.0f, -0.5009095f, 0.0f);
        this.FlagPole = new ModelRenderer((ModelBase)this, 34, 0);
        this.FlagPole.func_78793_a(-7.0f, -7.0f, -7.0f);
        this.FlagPole.func_78790_a(0.0f, 0.0f, 0.0f, 1, 11, 1, 0.0f);
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        this.Head.func_78785_a(f5);
        this.RightArm.func_78785_a(f5);
        this.RightLeg.func_78785_a(f5);
        this.LeftLeg.func_78785_a(f5);
        this.Body.func_78785_a(f5);
        this.LeftArm.func_78785_a(f5);
        this.Flag.func_78785_a(f5);
        this.FlagPole.func_78785_a(f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }

    public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        this.LeftLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f)) * 1.4f * limbSwingAmount;
        this.LeftArm.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.2f)) * 1.4f * limbSwingAmount;
        this.RightLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.Head.field_78796_g = netHeadYaw * ((float)Math.PI / 180);
        this.Head.field_78795_f = headPitch * ((float)Math.PI / 180);
    }
}

