/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.util.ResourceLocation
 */
package com.MrVorgan.peashootersmod.entity.render;

import com.MrVorgan.peashootersmod.entity.EntityOutHouseZombie;
import com.MrVorgan.peashootersmod.entity.model.ModelOutHouseZombie;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderOutHouseZombie
extends RenderLiving<EntityOutHouseZombie> {
    public static final ResourceLocation TEXTURES = new ResourceLocation("pm:textures/entity/outhousezombie.png");

    public RenderOutHouseZombie(RenderManager manager) {
        super(manager, (ModelBase)new ModelOutHouseZombie(), 0.5f);
    }

    protected ResourceLocation getEntityTexture(EntityOutHouseZombie entity) {
        return TEXTURES;
    }
}

