/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.util.ResourceLocation
 */
package com.MrVorgan.peashootersmod.entity.render;

import com.MrVorgan.peashootersmod.entity.EntityGargZombie;
import com.MrVorgan.peashootersmod.entity.model.ModelGargantuar;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderGargZombie
extends RenderLiving<EntityGargZombie> {
    public static final ResourceLocation TEXTURES = new ResourceLocation("pm:textures/entity/gargzombie.png");

    public RenderGargZombie(RenderManager manager) {
        super(manager, (ModelBase)new ModelGargantuar(), 0.5f);
    }

    protected ResourceLocation getEntityTexture(EntityGargZombie entity) {
        return TEXTURES;
    }
}

