/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.MathHelper
 */
package com.MrVorgan.peashootersmod.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class ModelYetiZombie
extends ModelBase {
    public ModelRenderer RightUpperArm;
    public ModelRenderer RightLeg;
    public ModelRenderer UpperBody;
    public ModelRenderer Belly;
    public ModelRenderer LeftUpperArm;
    public ModelRenderer LeftLeg;
    public ModelRenderer Head;
    public ModelRenderer RightWrist;
    public ModelRenderer LeftWrist;

    public ModelYetiZombie() {
        this.field_78090_t = 128;
        this.field_78089_u = 64;
        this.LeftUpperArm = new ModelRenderer((ModelBase)this, 0, 49);
        this.LeftUpperArm.field_78809_i = true;
        this.LeftUpperArm.func_78793_a(7.0f, 2.0f, 0.0f);
        this.LeftUpperArm.func_78790_a(-1.0f, -2.0f, -1.0f, 5, 7, 5, 0.0f);
        this.setRotateAngle(this.LeftUpperArm, 0.22759093f, 0.0f, -0.5462881f);
        this.LeftLeg = new ModelRenderer((ModelBase)this, 0, 30);
        this.LeftLeg.field_78809_i = true;
        this.LeftLeg.func_78793_a(2.0f, 13.0f, 0.0f);
        this.LeftLeg.func_78790_a(-1.0f, -2.0f, -1.0f, 5, 13, 5, 0.0f);
        this.LeftWrist = new ModelRenderer((ModelBase)this, 0, 3);
        this.LeftWrist.func_78793_a(7.8f, 3.0f, 0.0f);
        this.LeftWrist.func_78790_a(0.0f, 0.0f, 0.0f, 5, 7, 5, 0.0f);
        this.setRotateAngle(this.LeftWrist, -0.59184116f, 0.27314404f, -0.27314404f);
        this.Head = new ModelRenderer((ModelBase)this, 24, 44);
        this.Head.func_78793_a(-0.5f, -1.0f, -5.0f);
        this.Head.func_78790_a(-4.0f, -8.0f, -4.0f, 10, 10, 10, -0.5f);
        this.RightUpperArm = new ModelRenderer((ModelBase)this, 0, 49);
        this.RightUpperArm.func_78793_a(-9.0f, 0.0f, 0.0f);
        this.RightUpperArm.func_78790_a(-1.0f, -2.0f, -1.0f, 5, 7, 5, 0.0f);
        this.setRotateAngle(this.RightUpperArm, -0.29670596f, 0.0f, 0.4316199f);
        this.RightLeg = new ModelRenderer((ModelBase)this, 0, 30);
        this.RightLeg.func_78793_a(-4.0f, 13.0f, 0.0f);
        this.RightLeg.func_78790_a(-1.0f, -2.0f, -1.0f, 5, 13, 5, 0.0f);
        this.UpperBody = new ModelRenderer((ModelBase)this, 74, 0);
        this.UpperBody.func_78793_a(-3.0f, 6.0f, -1.0f);
        this.UpperBody.func_78790_a(-4.0f, -8.0f, -4.0f, 15, 8, 12, 0.0f);
        this.RightWrist = new ModelRenderer((ModelBase)this, 0, 3);
        this.RightWrist.func_78793_a(-11.0f, 2.0f, -2.0f);
        this.RightWrist.func_78790_a(0.0f, 0.0f, 0.0f, 5, 7, 5, 0.0f);
        this.setRotateAngle(this.RightWrist, -0.63739425f, -0.31869712f, 0.3642502f);
        this.Belly = new ModelRenderer((ModelBase)this, 84, 20);
        this.Belly.func_78793_a(-2.0f, 5.0f, -1.0f);
        this.Belly.func_78790_a(-4.0f, 0.0f, -2.0f, 13, 9, 9, 0.0f);
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        this.LeftUpperArm.func_78785_a(f5);
        this.LeftLeg.func_78785_a(f5);
        this.LeftWrist.func_78785_a(f5);
        this.Head.func_78785_a(f5);
        this.RightUpperArm.func_78785_a(f5);
        this.RightLeg.func_78785_a(f5);
        this.UpperBody.func_78785_a(f5);
        this.RightWrist.func_78785_a(f5);
        this.Belly.func_78785_a(f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }

    public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        this.LeftLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f)) * 1.4f * limbSwingAmount;
        this.RightLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.Head.field_78796_g = netHeadYaw * ((float)Math.PI / 180);
        this.Head.field_78795_f = headPitch * ((float)Math.PI / 180);
    }
}

