/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.util.ResourceLocation
 */
package com.MrVorgan.peashootersmod.entity.render;

import com.MrVorgan.peashootersmod.entity.EntityFlagZombie;
import com.MrVorgan.peashootersmod.entity.model.ModelFlagZombie;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderFlagZombie
extends RenderLiving<EntityFlagZombie> {
    public static final ResourceLocation TEXTURES = new ResourceLocation("pm:textures/entity/flag_zombie.png");

    public RenderFlagZombie(RenderManager manager) {
        super(manager, (ModelBase)new ModelFlagZombie(), 0.5f);
    }

    protected ResourceLocation getEntityTexture(EntityFlagZombie entity) {
        return TEXTURES;
    }
}

