/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.util.ResourceLocation
 */
package com.MrVorgan.peashootersmod.entity.render;

import com.MrVorgan.peashootersmod.entity.EntityWalnut;
import com.MrVorgan.peashootersmod.entity.model.ModelWalnut;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderWalnut
extends RenderLiving<EntityWalnut> {
    public static final ResourceLocation TEXTURES = new ResourceLocation("pm:textures/entity/walnut.png");

    public RenderWalnut(RenderManager manager) {
        super(manager, (ModelBase)new ModelWalnut(), 0.5f);
    }

    protected ResourceLocation getEntityTexture(EntityWalnut entity) {
        return TEXTURES;
    }
}

