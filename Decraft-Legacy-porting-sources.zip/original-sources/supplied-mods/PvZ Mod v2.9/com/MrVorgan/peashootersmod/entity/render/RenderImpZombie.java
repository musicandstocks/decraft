/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.util.ResourceLocation
 */
package com.MrVorgan.peashootersmod.entity.render;

import com.MrVorgan.peashootersmod.entity.EntityImpZombie;
import com.MrVorgan.peashootersmod.entity.model.ModelImp;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderImpZombie
extends RenderLiving<EntityImpZombie> {
    public static final ResourceLocation TEXTURES = new ResourceLocation("pm:textures/entity/impzombie.png");

    public RenderImpZombie(RenderManager manager) {
        super(manager, (ModelBase)new ModelImp(), 0.3f);
    }

    protected ResourceLocation getEntityTexture(EntityImpZombie entity) {
        return TEXTURES;
    }
}

