/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.util.ResourceLocation
 */
package com.MrVorgan.peashootersmod.entity.render;

import com.MrVorgan.peashootersmod.entity.EntityYetiZombie;
import com.MrVorgan.peashootersmod.entity.model.ModelYetiZombie;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderYetiZombie
extends RenderLiving<EntityYetiZombie> {
    public static final ResourceLocation TEXTURES = new ResourceLocation("pm:textures/entity/yetizombie.png");

    public RenderYetiZombie(RenderManager manager) {
        super(manager, (ModelBase)new ModelYetiZombie(), 0.5f);
    }

    protected ResourceLocation getEntityTexture(EntityYetiZombie entity) {
        return TEXTURES;
    }
}

