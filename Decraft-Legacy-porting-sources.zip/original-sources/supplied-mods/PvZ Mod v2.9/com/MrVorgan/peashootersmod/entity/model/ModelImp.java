/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.MathHelper
 */
package com.MrVorgan.peashootersmod.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class ModelImp
extends ModelBase {
    public ModelRenderer RightArm;
    public ModelRenderer LeftLeg;
    public ModelRenderer LeftArm;
    public ModelRenderer Head;
    public ModelRenderer Body;
    public ModelRenderer RightLeg;
    public ModelRenderer LeftWrist;
    public ModelRenderer RightWrist;

    public ModelImp() {
        this.field_78090_t = 64;
        this.field_78089_u = 32;
        this.RightArm = new ModelRenderer((ModelBase)this, 47, 13);
        this.RightArm.func_78793_a(-5.5f, 12.0f, 0.0f);
        this.RightArm.func_78790_a(0.0f, 0.0f, -2.5f, 2, 4, 3, 0.0f);
        this.LeftLeg = new ModelRenderer((ModelBase)this, 45, 0);
        this.LeftLeg.func_78793_a(0.75f, 19.0f, 1.0f);
        this.LeftLeg.func_78790_a(-0.5f, 0.0f, -2.5f, 3, 5, 3, 0.0f);
        this.Body = new ModelRenderer((ModelBase)this, 1, 9);
        this.Body.func_78793_a(-0.5f, 16.0f, 1.5f);
        this.Body.func_78790_a(-3.0f, -4.0f, -3.0f, 7, 5, 7, 0.0f);
        this.setRotateAngle(this.Body, 1.5707964f, 0.0f, 0.0f);
        this.Head = new ModelRenderer((ModelBase)this, 26, 20);
        this.Head.func_78793_a(-0.5f, 13.0f, -1.0f);
        this.Head.func_78790_a(-2.5f, -6.0f, -5.0f, 6, 6, 6, 0.0f);
        this.LeftWrist = new ModelRenderer((ModelBase)this, 0, 0);
        this.LeftWrist.func_78793_a(3.0f, 15.0f, 0.0f);
        this.LeftWrist.func_78790_a(0.5f, 0.0f, -5.0f, 2, 2, 4, 0.0f);
        this.LeftArm = new ModelRenderer((ModelBase)this, 47, 13);
        this.LeftArm.func_78793_a(4.5f, 12.0f, 0.0f);
        this.LeftArm.func_78790_a(-1.0f, 0.0f, -2.5f, 2, 4, 3, 0.0f);
        this.RightWrist = new ModelRenderer((ModelBase)this, 0, 0);
        this.RightWrist.func_78793_a(-5.0f, 15.0f, 0.0f);
        this.RightWrist.func_78790_a(-0.5f, 0.0f, -5.0f, 2, 2, 4, 0.0f);
        this.RightLeg = new ModelRenderer((ModelBase)this, 26, 0);
        this.RightLeg.func_78793_a(-2.75f, 19.0f, 1.0f);
        this.RightLeg.func_78790_a(-0.5f, 0.0f, -2.5f, 3, 5, 3, 0.0f);
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        this.RightArm.func_78785_a(f5);
        this.LeftLeg.func_78785_a(f5);
        this.Body.func_78785_a(f5);
        this.Head.func_78785_a(f5);
        this.LeftWrist.func_78785_a(f5);
        this.LeftArm.func_78785_a(f5);
        this.RightWrist.func_78785_a(f5);
        this.RightLeg.func_78785_a(f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }

    public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        this.LeftLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f)) * 1.4f * limbSwingAmount;
        this.LeftWrist.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.2f)) * 1.4f * limbSwingAmount;
        this.RightLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.RightWrist.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.2f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.Head.field_78796_g = netHeadYaw * ((float)Math.PI / 180);
        this.Head.field_78795_f = headPitch * ((float)Math.PI / 180);
    }
}

