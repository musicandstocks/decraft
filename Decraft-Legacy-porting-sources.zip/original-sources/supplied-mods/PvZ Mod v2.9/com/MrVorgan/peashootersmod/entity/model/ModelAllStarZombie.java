/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.MathHelper
 */
package com.MrVorgan.peashootersmod.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class ModelAllStarZombie
extends ModelBase {
    public ModelRenderer RightLeg;
    public ModelRenderer LeftLeg;
    public ModelRenderer Body;
    public ModelRenderer LeftArm;
    public ModelRenderer RightArm;
    public ModelRenderer Head;
    public ModelRenderer ShoulderPadBottom;
    public ModelRenderer ShoulderPadMiddle;
    public ModelRenderer ShoulderPadTop;
    public ModelRenderer Shoulders;
    public ModelRenderer LeftForeArm;
    public ModelRenderer NFLBall;
    public ModelRenderer Helmet;
    public ModelRenderer Helmet2;
    public ModelRenderer Helmet3;
    public ModelRenderer Bar1;
    public ModelRenderer Bar2;
    public ModelRenderer Bar3;
    public ModelRenderer Bar4;
    public ModelRenderer Helmet4;
    public ModelRenderer Helmet5;

    public ModelAllStarZombie() {
        this.field_78090_t = 128;
        this.field_78089_u = 128;
        this.Bar4 = new ModelRenderer((ModelBase)this, 17, 24);
        this.Bar4.func_78793_a(1.0f, -3.0f, -6.0f);
        this.Bar4.func_78790_a(0.0f, 0.0f, 0.0f, 1, 2, 0, 0.0f);
        this.Helmet3 = new ModelRenderer((ModelBase)this, 67, 27);
        this.Helmet3.func_78793_a(-4.5f, -9.0f, -6.0f);
        this.Helmet3.func_78790_a(0.0f, 0.0f, 0.0f, 9, 2, 9, 0.3f);
        this.ShoulderPadTop = new ModelRenderer((ModelBase)this, 20, 20);
        this.ShoulderPadTop.func_78793_a(7.0f, -3.0f, -1.0f);
        this.ShoulderPadTop.func_78790_a(0.0f, 0.0f, 0.0f, 3, 1, 4, 0.0f);
        this.Bar2 = new ModelRenderer((ModelBase)this, 17, 24);
        this.Bar2.func_78793_a(0.0f, 0.0f, 0.0f);
        this.Bar2.func_78790_a(-3.5f, -1.0f, -5.8f, 7, 0, 0, 0.3f);
        this.Body = new ModelRenderer((ModelBase)this, 0, 0);
        this.Body.func_78793_a(0.0f, 0.0f, -1.5f);
        this.Body.func_78790_a(-4.5f, 0.0f, -2.0f, 9, 12, 5, 0.2f);
        this.NFLBall = new ModelRenderer((ModelBase)this, 40, 52);
        this.NFLBall.func_78793_a(3.0f, 8.4f, -5.1f);
        this.NFLBall.func_78790_a(0.0f, 0.0f, 0.0f, 4, 4, 8, 0.5f);
        this.setRotateAngle(this.NFLBall, 0.4553564f, 0.0f, 0.0f);
        this.Helmet2 = new ModelRenderer((ModelBase)this, 42, 19);
        this.Helmet2.func_78793_a(4.0f, -8.0f, -6.0f);
        this.Helmet2.func_78790_a(0.0f, 0.0f, 0.0f, 1, 8, 9, 0.3f);
        this.RightLeg = new ModelRenderer((ModelBase)this, 18, 110);
        this.RightLeg.func_78793_a(-2.0f, 12.0f, 0.0f);
        this.RightLeg.func_78790_a(-2.25f, 0.0f, -3.0f, 4, 12, 4, 0.45f);
        this.Helmet5 = new ModelRenderer((ModelBase)this, 18, 23);
        this.Helmet5.func_78793_a(-4.0f, -0.3f, -5.7f);
        this.Helmet5.func_78790_a(0.0f, 0.0f, 0.0f, 8, 1, 1, 0.0f);
        this.LeftLeg = new ModelRenderer((ModelBase)this, 18, 91);
        this.LeftLeg.func_78793_a(2.0f, 12.0f, 0.0f);
        this.LeftLeg.func_78790_a(-1.75f, 0.0f, -3.0f, 4, 12, 4, 0.45f);
        this.ShoulderPadBottom = new ModelRenderer((ModelBase)this, 17, 17);
        this.ShoulderPadBottom.func_78793_a(5.0f, -1.0f, -3.0f);
        this.ShoulderPadBottom.func_78790_a(0.0f, 0.0f, 0.0f, 4, 3, 6, 0.0f);
        this.ShoulderPadMiddle = new ModelRenderer((ModelBase)this, 18, 19);
        this.ShoulderPadMiddle.func_78793_a(6.0f, -2.0f, -2.0f);
        this.ShoulderPadMiddle.func_78790_a(0.0f, 0.0f, 0.0f, 4, 1, 5, 0.0f);
        this.Helmet = new ModelRenderer((ModelBase)this, 71, 1);
        this.Helmet.func_78793_a(0.0f, 0.0f, 0.0f);
        this.Helmet.func_78790_a(-5.0f, -8.0f, -6.0f, 1, 8, 9, 0.3f);
        this.Bar1 = new ModelRenderer((ModelBase)this, 17, 24);
        this.Bar1.func_78793_a(0.0f, 0.0f, 0.0f);
        this.Bar1.func_78790_a(-3.5f, -3.0f, -6.0f, 7, 0, 0, 0.3f);
        this.Helmet4 = new ModelRenderer((ModelBase)this, 38, 8);
        this.Helmet4.func_78793_a(-4.0f, -9.0f, 3.3f);
        this.Helmet4.func_78790_a(0.0f, 0.0f, 0.0f, 8, 8, 1, 0.1f);
        this.Bar3 = new ModelRenderer((ModelBase)this, 17, 23);
        this.Bar3.func_78793_a(-2.0f, -3.0f, -6.0f);
        this.Bar3.func_78790_a(0.0f, 0.0f, 0.0f, 1, 2, 0, 0.0f);
        this.Head = new ModelRenderer((ModelBase)this, 82, 100);
        this.Head.func_78793_a(0.0f, 0.0f, 0.0f);
        this.Head.func_78790_a(-4.0f, -8.0f, -5.0f, 8, 8, 8, 0.0f);
        this.LeftArm = new ModelRenderer((ModelBase)this, 0, 71);
        this.LeftArm.func_78793_a(5.0f, 4.0f, 0.0f);
        this.LeftArm.func_78790_a(-1.5f, -3.0f, -2.0f, 4, 5, 4, 0.0f);
        this.setRotateAngle(this.LeftArm, 0.0f, 0.0f, -0.95609134f);
        this.RightArm = new ModelRenderer((ModelBase)this, 0, 86);
        this.RightArm.func_78793_a(-6.3f, 2.0f, 0.0f);
        this.RightArm.func_78790_a(-3.0f, -2.0f, -2.0f, 4, 14, 4, 0.0f);
        this.setRotateAngle(this.RightArm, -1.5707964f, 0.0f, 0.0f);
        this.Shoulders = new ModelRenderer((ModelBase)this, 4, 28);
        this.Shoulders.func_78793_a(-4.5f, -0.5f, -3.4f);
        this.Shoulders.func_78790_a(0.0f, 0.0f, 0.0f, 9, 8, 5, 0.7f);
        this.LeftForeArm = new ModelRenderer((ModelBase)this, 0, 52);
        this.LeftForeArm.func_78793_a(8.0f, 3.1f, -2.0f);
        this.LeftForeArm.func_78790_a(0.0f, 0.0f, 0.0f, 4, 8, 4, 0.0f);
        this.setRotateAngle(this.LeftForeArm, 0.0f, 0.0f, 0.59184116f);
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        this.Bar4.func_78785_a(f5);
        this.Helmet3.func_78785_a(f5);
        this.ShoulderPadTop.func_78785_a(f5);
        this.Bar2.func_78785_a(f5);
        this.Body.func_78785_a(f5);
        this.NFLBall.func_78785_a(f5);
        this.Helmet2.func_78785_a(f5);
        this.RightLeg.func_78785_a(f5);
        this.Helmet5.func_78785_a(f5);
        this.LeftLeg.func_78785_a(f5);
        this.ShoulderPadBottom.func_78785_a(f5);
        this.ShoulderPadMiddle.func_78785_a(f5);
        this.Helmet.func_78785_a(f5);
        this.Bar1.func_78785_a(f5);
        this.Helmet4.func_78785_a(f5);
        this.Bar3.func_78785_a(f5);
        this.Head.func_78785_a(f5);
        this.LeftArm.func_78785_a(f5);
        this.RightArm.func_78785_a(f5);
        this.Shoulders.func_78785_a(f5);
        this.LeftForeArm.func_78785_a(f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }

    public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        this.LeftLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f)) * 1.4f * limbSwingAmount;
        this.RightLeg.field_78795_f = MathHelper.func_76134_b((float)(limbSwing * 0.3f + (float)Math.PI)) * 1.4f * limbSwingAmount;
    }
}

