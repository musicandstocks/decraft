/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.Render
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraftforge.fml.client.registry.IRenderFactory
 *  net.minecraftforge.fml.client.registry.RenderingRegistry
 */
package com.MrVorgan.peashootersmod.util.handlers;

import com.MrVorgan.peashootersmod.entity.EntityAllStarZombie;
import com.MrVorgan.peashootersmod.entity.EntityBucketZombie;
import com.MrVorgan.peashootersmod.entity.EntityConeZombie;
import com.MrVorgan.peashootersmod.entity.EntityFlagZombie;
import com.MrVorgan.peashootersmod.entity.EntityGargZombie;
import com.MrVorgan.peashootersmod.entity.EntityImpZombie;
import com.MrVorgan.peashootersmod.entity.EntityOutHouseZombie;
import com.MrVorgan.peashootersmod.entity.EntityPotWeed;
import com.MrVorgan.peashootersmod.entity.EntityPumpkinWeed;
import com.MrVorgan.peashootersmod.entity.EntityRegZombie;
import com.MrVorgan.peashootersmod.entity.EntityTorchWood;
import com.MrVorgan.peashootersmod.entity.EntityVaseWeed;
import com.MrVorgan.peashootersmod.entity.EntityWalnut;
import com.MrVorgan.peashootersmod.entity.EntityWeed;
import com.MrVorgan.peashootersmod.entity.EntityYetiZombie;
import com.MrVorgan.peashootersmod.entity.render.RenderAllStarZombie;
import com.MrVorgan.peashootersmod.entity.render.RenderBucketZombie;
import com.MrVorgan.peashootersmod.entity.render.RenderConeZombie;
import com.MrVorgan.peashootersmod.entity.render.RenderFlagZombie;
import com.MrVorgan.peashootersmod.entity.render.RenderGargZombie;
import com.MrVorgan.peashootersmod.entity.render.RenderImpZombie;
import com.MrVorgan.peashootersmod.entity.render.RenderOutHouseZombie;
import com.MrVorgan.peashootersmod.entity.render.RenderPotWeed;
import com.MrVorgan.peashootersmod.entity.render.RenderPumpkinWeed;
import com.MrVorgan.peashootersmod.entity.render.RenderRegZombie;
import com.MrVorgan.peashootersmod.entity.render.RenderTorchWood;
import com.MrVorgan.peashootersmod.entity.render.RenderVaseWeed;
import com.MrVorgan.peashootersmod.entity.render.RenderWalnut;
import com.MrVorgan.peashootersmod.entity.render.RenderWeed;
import com.MrVorgan.peashootersmod.entity.render.RenderYetiZombie;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class RenderHandler {
    public static void registerEntityRenderers() {
        RenderingRegistry.registerEntityRenderingHandler(EntityWeed.class, (IRenderFactory)new IRenderFactory<EntityWeed>(){

            public Render<? super EntityWeed> createRenderFor(RenderManager manager) {
                return new RenderWeed(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityVaseWeed.class, (IRenderFactory)new IRenderFactory<EntityVaseWeed>(){

            public Render<? super EntityVaseWeed> createRenderFor(RenderManager manager) {
                return new RenderVaseWeed(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityWalnut.class, (IRenderFactory)new IRenderFactory<EntityWalnut>(){

            public Render<? super EntityWalnut> createRenderFor(RenderManager manager) {
                return new RenderWalnut(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityRegZombie.class, (IRenderFactory)new IRenderFactory<EntityRegZombie>(){

            public Render<? super EntityRegZombie> createRenderFor(RenderManager manager) {
                return new RenderRegZombie(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityAllStarZombie.class, (IRenderFactory)new IRenderFactory<EntityAllStarZombie>(){

            public Render<? super EntityAllStarZombie> createRenderFor(RenderManager manager) {
                return new RenderAllStarZombie(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityFlagZombie.class, (IRenderFactory)new IRenderFactory<EntityFlagZombie>(){

            public Render<? super EntityFlagZombie> createRenderFor(RenderManager manager) {
                return new RenderFlagZombie(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityTorchWood.class, (IRenderFactory)new IRenderFactory<EntityTorchWood>(){

            public Render<? super EntityTorchWood> createRenderFor(RenderManager manager) {
                return new RenderTorchWood(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityGargZombie.class, (IRenderFactory)new IRenderFactory<EntityGargZombie>(){

            public Render<? super EntityGargZombie> createRenderFor(RenderManager manager) {
                return new RenderGargZombie(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityOutHouseZombie.class, (IRenderFactory)new IRenderFactory<EntityOutHouseZombie>(){

            public Render<? super EntityOutHouseZombie> createRenderFor(RenderManager manager) {
                return new RenderOutHouseZombie(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityPotWeed.class, (IRenderFactory)new IRenderFactory<EntityPotWeed>(){

            public Render<? super EntityPotWeed> createRenderFor(RenderManager manager) {
                return new RenderPotWeed(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityPumpkinWeed.class, (IRenderFactory)new IRenderFactory<EntityPumpkinWeed>(){

            public Render<? super EntityPumpkinWeed> createRenderFor(RenderManager manager) {
                return new RenderPumpkinWeed(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityConeZombie.class, (IRenderFactory)new IRenderFactory<EntityConeZombie>(){

            public Render<? super EntityConeZombie> createRenderFor(RenderManager manager) {
                return new RenderConeZombie(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityBucketZombie.class, (IRenderFactory)new IRenderFactory<EntityBucketZombie>(){

            public Render<? super EntityBucketZombie> createRenderFor(RenderManager manager) {
                return new RenderBucketZombie(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityImpZombie.class, (IRenderFactory)new IRenderFactory<EntityImpZombie>(){

            public Render<? super EntityImpZombie> createRenderFor(RenderManager manager) {
                return new RenderImpZombie(manager);
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityYetiZombie.class, (IRenderFactory)new IRenderFactory<EntityYetiZombie>(){

            public Render<? super EntityYetiZombie> createRenderFor(RenderManager manager) {
                return new RenderYetiZombie(manager);
            }
        });
    }
}

