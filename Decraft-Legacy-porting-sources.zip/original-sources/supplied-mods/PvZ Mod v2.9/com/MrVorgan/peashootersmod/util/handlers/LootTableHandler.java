/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.world.storage.loot.LootTableList
 */
package com.MrVorgan.peashootersmod.util.handlers;

import net.minecraft.util.ResourceLocation;
import net.minecraft.world.storage.loot.LootTableList;

public class LootTableHandler {
    public static final ResourceLocation WEED = LootTableList.func_186375_a((ResourceLocation)new ResourceLocation("pm", "weed"));
    public static final ResourceLocation ZOMBIE = LootTableList.func_186375_a((ResourceLocation)new ResourceLocation("pm", "zombie"));
    public static final ResourceLocation CONE_HEAD = LootTableList.func_186375_a((ResourceLocation)new ResourceLocation("pm", "cone_zombie"));
    public static final ResourceLocation TORCHWOOD = LootTableList.func_186375_a((ResourceLocation)new ResourceLocation("pm", "torchwood"));
    public static final ResourceLocation WALNUT = LootTableList.func_186375_a((ResourceLocation)new ResourceLocation("pm", "walnut"));
    public static final ResourceLocation YETI_ZOMBIE = LootTableList.func_186375_a((ResourceLocation)new ResourceLocation("pm", "yeti"));
}

