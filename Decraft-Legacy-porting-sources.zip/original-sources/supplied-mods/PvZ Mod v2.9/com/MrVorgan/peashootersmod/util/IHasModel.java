/*
 * Decompiled with CFR 0.152.
 */
package com.MrVorgan.peashootersmod.util;

public interface IHasModel {
    public void registerModels();
}

