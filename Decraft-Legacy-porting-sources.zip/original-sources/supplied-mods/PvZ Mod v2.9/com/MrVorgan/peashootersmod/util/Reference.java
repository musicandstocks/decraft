/*
 * Decompiled with CFR 0.152.
 */
package com.MrVorgan.peashootersmod.util;

public class Reference {
    public static final String MOD_ID = "pm";
    public static final String NAME = "Plants Vs Zombies Mod";
    public static final String VERSION = "2.9";
    public static final String ACCEPTED_VERSIONS = "[1.12.2]";
    public static final String CLIENT_PROXY_CLASS = "com.MrVorgan.peashootersmod.proxy.ClientProxy";
    public static final String COMMON_PROXY_CLASS = "com.MrVorgan.peashootersmod.proxy.CommonProxy";
    public static final int ENTITY_WEED = 120;
    public static final int ENTITY_REG_ZOMBIE = 121;
    public static final int ENTITY_POT_WEED = 122;
    public static final int ENTITY_CONE_ZOMBIE = 123;
    public static final int ENTITY_BUCKET_ZOMBIE = 124;
    public static final int ENTITY_GARG_ZOMBIE = 125;
    public static final int ENTITY_IMP_ZOMBIE = 126;
    public static final int ENTITY_PUMPKIN_WEED = 127;
    public static final int ENTITY_TORCHWOOD = 128;
    public static final int ENTITY_FLAG_ZOMBIE = 129;
    public static final int ENTITY_ALL_STAR_ZOMBIE = 130;
    public static final int ENTITY_OUT_HOUSE_ZOMBIE = 131;
    public static final int ENTITY_VASE_WEED = 132;
    public static final int ENTITY_WALNUT = 133;
    public static final int ENTITY_YETI_ZOMBIE = 134;
}

