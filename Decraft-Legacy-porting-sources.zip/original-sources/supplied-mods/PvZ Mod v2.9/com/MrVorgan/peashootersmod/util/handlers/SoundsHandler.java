/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.SoundEvent
 *  net.minecraftforge.fml.common.registry.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistryEntry
 */
package com.MrVorgan.peashootersmod.util.handlers;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistryEntry;

public class SoundsHandler {
    public static SoundEvent ENTITY_WEED_AMBIENT;
    public static SoundEvent ENTITY_WEED_DEATH;
    public static SoundEvent ENTITY_WEED_WALK;
    public static SoundEvent ENTITY_ZOMBIE_AMBIENT;
    public static SoundEvent ENTITY_GARG_AMBIENT;
    public static SoundEvent ENTITY_GARG_HURT;
    public static SoundEvent ENTITY_GARG_DEATH;
    public static SoundEvent ENTITY_ZOMBIE_HURT;
    public static SoundEvent ENTITY_IMP_AMBIENT;
    public static SoundEvent ENTITY_IMP_DEATH;
    public static SoundEvent ENTITY_IMP_HURT;
    public static SoundEvent ENTITY_TORCHWOOD_HURT;
    public static SoundEvent ENTITY_TORCHWOOD_DEATH;
    public static SoundEvent ENTITY_TORCHWOOD_AMBIENT;
    public static SoundEvent ENTITY_FLAG_ZOMBIE_DEATH;
    public static SoundEvent ENTITY_WALNUT_HURT;
    public static SoundEvent ENTITY_WALNUT_DEATH;

    public static void registerSounds() {
        ENTITY_WEED_AMBIENT = SoundsHandler.registerSound("entity.weed.weed_ambient");
        ENTITY_WEED_DEATH = SoundsHandler.registerSound("entity.weed.weed_death");
        ENTITY_WEED_WALK = SoundsHandler.registerSound("entity.weed.weed_walk");
        ENTITY_ZOMBIE_AMBIENT = SoundsHandler.registerSound("entity.reg_zombie.zombie_ambient");
        ENTITY_ZOMBIE_HURT = SoundsHandler.registerSound("entity.reg_zombie.zombie_hurt");
        ENTITY_GARG_AMBIENT = SoundsHandler.registerSound("entity.garg.garg_ambient");
        ENTITY_GARG_HURT = SoundsHandler.registerSound("entity.garg.garg_hurt");
        ENTITY_GARG_DEATH = SoundsHandler.registerSound("entity.garg.garg_death");
        ENTITY_IMP_AMBIENT = SoundsHandler.registerSound("entity.imp.imp_ambient");
        ENTITY_IMP_DEATH = SoundsHandler.registerSound("entity.imp.imp_death");
        ENTITY_FLAG_ZOMBIE_DEATH = SoundsHandler.registerSound("entity.reg_zombie.flag_zombie_death");
        ENTITY_IMP_HURT = SoundsHandler.registerSound("entity.imp.imp_hurt");
        ENTITY_TORCHWOOD_HURT = SoundsHandler.registerSound("entity.torchwood.torchwood_hurt");
        ENTITY_TORCHWOOD_AMBIENT = SoundsHandler.registerSound("entity.torchwood.torchwood_ambient");
        ENTITY_TORCHWOOD_DEATH = SoundsHandler.registerSound("entity.torchwood.torchwood_death");
        ENTITY_WALNUT_DEATH = SoundsHandler.registerSound("entity.walnut.gulp");
        ENTITY_WALNUT_HURT = SoundsHandler.registerSound("entity.walnut.zombiebite");
    }

    private static SoundEvent registerSound(String name) {
        ResourceLocation location = new ResourceLocation("pm", name);
        SoundEvent event = new SoundEvent(location);
        event.setRegistryName(name);
        ForgeRegistries.SOUND_EVENTS.register((IForgeRegistryEntry)event);
        return event;
    }
}

