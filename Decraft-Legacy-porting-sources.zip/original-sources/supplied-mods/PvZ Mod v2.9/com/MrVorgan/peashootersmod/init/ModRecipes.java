/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.common.registry.GameRegistry
 */
package com.MrVorgan.peashootersmod.init;

import com.MrVorgan.peashootersmod.init.ModItems;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModRecipes {
    public static void init() {
        GameRegistry.addSmelting((Item)ModItems.PEA_POD, (ItemStack)new ItemStack(ModItems.FIRE_POD, 1), (float)1.5f);
        GameRegistry.addSmelting((Item)ModItems.SNOW_POD, (ItemStack)new ItemStack(ModItems.PEA_POD, 1), (float)1.5f);
    }
}

