/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.material.Material
 */
package com.MrVorgan.peashootersmod.init;

import com.MrVorgan.peashootersmod.blocks.BlockWeedsPlant;
import com.MrVorgan.peashootersmod.blocks.FertileDirt;
import com.MrVorgan.peashootersmod.blocks.GnomeGoldOre;
import com.MrVorgan.peashootersmod.blocks.GnomeIronOre;
import com.MrVorgan.peashootersmod.blocks.PotatoMinePlant;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class ModBlocks {
    public static final List<Block> BLOCKS = new ArrayList<Block>();
    public static final Block FERTILE_DIRT = new FertileDirt("fertile_dirt", Material.field_151578_c);
    public static final Block GNOME_IRON_ORE = new GnomeIronOre("gnome_iron_ore", Material.field_151576_e);
    public static final Block GNOME_GOLD_ORE = new GnomeGoldOre("gnome_gold_ore", Material.field_151576_e);
    public static final Block WEEDS_PLANT = new BlockWeedsPlant("weeds_plant");
    public static final Block POTATO_MINE_PLANT = new PotatoMinePlant("potato_mine_plant");
}

