/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.inventory.EntityEquipmentSlot
 *  net.minecraft.item.Item
 *  net.minecraft.item.Item$ToolMaterial
 *  net.minecraft.item.ItemArmor$ArmorMaterial
 *  net.minecraft.item.ItemHoe
 *  net.minecraft.item.ItemSword
 *  net.minecraft.util.SoundEvent
 *  net.minecraftforge.common.util.EnumHelper
 */
package com.MrVorgan.peashootersmod.init;

import com.MrVorgan.peashootersmod.items.ItemBase;
import com.MrVorgan.peashootersmod.items.armor.ArmorBase;
import com.MrVorgan.peashootersmod.items.armor.ArmorBase_2;
import com.MrVorgan.peashootersmod.items.armor.ArmorBase_3;
import com.MrVorgan.peashootersmod.items.armor.ArmorBase_4;
import com.MrVorgan.peashootersmod.items.food.ItemCustomFood;
import com.MrVorgan.peashootersmod.items.food.ItemWeed;
import com.MrVorgan.peashootersmod.items.tools.ToolHoe;
import com.MrVorgan.peashootersmod.items.tools.ToolSword;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemSword;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.common.util.EnumHelper;

public class ModItems {
    public static final List<Item> ITEMS = new ArrayList<Item>();
    public static final Item.ToolMaterial MATERIAL_IRON = EnumHelper.addToolMaterial((String)"material_iron", (int)2, (int)250, (float)6.0f, (float)2.0f, (int)0);
    public static final ItemArmor.ArmorMaterial ARMOR_MATERIAL_PADDING = EnumHelper.addArmorMaterial((String)"armor_material_padding", (String)"pm:padding", (int)14, (int[])new int[]{2, 2, 8, 4}, (int)0, (SoundEvent)SoundEvents.field_187728_s, (float)0.0f);
    public static final ItemArmor.ArmorMaterial ARMOR_MATERIAL_IRON = EnumHelper.addArmorMaterial((String)"armor_material_iron", (String)"pm:iron", (int)16, (int[])new int[]{0, 0, 0, 8}, (int)0, (SoundEvent)SoundEvents.field_187725_r, (float)0.0f);
    public static final Item.ToolMaterial MATERIAL_PAN = EnumHelper.addToolMaterial((String)"material_pan", (int)3, (int)1561, (float)10.0f, (float)5.0f, (int)0);
    public static final ItemArmor.ArmorMaterial ARMOR_MATERIAL_CONE = EnumHelper.addArmorMaterial((String)"armor_material_cone", (String)"pm:cone", (int)16, (int[])new int[]{0, 0, 0, 5}, (int)0, (SoundEvent)SoundEvents.field_187728_s, (float)0.0f);
    public static final ItemArmor.ArmorMaterial ARMOR_MATERIAL_POT = EnumHelper.addArmorMaterial((String)"armor_material_pot", (String)"pm:pot", (int)16, (int[])new int[]{0, 0, 0, 8}, (int)0, (SoundEvent)SoundEvents.field_187725_r, (float)0.0f);
    public static final Item SUN = new ItemBase("sun");
    public static final Item GNOME_IRON = new ItemBase("gnome_iron");
    public static final Item GNOME_GOLD = new ItemBase("gnome_gold");
    public static final Item SUNFLOWER_BUD = new ItemBase("sunflower_bud");
    public static final Item SUNFLOWER_SEEDS = new ItemBase("sunflower_seeds");
    public static final Item PEASHOOTER_SEED = new ItemBase("peashooter_seed");
    public static final Item PEA_POD = new ItemBase("pea_pod");
    public static final Item THREEPEATER_SEEDS = new ItemBase("threepeater_seeds");
    public static final Item THREEPEATER_PODS = new ItemBase("threepeater_pods");
    public static final Item REPEATER_PODS = new ItemBase("repeater_pods");
    public static final Item REPEATER_SEEDS = new ItemBase("repeater_seeds");
    public static final Item FIREPEA_SEED = new ItemBase("firepea_seed");
    public static final Item FIRE_POD = new ItemBase("fire_pod");
    public static final Item SNOWPEA_SEED = new ItemBase("snowpea_seed");
    public static final Item SNOW_POD = new ItemBase("snow_pod");
    public static final Item FUME_SHROOM_BUBBLES = new ItemBase("fume_shroom_bubbles");
    public static final Item PUFF_SHROOM_BUBBLES = new ItemBase("puff_shroom_bubbles");
    public static final Item SHELL_PIECE = new ItemBase("shell_piece");
    public static final Item WEED_ITEM = new ItemWeed("weed_item", 1, false);
    public static final Item CONE_PIECE = new ItemBase("cone_piece");
    public static final Item FLAG = new ItemBase("flag");
    public static final Item SPIKE = new ItemBase("spike");
    public static final Item PADDING = new ItemBase("padding");
    public static final Item TACO = new ItemCustomFood("taco", 18, false);
    public static final Item CHILLY_TACO = new ItemCustomFood("chilly_taco", 18, true);
    public static final ItemHoe IRON_TROWEL = new ToolHoe("iron_trowel", MATERIAL_IRON);
    public static final ItemSword PAN_SWORD = new ToolSword("pan_sword", MATERIAL_PAN);
    public static final Item AS_HELMET = new ArmorBase_2("as_helmet", ARMOR_MATERIAL_PADDING, 1, EntityEquipmentSlot.HEAD);
    public static final Item AS_CHESTPLATE = new ArmorBase_2("as_chestplate", ARMOR_MATERIAL_PADDING, 1, EntityEquipmentSlot.CHEST);
    public static final Item AS_LEGGINGS = new ArmorBase_2("as_leggings", ARMOR_MATERIAL_PADDING, 2, EntityEquipmentSlot.LEGS);
    public static final Item AS_BOOTS = new ArmorBase_2("as_boots", ARMOR_MATERIAL_PADDING, 1, EntityEquipmentSlot.FEET);
    public static final Item W_BUCKET = new ArmorBase("w_bucket", ARMOR_MATERIAL_IRON, 1, EntityEquipmentSlot.HEAD);
    public static final Item W_CONE = new ArmorBase_3("w_cone", ARMOR_MATERIAL_CONE, 1, EntityEquipmentSlot.HEAD);
    public static final Item W_POT = new ArmorBase_4("w_pot", ARMOR_MATERIAL_POT, 1, EntityEquipmentSlot.HEAD);
}

