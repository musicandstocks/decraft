/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.biome.Biome
 *  net.minecraftforge.common.BiomeDictionary
 *  net.minecraftforge.common.BiomeDictionary$Type
 *  net.minecraftforge.common.BiomeManager
 *  net.minecraftforge.common.BiomeManager$BiomeEntry
 *  net.minecraftforge.common.BiomeManager$BiomeType
 *  net.minecraftforge.fml.common.registry.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistryEntry
 */
package com.MrVorgan.peashootersmod.init;

import com.MrVorgan.peashootersmod.world.biome.BiomeFrostbiteCaves;
import com.MrVorgan.peashootersmod.world.biome.BiomeZomburbia;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.common.BiomeManager;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistryEntry;

public class ModBiomes {
    public static final Biome ZOMBURBIA = new BiomeZomburbia();
    public static final Biome FROSTBITE_CAVES = new BiomeFrostbiteCaves();

    public static void registerBiomes() {
        ModBiomes.initBiome(ZOMBURBIA, "zomburbia", BiomeManager.BiomeType.WARM, BiomeDictionary.Type.DEAD, BiomeDictionary.Type.SPOOKY);
        ModBiomes.initBiome(FROSTBITE_CAVES, "frostbite_caves", BiomeManager.BiomeType.ICY, BiomeDictionary.Type.COLD, BiomeDictionary.Type.SPOOKY);
    }

    private static Biome initBiome(Biome biome, String name, BiomeManager.BiomeType biomeType, BiomeDictionary.Type ... types) {
        biome.setRegistryName(name);
        ForgeRegistries.BIOMES.register((IForgeRegistryEntry)biome);
        System.out.println("Biome Registered");
        BiomeDictionary.addTypes((Biome)biome, (BiomeDictionary.Type[])types);
        BiomeManager.addBiome((BiomeManager.BiomeType)biomeType, (BiomeManager.BiomeEntry)new BiomeManager.BiomeEntry(biome, 10));
        BiomeManager.addSpawnBiome((Biome)biome);
        System.out.println("Biome Added");
        return biome;
    }
}

