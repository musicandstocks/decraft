/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.fml.common.registry.EntityRegistry
 */
package com.MrVorgan.peashootersmod.init;

import com.MrVorgan.peashootersmod.Main;
import com.MrVorgan.peashootersmod.entity.EntityAllStarZombie;
import com.MrVorgan.peashootersmod.entity.EntityBucketZombie;
import com.MrVorgan.peashootersmod.entity.EntityConeZombie;
import com.MrVorgan.peashootersmod.entity.EntityFlagZombie;
import com.MrVorgan.peashootersmod.entity.EntityGargZombie;
import com.MrVorgan.peashootersmod.entity.EntityImpZombie;
import com.MrVorgan.peashootersmod.entity.EntityOutHouseZombie;
import com.MrVorgan.peashootersmod.entity.EntityPotWeed;
import com.MrVorgan.peashootersmod.entity.EntityPumpkinWeed;
import com.MrVorgan.peashootersmod.entity.EntityRegZombie;
import com.MrVorgan.peashootersmod.entity.EntityTorchWood;
import com.MrVorgan.peashootersmod.entity.EntityVaseWeed;
import com.MrVorgan.peashootersmod.entity.EntityWeed;
import com.MrVorgan.peashootersmod.entity.EntityYetiZombie;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;

public class ModEntities {
    public static void registerEntities() {
        ModEntities.registerEntity("weed", EntityWeed.class, 120, 50, 41265, 54065);
        ModEntities.registerEntity("flag_zombie", EntityFlagZombie.class, 129, 50, 0x505050, 0xFF0000);
        ModEntities.registerEntity("pot_weed", EntityPotWeed.class, 122, 50, 41265, 7220224);
        ModEntities.registerEntity("vase_weed", EntityVaseWeed.class, 132, 50, 41265, 7220224);
        ModEntities.registerEntity("cone_zombie", EntityConeZombie.class, 123, 50, 0x505050, 16751104);
        ModEntities.registerEntity("bucket_zombie", EntityBucketZombie.class, 124, 50, 0x646464, 0x505050);
        ModEntities.registerEntity("garg_zombie", EntityGargZombie.class, 125, 50, 0x646464, 7220224);
        ModEntities.registerEntity("imp_zombie", EntityImpZombie.class, 126, 50, 0x646464, 8354373);
        ModEntities.registerEntity("pumpkin_weed", EntityPumpkinWeed.class, 127, 50, 41265, 16751104);
        ModEntities.registerEntity("all_star_zombie", EntityAllStarZombie.class, 130, 50, 0xFF0000, 0x505050);
        ModEntities.registerEntity("torchwood", EntityTorchWood.class, 128, 50, 0x6DDD00, 7220224);
        ModEntities.registerEntity("reg_zombie", EntityRegZombie.class, 121, 50, 0x505050, 0x646464);
        ModEntities.registerEntity("out_house_zombie", EntityOutHouseZombie.class, 131, 50, 0x505050, 3110313);
        ModEntities.registerEntity("yeti_zombie", EntityYetiZombie.class, 134, 50, 0x646464, 0xFFFFFF);
    }

    private static void registerEntity(String name, Class<? extends Entity> entity, int id, int range, int color1, int color2) {
        EntityRegistry.registerModEntity((ResourceLocation)new ResourceLocation("pm:" + name), entity, (String)name, (int)id, (Object)Main.instance, (int)range, (int)1, (boolean)true, (int)color1, (int)color2);
    }
}

