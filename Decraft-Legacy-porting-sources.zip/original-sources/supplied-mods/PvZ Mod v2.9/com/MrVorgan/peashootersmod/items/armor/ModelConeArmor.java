/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 */
package com.MrVorgan.peashootersmod.items.armor;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelConeArmor
extends ModelBiped {
    public ModelRenderer Cone_Base;
    public ModelRenderer Cone_Start_Bottom;
    public ModelRenderer Cone_Part_Middle;
    public ModelRenderer Top_2;
    public ModelRenderer Top_1;

    public ModelConeArmor() {
        this.field_78090_t = 128;
        this.field_78089_u = 128;
        this.Cone_Start_Bottom = new ModelRenderer((ModelBase)this, 75, 9);
        this.Cone_Start_Bottom.func_78793_a(-4.0f, -13.0f, -4.0f);
        this.Cone_Start_Bottom.func_78790_a(0.0f, 0.0f, 0.0f, 8, 4, 8, 0.0f);
        this.Cone_Base = new ModelRenderer((ModelBase)this, 26, 15);
        this.Cone_Base.func_78793_a(-6.0f, -9.0f, -6.0f);
        this.Cone_Base.func_78790_a(0.0f, 0.0f, 0.0f, 12, 1, 12, 0.0f);
        this.Cone_Part_Middle = new ModelRenderer((ModelBase)this, 10, 0);
        this.Cone_Part_Middle.func_78793_a(-3.0f, -16.0f, -3.0f);
        this.Cone_Part_Middle.func_78790_a(0.0f, 0.0f, 0.0f, 6, 3, 6, 0.0f);
        this.Top_1 = new ModelRenderer((ModelBase)this, 49, 0);
        this.Top_1.func_78793_a(-1.0f, -23.0f, -1.0f);
        this.Top_1.func_78790_a(0.0f, 0.0f, 0.0f, 2, 3, 2, 0.0f);
        this.Top_2 = new ModelRenderer((ModelBase)this, 8, 16);
        this.Top_2.func_78793_a(-2.0f, -20.0f, -2.0f);
        this.Top_2.func_78790_a(0.0f, 0.0f, 0.0f, 4, 4, 4, 0.0f);
        this.field_78116_c.func_78792_a(this.Cone_Part_Middle);
        this.field_78116_c.func_78792_a(this.Cone_Base);
        this.field_78116_c.func_78792_a(this.Cone_Start_Bottom);
        this.field_78116_c.func_78792_a(this.Top_1);
        this.field_78116_c.func_78792_a(this.Top_2);
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }
}

