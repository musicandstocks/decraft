/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 *  net.minecraft.item.Item$ToolMaterial
 *  net.minecraft.item.ItemSword
 */
package com.MrVorgan.peashootersmod.items.tools;

import com.MrVorgan.peashootersmod.Main;
import com.MrVorgan.peashootersmod.init.ModItems;
import com.MrVorgan.peashootersmod.util.IHasModel;
import net.minecraft.item.Item;
import net.minecraft.item.ItemSword;

public class ToolSword
extends ItemSword
implements IHasModel {
    public ToolSword(String name, Item.ToolMaterial material) {
        super(material);
        this.func_77655_b(name);
        this.setRegistryName(name);
        this.func_77637_a(Main.pvz_t_w);
        ModItems.ITEMS.add((Item)this);
    }

    @Override
    public void registerModels() {
        Main.proxy.registerItemRenderer((Item)this, 0, "inventory");
    }
}

