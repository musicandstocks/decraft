/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 */
package com.MrVorgan.peashootersmod.items.armor;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelPotArmour
extends ModelBiped {
    public ModelRenderer shape15;
    public ModelRenderer shape16;

    public ModelPotArmour() {
        this.field_78090_t = 128;
        this.field_78089_u = 128;
        this.shape15 = new ModelRenderer((ModelBase)this, 88, 0);
        this.shape15.func_78793_a(-5.0f, -8.0f, -5.0f);
        this.shape15.func_78790_a(0.0f, 0.0f, 0.0f, 10, 2, 10, 0.0f);
        this.shape16 = new ModelRenderer((ModelBase)this, 90, 14);
        this.shape16.func_78793_a(-4.0f, -13.0f, -4.0f);
        this.shape16.func_78790_a(0.0f, 0.0f, 0.0f, 8, 5, 8, 0.0f);
        this.field_78116_c.func_78792_a(this.shape15);
        this.field_78116_c.func_78792_a(this.shape16);
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }
}

