/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 */
package com.MrVorgan.peashootersmod.items;

import com.MrVorgan.peashootersmod.Main;
import com.MrVorgan.peashootersmod.init.ModItems;
import com.MrVorgan.peashootersmod.util.IHasModel;
import net.minecraft.item.Item;

public class ItemBase
extends Item
implements IHasModel {
    public ItemBase(String name) {
        this.func_77655_b(name);
        this.setRegistryName(name);
        this.func_77637_a(Main.pvz_t_w);
        ModItems.ITEMS.add(this);
    }

    @Override
    public void registerModels() {
        Main.proxy.registerItemRenderer(this, 0, "inventory");
    }
}

