/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemFood
 */
package com.MrVorgan.peashootersmod.items.food;

import com.MrVorgan.peashootersmod.Main;
import com.MrVorgan.peashootersmod.init.ModItems;
import com.MrVorgan.peashootersmod.util.IHasModel;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;

public class ItemCustomFood
extends ItemFood
implements IHasModel {
    public ItemCustomFood(String name, int amount, boolean isWolfFood) {
        super(amount, isWolfFood);
        this.func_77655_b(name);
        this.setRegistryName(name);
        this.func_77637_a(Main.pvz_t_w);
        ModItems.ITEMS.add((Item)this);
    }

    @Override
    public void registerModels() {
        Main.proxy.registerItemRenderer((Item)this, 0, "inventory");
    }
}

