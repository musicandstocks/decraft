/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 */
package com.MrVorgan.peashootersmod.items.armor;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelCustomArmor
extends ModelBiped {
    public ModelRenderer Bucket;

    public ModelCustomArmor() {
        this.field_78090_t = 128;
        this.field_78089_u = 128;
        this.Bucket = new ModelRenderer((ModelBase)this, 64, 0);
        this.Bucket.func_78793_a(-4.1f, -8.0f, -4.2f);
        this.Bucket.func_78790_a(-0.6f, -2.6f, -0.5f, 9, 7, 9, 0.0f);
        this.field_78116_c.func_78792_a(this.Bucket);
    }

    public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
        super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
    }

    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.field_78795_f = x;
        modelRenderer.field_78796_g = y;
        modelRenderer.field_78808_h = z;
    }
}

