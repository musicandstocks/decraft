/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.inventory.EntityEquipmentSlot
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemArmor$ArmorMaterial
 *  net.minecraft.item.ItemStack
 */
package com.MrVorgan.peashootersmod.items.armor;

import com.MrVorgan.peashootersmod.Main;
import com.MrVorgan.peashootersmod.init.ModItems;
import com.MrVorgan.peashootersmod.items.armor.ModelCustomArmor;
import com.MrVorgan.peashootersmod.util.IHasModel;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

public class ArmorBase
extends ItemArmor
implements IHasModel {
    public ArmorBase(String name, ItemArmor.ArmorMaterial materialIn, int renderIndexIn, EntityEquipmentSlot equipmentSlotIn) {
        super(materialIn, renderIndexIn, equipmentSlotIn);
        this.func_77655_b(name);
        this.setRegistryName(name);
        this.func_77637_a(Main.pvz_t_w);
        ModItems.ITEMS.add((Item)this);
    }

    @Override
    public void registerModels() {
        Main.proxy.registerItemRenderer((Item)this, 0, "inventory");
    }

    public ModelBiped getArmorModel(EntityLivingBase entityLiving, ItemStack itemStack, EntityEquipmentSlot armorSlot, ModelBiped _default) {
        if (itemStack != ItemStack.field_190927_a && itemStack.func_77973_b() instanceof ItemArmor) {
            ModelCustomArmor model = new ModelCustomArmor();
            model.field_78116_c.field_78806_j = armorSlot == EntityEquipmentSlot.HEAD;
            model.field_78091_s = _default.field_78091_s;
            model.field_78093_q = _default.field_78093_q;
            model.field_78117_n = _default.field_78117_n;
            model.field_187076_m = _default.field_187076_m;
            model.field_187075_l = _default.field_187075_l;
            return model;
        }
        return null;
    }
}

