/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.World
 *  net.minecraft.world.WorldType
 *  net.minecraft.world.biome.BiomeProvider
 *  net.minecraft.world.biome.BiomeProviderSingle
 */
package com.MrVorgan.peashootersmod.world.biome.types;

import com.MrVorgan.peashootersmod.init.ModBiomes;
import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeProvider;
import net.minecraft.world.biome.BiomeProviderSingle;

public class WorldTypeZomburbia
extends WorldType {
    public WorldTypeZomburbia() {
        super("zomburbia");
    }

    public BiomeProvider getBiomeProvider(World world) {
        return new BiomeProviderSingle(ModBiomes.ZOMBURBIA);
    }
}

