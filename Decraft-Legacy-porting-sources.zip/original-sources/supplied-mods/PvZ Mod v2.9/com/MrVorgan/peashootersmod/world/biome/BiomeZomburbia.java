/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.init.Blocks
 *  net.minecraft.world.biome.Biome
 *  net.minecraft.world.biome.Biome$BiomeProperties
 *  net.minecraft.world.biome.Biome$SpawnListEntry
 */
package com.MrVorgan.peashootersmod.world.biome;

import com.MrVorgan.peashootersmod.entity.EntityAllStarZombie;
import com.MrVorgan.peashootersmod.entity.EntityBucketZombie;
import com.MrVorgan.peashootersmod.entity.EntityConeZombie;
import com.MrVorgan.peashootersmod.entity.EntityFlagZombie;
import com.MrVorgan.peashootersmod.entity.EntityGargZombie;
import com.MrVorgan.peashootersmod.entity.EntityImpZombie;
import com.MrVorgan.peashootersmod.entity.EntityOutHouseZombie;
import com.MrVorgan.peashootersmod.entity.EntityPotWeed;
import com.MrVorgan.peashootersmod.entity.EntityPumpkinWeed;
import com.MrVorgan.peashootersmod.entity.EntityRegZombie;
import com.MrVorgan.peashootersmod.entity.EntityTorchWood;
import com.MrVorgan.peashootersmod.entity.EntityVaseWeed;
import com.MrVorgan.peashootersmod.entity.EntityWeed;
import com.MrVorgan.peashootersmod.entity.EntityYetiZombie;
import net.minecraft.init.Blocks;
import net.minecraft.world.biome.Biome;

public class BiomeZomburbia
extends Biome {
    public BiomeZomburbia() {
        super(new Biome.BiomeProperties("zomburbia").func_185396_a().func_185398_c(0.125f).func_185400_d(0.05f).func_185410_a(1.0f).func_185402_a(16711853));
        this.field_76752_A = Blocks.field_150391_bh.func_176223_P();
        this.field_76753_B = Blocks.field_150346_d.func_176223_P();
        this.field_82914_M.clear();
        this.field_76762_K.clear();
        this.field_76761_J.clear();
        this.field_76755_L.clear();
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityWeed.class, 6, 1, 3));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityPotWeed.class, 6, 1, 3));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityPumpkinWeed.class, 6, 1, 3));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityTorchWood.class, 1, 1, 1));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityVaseWeed.class, 1, 1, 2));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityRegZombie.class, 5, 1, 3));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityConeZombie.class, 5, 1, 2));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityBucketZombie.class, 5, 1, 1));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityGargZombie.class, 1, 1, 1));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityImpZombie.class, 2, 1, 1));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityFlagZombie.class, 1, 1, 1));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityAllStarZombie.class, 1, 1, 1));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityOutHouseZombie.class, 1, 1, 2));
        this.field_76761_J.add(new Biome.SpawnListEntry(EntityYetiZombie.class, 1, 1, 1));
    }
}

