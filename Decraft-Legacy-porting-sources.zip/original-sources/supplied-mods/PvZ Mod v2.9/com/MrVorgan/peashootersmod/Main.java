/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraftforge.fml.common.IWorldGenerator
 *  net.minecraftforge.fml.common.Mod
 *  net.minecraftforge.fml.common.Mod$EventHandler
 *  net.minecraftforge.fml.common.Mod$Instance
 *  net.minecraftforge.fml.common.SidedProxy
 *  net.minecraftforge.fml.common.event.FMLInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLPostInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLPreInitializationEvent
 *  net.minecraftforge.fml.common.registry.GameRegistry
 */
package com.MrVorgan.peashootersmod;

import com.MrVorgan.peashootersmod.init.ModRecipes;
import com.MrVorgan.peashootersmod.proxy.CommonProxy;
import com.MrVorgan.peashootersmod.tabs.PvZ_T_W;
import com.MrVorgan.peashootersmod.util.handlers.RegistryHandler;
import com.MrVorgan.peashootersmod.world.biome.ModWorldGen;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraftforge.fml.common.IWorldGenerator;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid="pm", name="Plants Vs Zombies Mod", version="2.9", acceptedMinecraftVersions="[1.12.2]")
public class Main {
    @Mod.Instance
    public static Main instance;
    public static final CreativeTabs pvz_t_w;
    @SidedProxy(clientSide="com.MrVorgan.peashootersmod.proxy.ClientProxy", serverSide="com.MrVorgan.peashootersmod.proxy.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public static void PreInit(FMLPreInitializationEvent event) {
        RegistryHandler.preInitRegistries();
        GameRegistry.registerWorldGenerator((IWorldGenerator)new ModWorldGen(), (int)3);
    }

    @Mod.EventHandler
    public static void init(FMLInitializationEvent event) {
        ModRecipes.init();
        RegistryHandler.initRegistries();
    }

    @Mod.EventHandler
    public static void Postinit(FMLPostInitializationEvent event) {
        RegistryHandler.postInitRegistries();
    }

    static {
        pvz_t_w = new PvZ_T_W("pvz_t_w");
    }
}

