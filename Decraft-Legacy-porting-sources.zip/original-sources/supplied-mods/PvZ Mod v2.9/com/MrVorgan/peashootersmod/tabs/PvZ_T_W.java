/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.item.ItemStack
 */
package com.MrVorgan.peashootersmod.tabs;

import com.MrVorgan.peashootersmod.init.ModItems;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;

public class PvZ_T_W
extends CreativeTabs {
    public PvZ_T_W(String label) {
        super("pvz_t_w");
        this.func_78025_a("sun_2.png");
    }

    public ItemStack func_78016_d() {
        return new ItemStack(ModItems.SUN);
    }
}

