/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.SoundType
 *  net.minecraft.block.material.Material
 */
package com.MrVorgan.peashootersmod.blocks;

import com.MrVorgan.peashootersmod.blocks.BlockBase;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

public class FertileDirt
extends BlockBase {
    public FertileDirt(String name, Material material) {
        super(name, material);
        this.func_149672_a(SoundType.field_185849_b);
        this.func_149711_c(0.5f);
        this.func_149752_b(4.0f);
        this.setHarvestLevel("shovel", 0);
        this.func_149715_a(0.0f);
    }
}

