/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.SoundType
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.item.Item
 */
package com.MrVorgan.peashootersmod.blocks;

import com.MrVorgan.peashootersmod.blocks.BlockBase;
import com.MrVorgan.peashootersmod.init.ModItems;
import java.util.Random;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;

public class GnomeGoldOre
extends BlockBase {
    public GnomeGoldOre(String name, Material material) {
        super(name, material);
        this.func_149672_a(SoundType.field_185851_d);
        this.func_149711_c(3.0f);
        this.func_149752_b(15.0f);
        this.setHarvestLevel("pickaxe", 3);
        this.func_149715_a(1.0f);
    }

    public Item func_180660_a(IBlockState state, Random rand, int fortune) {
        return ModItems.GNOME_GOLD;
    }

    public int func_149745_a(Random rand) {
        return 1;
    }
}

