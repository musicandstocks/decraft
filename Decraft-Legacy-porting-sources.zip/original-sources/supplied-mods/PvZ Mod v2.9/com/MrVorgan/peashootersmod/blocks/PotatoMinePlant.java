/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockCrops
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 *  net.minecraftforge.common.IPlantable
 */
package com.MrVorgan.peashootersmod.blocks;

import com.MrVorgan.peashootersmod.init.ModBlocks;
import com.MrVorgan.peashootersmod.init.ModItems;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.common.IPlantable;

public class PotatoMinePlant
extends BlockCrops {
    private static final AxisAlignedBB[] potato_mine = new AxisAlignedBB[]{new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 0.11, 1.0), new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 0.6, 1.0)};

    public PotatoMinePlant(String name) {
        this.func_149663_c(name);
        this.setRegistryName(name);
        ModBlocks.BLOCKS.add((Block)this);
        ModItems.ITEMS.add((Item)new ItemBlock((Block)this).setRegistryName(this.getRegistryName()));
    }

    public boolean func_180671_f(World worldIn, BlockPos pos, IBlockState state) {
        IBlockState soil = worldIn.func_180495_p(pos.func_177977_b());
        return (worldIn.func_175699_k(pos) >= 8 || worldIn.func_175678_i(pos)) && soil.func_177230_c().canSustainPlant(soil, (IBlockAccess)worldIn, pos.func_177977_b(), EnumFacing.UP, (IPlantable)this);
    }

    protected Item func_149866_i() {
        return ModItems.SHELL_PIECE;
    }

    protected Item func_149865_P() {
        return ModItems.SHELL_PIECE;
    }

    public Item func_180660_a(IBlockState state, Random rand, int fortune) {
        return this.func_185525_y(state) ? this.func_149865_P() : this.getSeed(ModItems.SHELL_PIECE);
    }

    public AxisAlignedBB func_185496_a(IBlockState state, IBlockAccess source, BlockPos pos) {
        return potato_mine[(Integer)state.func_177229_b((IProperty)this.func_185524_e())];
    }

    public int func_185526_g() {
        return 1;
    }

    private Item getSeed(Item shellPiece) {
        return ModItems.SHELL_PIECE;
    }
}

