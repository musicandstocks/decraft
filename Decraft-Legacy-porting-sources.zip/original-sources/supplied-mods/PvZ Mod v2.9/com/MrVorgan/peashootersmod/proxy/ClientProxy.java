/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.block.model.ModelResourceLocation
 *  net.minecraft.item.Item
 *  net.minecraftforge.client.model.ModelLoader
 */
package com.MrVorgan.peashootersmod.proxy;

import com.MrVorgan.peashootersmod.proxy.CommonProxy;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.model.ModelLoader;

public class ClientProxy
extends CommonProxy {
    @Override
    public void registerItemRenderer(Item item, int meta, String is) {
        String id = null;
        ModelLoader.setCustomModelResourceLocation((Item)item, (int)meta, (ModelResourceLocation)new ModelResourceLocation(item.getRegistryName(), id));
    }
}

