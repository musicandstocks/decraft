/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 */
package com.MrVorgan.peashootersmod.proxy;

import net.minecraft.item.Item;

public class CommonProxy {
    public void registerItemRenderer(Item item, int meta, String id) {
    }
}

