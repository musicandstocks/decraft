/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockSlab
 *  net.minecraft.block.BlockSlab$EnumBlockHalf
 *  net.minecraft.block.SoundType
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.properties.PropertyEnum
 *  net.minecraft.block.state.BlockStateContainer
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.renderer.block.model.ModelResourceLocation
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemSlab
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.IStringSerializable
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 *  net.minecraftforge.client.event.ModelRegistryEvent
 *  net.minecraftforge.client.model.ModelLoader
 *  net.minecraftforge.fml.common.registry.GameRegistry$ObjectHolder
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.mcreator.plantsvszombies.block;

import java.util.Random;
import net.mcreator.plantsvszombies.ElementsPlantsVsZombiesMod;
import net.mcreator.plantsvszombies.creativetab.TabPvZ;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.item.ItemSlab;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@ElementsPlantsVsZombiesMod.ModElement.Tag
public class BlockFlowerpot
extends ElementsPlantsVsZombiesMod.ModElement {
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:flowerpot")
    public static final Block block = null;
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:flowerpot_double")
    public static final Block block_slab_double = null;

    public BlockFlowerpot(ElementsPlantsVsZombiesMod instance) {
        super(instance, 15);
    }

    @Override
    public void initElements() {
        this.elements.blocks.add(() -> (Block)new BlockCustom().setRegistryName("flowerpot"));
        this.elements.blocks.add(() -> (Block)new BlockCustom.Double().setRegistryName("flowerpot_double"));
        this.elements.items.add(() -> (Item)new ItemSlab(block, (BlockSlab)block, (BlockSlab)block_slab_double).setRegistryName(block.getRegistryName()));
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    public void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation((Item)Item.func_150898_a((Block)block), (int)0, (ModelResourceLocation)new ModelResourceLocation("plants_vs_zombies_:flowerpot", "inventory"));
    }

    public static class BlockCustom
    extends BlockSlab {
        public static final PropertyEnum<Variant> VARIANT = PropertyEnum.func_177709_a((String)"variant", Variant.class);

        public BlockCustom() {
            super(Material.field_151576_e);
            this.func_149663_c("flowerpot");
            this.func_149672_a(SoundType.field_185849_b);
            this.func_149711_c(1.0f);
            this.func_149752_b(10.0f);
            this.func_149715_a(0.0f);
            this.func_149713_g(255);
            this.func_149647_a(TabPvZ.tab);
            IBlockState state = this.field_176227_L.func_177621_b().func_177226_a(VARIANT, (Comparable)((Object)Variant.DEFAULT));
            if (!this.func_176552_j()) {
                state = state.func_177226_a((IProperty)BlockSlab.field_176554_a, (Comparable)BlockSlab.EnumBlockHalf.BOTTOM);
            }
            this.func_180632_j(state);
            this.field_149783_u = !this.func_176552_j();
        }

        public Item func_180660_a(IBlockState state, Random rand, int fortune) {
            return Item.func_150898_a((Block)block);
        }

        public ItemStack func_185473_a(World worldIn, BlockPos pos, IBlockState state) {
            return new ItemStack(block);
        }

        protected BlockStateContainer func_180661_e() {
            return this.func_176552_j() ? new BlockStateContainer((Block)this, new IProperty[]{VARIANT}) : new BlockStateContainer((Block)this, new IProperty[]{field_176554_a, VARIANT});
        }

        public IBlockState func_176203_a(int meta) {
            if (this.func_176552_j()) {
                return this.func_176223_P();
            }
            return this.func_176223_P().func_177226_a((IProperty)field_176554_a, (Comparable)BlockSlab.EnumBlockHalf.values()[meta % 2]);
        }

        public int func_176201_c(IBlockState state) {
            if (this.func_176552_j()) {
                return 0;
            }
            return ((BlockSlab.EnumBlockHalf)state.func_177229_b((IProperty)field_176554_a)).ordinal();
        }

        public String func_150002_b(int meta) {
            return super.func_149739_a();
        }

        public IProperty<?> func_176551_l() {
            return VARIANT;
        }

        public Comparable<?> func_185674_a(ItemStack stack) {
            return Variant.DEFAULT;
        }

        public boolean func_176552_j() {
            return false;
        }

        public boolean doesSideBlockRendering(IBlockState state, IBlockAccess world, BlockPos pos, EnumFacing face) {
            if (this.func_176552_j()) {
                return true;
            }
            return super.doesSideBlockRendering(state, world, pos, face);
        }

        public static class Double
        extends BlockCustom {
            @Override
            public boolean func_176552_j() {
                return true;
            }
        }

        public static enum Variant implements IStringSerializable
        {
            DEFAULT;


            public String func_176610_l() {
                return "default";
            }
        }
    }
}

