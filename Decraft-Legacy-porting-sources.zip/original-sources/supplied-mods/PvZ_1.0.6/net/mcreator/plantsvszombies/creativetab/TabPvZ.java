/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.mcreator.plantsvszombies.creativetab;

import net.mcreator.plantsvszombies.ElementsPlantsVsZombiesMod;
import net.mcreator.plantsvszombies.item.ItemPeapode;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@ElementsPlantsVsZombiesMod.ModElement.Tag
public class TabPvZ
extends ElementsPlantsVsZombiesMod.ModElement {
    public static CreativeTabs tab;

    public TabPvZ(ElementsPlantsVsZombiesMod instance) {
        super(instance, 18);
    }

    @Override
    public void initElements() {
        tab = new CreativeTabs("tabpv_z"){

            @SideOnly(value=Side.CLIENT)
            public ItemStack func_78016_d() {
                return new ItemStack(ItemPeapode.block, 1);
            }

            @SideOnly(value=Side.CLIENT)
            public boolean hasSearchBar() {
                return false;
            }
        };
    }
}

