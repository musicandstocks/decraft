/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  net.minecraft.client.Minecraft
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.world.World
 *  net.minecraft.world.storage.WorldSavedData
 *  net.minecraftforge.fml.common.network.ByteBufUtils
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler
 *  net.minecraftforge.fml.common.network.simpleimpl.MessageContext
 *  net.minecraftforge.fml.relauncher.Side
 */
package net.mcreator.plantsvszombies;

import io.netty.buffer.ByteBuf;
import net.mcreator.plantsvszombies.PlantsVsZombiesMod;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;

public class PlantsVsZombiesModVariables {

    public static class WorldSavedDataSyncMessage
    implements IMessage {
        public int type;
        public WorldSavedData data;

        public WorldSavedDataSyncMessage() {
        }

        public WorldSavedDataSyncMessage(int type, WorldSavedData data) {
            this.type = type;
            this.data = data;
        }

        public void toBytes(ByteBuf buf) {
            buf.writeInt(this.type);
            ByteBufUtils.writeTag((ByteBuf)buf, (NBTTagCompound)this.data.func_189551_b(new NBTTagCompound()));
        }

        public void fromBytes(ByteBuf buf) {
            this.type = buf.readInt();
            this.data = this.type == 0 ? new MapVariables() : new WorldVariables();
            this.data.func_76184_a(ByteBufUtils.readTag((ByteBuf)buf));
        }
    }

    public static class WorldSavedDataSyncMessageHandler
    implements IMessageHandler<WorldSavedDataSyncMessage, IMessage> {
        public IMessage onMessage(WorldSavedDataSyncMessage message, MessageContext context) {
            if (context.side == Side.SERVER) {
                context.getServerHandler().field_147369_b.func_71121_q().func_152344_a(() -> this.syncData(message, context, context.getServerHandler().field_147369_b.field_70170_p));
            } else {
                Minecraft.func_71410_x().func_152344_a(() -> this.syncData(message, context, Minecraft.func_71410_x().field_71439_g.field_70170_p));
            }
            return null;
        }

        private void syncData(WorldSavedDataSyncMessage message, MessageContext context, World world) {
            if (context.side == Side.SERVER) {
                message.data.func_76185_a();
                if (message.type == 0) {
                    PlantsVsZombiesMod.PACKET_HANDLER.sendToAll((IMessage)message);
                } else {
                    PlantsVsZombiesMod.PACKET_HANDLER.sendToDimension((IMessage)message, world.field_73011_w.getDimension());
                }
            }
            if (message.type == 0) {
                world.func_175693_T().func_75745_a("plants_vs_zombies__mapvars", message.data);
            } else {
                world.getPerWorldStorage().func_75745_a("plants_vs_zombies__worldvars", message.data);
            }
        }
    }

    public static class WorldVariables
    extends WorldSavedData {
        public static final String DATA_NAME = "plants_vs_zombies__worldvars";

        public WorldVariables() {
            super(DATA_NAME);
        }

        public WorldVariables(String s) {
            super(s);
        }

        public void func_76184_a(NBTTagCompound nbt) {
        }

        public NBTTagCompound func_189551_b(NBTTagCompound nbt) {
            return nbt;
        }

        public void syncData(World world) {
            this.func_76185_a();
            if (world.field_72995_K) {
                PlantsVsZombiesMod.PACKET_HANDLER.sendToServer((IMessage)new WorldSavedDataSyncMessage(1, this));
            } else {
                PlantsVsZombiesMod.PACKET_HANDLER.sendToDimension((IMessage)new WorldSavedDataSyncMessage(1, this), world.field_73011_w.getDimension());
            }
        }

        public static WorldVariables get(World world) {
            WorldVariables instance = (WorldVariables)world.getPerWorldStorage().func_75742_a(WorldVariables.class, DATA_NAME);
            if (instance == null) {
                instance = new WorldVariables();
                world.getPerWorldStorage().func_75745_a(DATA_NAME, (WorldSavedData)instance);
            }
            return instance;
        }
    }

    public static class MapVariables
    extends WorldSavedData {
        public static final String DATA_NAME = "plants_vs_zombies__mapvars";

        public MapVariables() {
            super(DATA_NAME);
        }

        public MapVariables(String s) {
            super(s);
        }

        public void func_76184_a(NBTTagCompound nbt) {
        }

        public NBTTagCompound func_189551_b(NBTTagCompound nbt) {
            return nbt;
        }

        public void syncData(World world) {
            this.func_76185_a();
            if (world.field_72995_K) {
                PlantsVsZombiesMod.PACKET_HANDLER.sendToServer((IMessage)new WorldSavedDataSyncMessage(0, this));
            } else {
                PlantsVsZombiesMod.PACKET_HANDLER.sendToAll((IMessage)new WorldSavedDataSyncMessage(0, this));
            }
        }

        public static MapVariables get(World world) {
            MapVariables instance = (MapVariables)world.func_175693_T().func_75742_a(MapVariables.class, DATA_NAME);
            if (instance == null) {
                instance = new MapVariables();
                world.func_175693_T().func_75745_a(DATA_NAME, (WorldSavedData)instance);
            }
            return instance;
        }
    }
}

