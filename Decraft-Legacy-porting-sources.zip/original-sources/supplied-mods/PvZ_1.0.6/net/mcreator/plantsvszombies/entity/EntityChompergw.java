/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelBox
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityCreature
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.entity.EnumCreatureAttribute
 *  net.minecraft.entity.EnumCreatureType
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.EntityAIAttackMelee
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.ai.EntityAILookIdle
 *  net.minecraft.entity.ai.EntityAINearestAttackableTarget
 *  net.minecraft.entity.ai.EntityAIWanderAvoidWater
 *  net.minecraft.entity.monster.EntityMob
 *  net.minecraft.entity.monster.EntityZombie
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.SoundEvent
 *  net.minecraft.world.World
 *  net.minecraft.world.biome.Biome
 *  net.minecraftforge.fml.client.registry.RenderingRegistry
 *  net.minecraftforge.fml.common.event.FMLInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLPreInitializationEvent
 *  net.minecraftforge.fml.common.registry.EntityEntryBuilder
 *  net.minecraftforge.fml.common.registry.EntityRegistry
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.mcreator.plantsvszombies.entity;

import net.mcreator.plantsvszombies.ElementsPlantsVsZombiesMod;
import net.minecraft.block.Block;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@ElementsPlantsVsZombiesMod.ModElement.Tag
public class EntityChompergw
extends ElementsPlantsVsZombiesMod.ModElement {
    public static final int ENTITYID = 12;
    public static final int ENTITYID_RANGED = 13;

    public EntityChompergw(ElementsPlantsVsZombiesMod instance) {
        super(instance, 25);
    }

    @Override
    public void initElements() {
        this.elements.entities.add(() -> EntityEntryBuilder.create().entity(EntityCustom.class).id(new ResourceLocation("plants_vs_zombies_", "chompergw"), 12).name("chompergw").tracker(54, 3, true).egg(-10092442, -16751053).build());
    }

    @Override
    public void init(FMLInitializationEvent event) {
        Biome[] spawnBiomes = new Biome[]{(Biome)Biome.field_185377_q.func_82594_a((Object)new ResourceLocation("plains")), (Biome)Biome.field_185377_q.func_82594_a((Object)new ResourceLocation("forest")), (Biome)Biome.field_185377_q.func_82594_a((Object)new ResourceLocation("jungle")), (Biome)Biome.field_185377_q.func_82594_a((Object)new ResourceLocation("jungle_hills"))};
        EntityRegistry.addSpawn(EntityCustom.class, (int)1, (int)1, (int)1, (EnumCreatureType)EnumCreatureType.CREATURE, (Biome[])spawnBiomes);
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    public void preInit(FMLPreInitializationEvent event) {
        RenderingRegistry.registerEntityRenderingHandler(EntityCustom.class, renderManager -> new RenderLiving(renderManager, new ModelChomper(), 0.4f){

            protected ResourceLocation func_110775_a(Entity entity) {
                return new ResourceLocation("plants_vs_zombies_:textures/chompergw.png");
            }
        });
    }

    public static class ModelChomper
    extends ModelBase {
        private final ModelRenderer bb_main;

        public ModelChomper() {
            this.field_78090_t = 64;
            this.field_78089_u = 64;
            this.bb_main = new ModelRenderer((ModelBase)this);
            this.bb_main.func_78793_a(0.0f, 24.0f, 0.0f);
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 23, 50, -2.0f, -8.0f, 1.0f, 1, 5, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 24, 49, -2.0f, -12.0f, 2.0f, 1, 4, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 0, 50, -3.0f, -13.0f, 0.0f, 3, 1, 4, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 2, 13, -6.0f, -15.0f, -3.0f, 9, 2, 7, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 2, 2, -6.0f, -23.0f, -3.0f, 9, 2, 7, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 34, 48, -5.0f, -21.0f, -2.0f, 7, 1, 6, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 28, 1, -6.0f, -22.0f, -5.0f, 9, 2, 3, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 22, 22, -6.0f, -16.0f, -5.0f, 9, 1, 4, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 7, 8, -6.0f, -15.0f, -5.0f, 9, 1, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 0, 22, -6.0f, -23.0f, 4.0f, 9, 10, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 46, 46, -5.0f, -22.0f, 3.0f, 7, 8, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 50, 43, 2.0f, -22.0f, -1.0f, 0, 8, 5, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 50, 43, -5.0f, -22.0f, -1.0f, 0, 8, 5, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 46, 46, -5.0f, -22.0f, 3.0f, 7, 7, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 39, 49, -5.0f, -16.0f, -1.0f, 7, 1, 5, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 31, 6, -6.0f, -21.0f, -1.0f, 0, 6, 5, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 53, 27, -6.0f, -21.0f, -2.0f, 1, 6, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 53, 27, 2.0f, -21.0f, -2.0f, 1, 6, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 15, 5, 2.0f, -21.0f, -1.0f, 1, 6, 5, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 20, 50, -4.0f, -4.0f, -1.0f, 2, 4, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 22, 51, -4.0f, -4.0f, 2.0f, 2, 4, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 20, 50, -1.0f, -4.0f, 2.0f, 2, 4, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 22, 52, -1.0f, -4.0f, -1.0f, 2, 4, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 34, 33, -2.0f, -24.0f, 4.0f, 1, 2, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 4, 6, -2.0f, -22.0f, 6.0f, 1, 2, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 0, 6, -2.0f, -19.0f, 6.0f, 1, 2, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 30, 7, -2.0f, -17.0f, -5.0f, 1, 1, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 27, 13, 0.0f, -17.0f, -5.0f, 1, 1, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 22, 24, 2.0f, -17.0f, -4.0f, 1, 1, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 20, 22, -6.0f, -17.0f, -4.0f, 1, 1, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 27, 0, 1.0f, -20.0f, -5.0f, 1, 1, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 0, 17, 2.0f, -20.0f, -3.0f, 1, 1, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 27, 11, -3.0f, -20.0f, -5.0f, 1, 1, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 27, 6, -5.0f, -20.0f, -5.0f, 1, 1, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 4, 17, -6.0f, -20.0f, -3.0f, 1, 1, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 27, 2, -1.0f, -20.0f, -5.0f, 1, 1, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 29, 28, -4.0f, -17.0f, -5.0f, 1, 1, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 16, 34, -2.0f, -25.0f, 1.0f, 1, 3, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 27, 15, -2.0f, -26.0f, -2.0f, 1, 3, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 55, 14, -2.0f, -18.0f, 1.0f, 1, 1, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 53, 14, -2.0f, -19.0f, -1.0f, 1, 1, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 56, 13, -2.0f, -18.0f, -3.0f, 1, 1, 2, 0.0f, false));
        }

        public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
            this.bb_main.func_78785_a(f5);
        }

        public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
            modelRenderer.field_78795_f = x;
            modelRenderer.field_78796_g = y;
            modelRenderer.field_78808_h = z;
        }

        public void func_78087_a(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
            super.func_78087_a(f, f1, f2, f3, f4, f5, e);
        }
    }

    public static class EntityCustom
    extends EntityMob {
        public EntityCustom(World world) {
            super(world);
            this.func_70105_a(0.5f, 1.6f);
            this.field_70728_aV = 0;
            this.field_70178_ae = false;
            this.func_94061_f(false);
        }

        protected void func_184651_r() {
            super.func_184651_r();
            this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, EntityZombie.class, true, false));
            this.field_70714_bg.func_75776_a(2, (EntityAIBase)new EntityAIAttackMelee((EntityCreature)this, 1.2, false));
            this.field_70714_bg.func_75776_a(3, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
            this.field_70714_bg.func_75776_a(4, (EntityAIBase)new EntityAIWanderAvoidWater((EntityCreature)this, 0.8));
        }

        public EnumCreatureAttribute func_70668_bt() {
            return EnumCreatureAttribute.UNDEFINED;
        }

        protected Item func_146068_u() {
            return new ItemStack((Block)Blocks.field_150328_O, 1, 2).func_77973_b();
        }

        public SoundEvent func_184639_G() {
            return (SoundEvent)SoundEvent.field_187505_a.func_82594_a((Object)new ResourceLocation(""));
        }

        public SoundEvent func_184601_bQ(DamageSource ds) {
            return (SoundEvent)SoundEvent.field_187505_a.func_82594_a((Object)new ResourceLocation("entity.generic.hurt"));
        }

        public SoundEvent func_184615_bR() {
            return (SoundEvent)SoundEvent.field_187505_a.func_82594_a((Object)new ResourceLocation("entity.generic.death"));
        }

        protected float func_70599_aP() {
            return 1.0f;
        }

        protected void func_110147_ax() {
            super.func_110147_ax();
            if (this.func_110148_a(SharedMonsterAttributes.field_188791_g) != null) {
                this.func_110148_a(SharedMonsterAttributes.field_188791_g).func_111128_a(0.0);
            }
            if (this.func_110148_a(SharedMonsterAttributes.field_111263_d) != null) {
                this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.3);
            }
            if (this.func_110148_a(SharedMonsterAttributes.field_111267_a) != null) {
                this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(10.0);
            }
            if (this.func_110148_a(SharedMonsterAttributes.field_111264_e) != null) {
                this.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a(7.0);
            }
        }
    }
}

