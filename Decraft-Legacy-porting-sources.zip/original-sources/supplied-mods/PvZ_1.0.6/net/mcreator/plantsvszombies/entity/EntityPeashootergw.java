/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelBox
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.client.renderer.entity.RenderLiving
 *  net.minecraft.client.renderer.entity.RenderSnowball
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityCreature
 *  net.minecraft.entity.EntityLiving
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.EnumCreatureAttribute
 *  net.minecraft.entity.EnumCreatureType
 *  net.minecraft.entity.IRangedAttackMob
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.EntityAIAttackRanged
 *  net.minecraft.entity.ai.EntityAIBase
 *  net.minecraft.entity.ai.EntityAILookIdle
 *  net.minecraft.entity.ai.EntityAINearestAttackableTarget
 *  net.minecraft.entity.ai.EntityAIWanderAvoidWater
 *  net.minecraft.entity.monster.EntityZombie
 *  net.minecraft.entity.projectile.EntityTippedArrow
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.SoundEvent
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.world.World
 *  net.minecraft.world.biome.Biome
 *  net.minecraftforge.fml.client.registry.RenderingRegistry
 *  net.minecraftforge.fml.common.event.FMLInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLPreInitializationEvent
 *  net.minecraftforge.fml.common.registry.EntityEntryBuilder
 *  net.minecraftforge.fml.common.registry.EntityRegistry
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.mcreator.plantsvszombies.entity;

import net.mcreator.plantsvszombies.ElementsPlantsVsZombiesMod;
import net.mcreator.plantsvszombies.item.ItemPeapode;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderSnowball;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackRanged;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@ElementsPlantsVsZombiesMod.ModElement.Tag
public class EntityPeashootergw
extends ElementsPlantsVsZombiesMod.ModElement {
    public static final int ENTITYID = 8;
    public static final int ENTITYID_RANGED = 9;

    public EntityPeashootergw(ElementsPlantsVsZombiesMod instance) {
        super(instance, 16);
    }

    @Override
    public void initElements() {
        this.elements.entities.add(() -> EntityEntryBuilder.create().entity(EntityCustom.class).id(new ResourceLocation("plants_vs_zombies_", "peashootergw"), 8).name("peashootergw").tracker(64, 3, true).egg(-16738048, -6697984).build());
        this.elements.entities.add(() -> EntityEntryBuilder.create().entity(EntityArrowCustom.class).id(new ResourceLocation("plants_vs_zombies_", "entitybulletpeashootergw"), 9).name("entitybulletpeashootergw").tracker(64, 1, true).build());
    }

    @Override
    public void init(FMLInitializationEvent event) {
        Biome[] spawnBiomes = new Biome[]{(Biome)Biome.field_185377_q.func_82594_a((Object)new ResourceLocation("forest")), (Biome)Biome.field_185377_q.func_82594_a((Object)new ResourceLocation("plains"))};
        EntityRegistry.addSpawn(EntityCustom.class, (int)1, (int)1, (int)1, (EnumCreatureType)EnumCreatureType.CREATURE, (Biome[])spawnBiomes);
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    public void preInit(FMLPreInitializationEvent event) {
        RenderingRegistry.registerEntityRenderingHandler(EntityCustom.class, renderManager -> new RenderLiving(renderManager, new ModelPegw(), 0.5f){

            protected ResourceLocation func_110775_a(Entity entity) {
                return new ResourceLocation("plants_vs_zombies_:textures/gw2.png");
            }
        });
        RenderingRegistry.registerEntityRenderingHandler(EntityArrowCustom.class, renderManager -> new RenderSnowball<EntityArrowCustom>(renderManager, null, Minecraft.func_71410_x().func_175599_af()){

            public ItemStack getStackToRender(EntityArrowCustom entity) {
                return new ItemStack(ItemPeapode.block, 1);
            }
        });
    }

    public static class ModelPegw
    extends ModelBase {
        private final ModelRenderer bb_main;

        public ModelPegw() {
            this.field_78090_t = 64;
            this.field_78089_u = 64;
            this.bb_main = new ModelRenderer((ModelBase)this);
            this.bb_main.func_78793_a(0.0f, 24.0f, 0.0f);
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 3, 22, -2.0f, -15.0f, 1.0f, 1, 12, 1, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 2, 1, -6.0f, -22.0f, -3.0f, 9, 9, 9, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 11, 20, -4.0f, -18.0f, -6.0f, 5, 5, 3, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 28, 25, -4.0f, -23.0f, 6.0f, 5, 1, 4, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 0, 0, -4.0f, -4.0f, -1.0f, 2, 4, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 0, 0, -4.0f, -4.0f, 2.0f, 2, 4, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 0, 0, -1.0f, -4.0f, 2.0f, 2, 4, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 0, 0, -1.0f, -4.0f, -1.0f, 2, 4, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 24, 29, 0.0f, -9.0f, 2.0f, 1, 2, 5, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 12, 28, -4.0f, -10.0f, 2.0f, 1, 2, 5, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 0, 0, -1.0f, -8.0f, 1.0f, 1, 1, 2, 0.0f, false));
            this.bb_main.field_78804_l.add(new ModelBox(this.bb_main, 0, 0, -3.0f, -9.0f, 1.0f, 1, 1, 2, 0.0f, false));
        }

        public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
            this.bb_main.func_78785_a(f5);
        }

        public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
            modelRenderer.field_78795_f = x;
            modelRenderer.field_78796_g = y;
            modelRenderer.field_78808_h = z;
        }

        public void func_78087_a(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
            super.func_78087_a(f, f1, f2, f3, f4, f5, e);
        }
    }

    public static class EntityArrowCustom
    extends EntityTippedArrow {
        public EntityArrowCustom(World a) {
            super(a);
        }

        public EntityArrowCustom(World worldIn, double x, double y, double z) {
            super(worldIn, x, y, z);
        }

        public EntityArrowCustom(World worldIn, EntityLivingBase shooter) {
            super(worldIn, shooter);
        }
    }

    public static class EntityCustom
    extends EntityCreature
    implements IRangedAttackMob {
        public EntityCustom(World world) {
            super(world);
            this.func_70105_a(0.6f, 1.5f);
            this.field_70728_aV = 0;
            this.field_70178_ae = false;
            this.func_94061_f(false);
            this.func_110163_bv();
        }

        protected void func_184651_r() {
            super.func_184651_r();
            this.field_70714_bg.func_75776_a(1, (EntityAIBase)new EntityAIWanderAvoidWater((EntityCreature)this, 0.8));
            this.field_70714_bg.func_75776_a(2, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
            this.field_70715_bh.func_75776_a(3, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, EntityZombie.class, false, false));
            this.field_70714_bg.func_75776_a(1, (EntityAIBase)new EntityAIAttackRanged((IRangedAttackMob)this, 1.25, 20, 10.0f));
        }

        public EnumCreatureAttribute func_70668_bt() {
            return EnumCreatureAttribute.UNDEFINED;
        }

        protected boolean func_70692_ba() {
            return false;
        }

        protected Item func_146068_u() {
            return null;
        }

        public SoundEvent func_184639_G() {
            return (SoundEvent)SoundEvent.field_187505_a.func_82594_a((Object)new ResourceLocation(""));
        }

        public SoundEvent func_184601_bQ(DamageSource ds) {
            return (SoundEvent)SoundEvent.field_187505_a.func_82594_a((Object)new ResourceLocation("entity.generic.hurt"));
        }

        public SoundEvent func_184615_bR() {
            return (SoundEvent)SoundEvent.field_187505_a.func_82594_a((Object)new ResourceLocation("entity.generic.death"));
        }

        protected float func_70599_aP() {
            return 1.0f;
        }

        protected void func_110147_ax() {
            super.func_110147_ax();
            if (this.func_110148_a(SharedMonsterAttributes.field_188791_g) != null) {
                this.func_110148_a(SharedMonsterAttributes.field_188791_g).func_111128_a(0.0);
            }
            if (this.func_110148_a(SharedMonsterAttributes.field_111263_d) != null) {
                this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.3);
            }
            if (this.func_110148_a(SharedMonsterAttributes.field_111267_a) != null) {
                this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(10.0);
            }
            if (this.func_110148_a(SharedMonsterAttributes.field_111264_e) != null) {
                this.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a(3.0);
            }
        }

        public void func_184724_a(boolean swingingArms) {
        }

        public void func_82196_d(EntityLivingBase target, float flval) {
            EntityArrowCustom entityarrow = new EntityArrowCustom(this.field_70170_p, (EntityLivingBase)this);
            double d0 = target.field_70163_u + (double)target.func_70047_e() - 1.1;
            double d1 = target.field_70165_t - this.field_70165_t;
            double d3 = target.field_70161_v - this.field_70161_v;
            entityarrow.func_70186_c(d1, d0 - entityarrow.field_70163_u + (double)MathHelper.func_76133_a((double)(d1 * d1 + d3 * d3)) * (double)0.2f, d3, 1.6f, 12.0f);
            this.field_70170_p.func_72838_d((Entity)entityarrow);
        }
    }
}

