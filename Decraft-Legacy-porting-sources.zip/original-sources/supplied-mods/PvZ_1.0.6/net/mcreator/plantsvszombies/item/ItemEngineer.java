/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.block.model.ModelResourceLocation
 *  net.minecraft.inventory.EntityEquipmentSlot
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemArmor$ArmorMaterial
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.SoundEvent
 *  net.minecraftforge.client.event.ModelRegistryEvent
 *  net.minecraftforge.client.model.ModelLoader
 *  net.minecraftforge.common.util.EnumHelper
 *  net.minecraftforge.fml.common.registry.GameRegistry$ObjectHolder
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.mcreator.plantsvszombies.item;

import net.mcreator.plantsvszombies.ElementsPlantsVsZombiesMod;
import net.mcreator.plantsvszombies.creativetab.TabPvZ;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@ElementsPlantsVsZombiesMod.ModElement.Tag
public class ItemEngineer
extends ElementsPlantsVsZombiesMod.ModElement {
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:engineerhelmet")
    public static final Item helmet = null;
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:engineerbody")
    public static final Item body = null;
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:engineerlegs")
    public static final Item legs = null;
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:engineerboots")
    public static final Item boots = null;

    public ItemEngineer(ElementsPlantsVsZombiesMod instance) {
        super(instance, 9);
    }

    @Override
    public void initElements() {
        ItemArmor.ArmorMaterial enuma = EnumHelper.addArmorMaterial((String)"ENGINEER", (String)"plants_vs_zombies_:engineerhelmet", (int)25, (int[])new int[]{0, 0, 6, 6}, (int)9, (SoundEvent)((SoundEvent)SoundEvent.field_187505_a.func_82594_a((Object)new ResourceLocation(""))), (float)0.0f);
        this.elements.items.add(() -> ((Item)new ItemArmor(enuma, 0, EntityEquipmentSlot.HEAD).func_77655_b("engineerhelmet").setRegistryName("engineerhelmet")).func_77637_a(TabPvZ.tab));
        this.elements.items.add(() -> ((Item)new ItemArmor(enuma, 0, EntityEquipmentSlot.CHEST).func_77655_b("engineerbody").setRegistryName("engineerbody")).func_77637_a(TabPvZ.tab));
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    public void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation((Item)helmet, (int)0, (ModelResourceLocation)new ModelResourceLocation("plants_vs_zombies_:engineerhelmet", "inventory"));
        ModelLoader.setCustomModelResourceLocation((Item)body, (int)0, (ModelResourceLocation)new ModelResourceLocation("plants_vs_zombies_:engineerbody", "inventory"));
    }
}

