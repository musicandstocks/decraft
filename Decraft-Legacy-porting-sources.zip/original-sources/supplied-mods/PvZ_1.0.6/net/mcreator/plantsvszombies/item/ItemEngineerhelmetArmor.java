/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.block.model.ModelResourceLocation
 *  net.minecraft.inventory.EntityEquipmentSlot
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemArmor$ArmorMaterial
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.SoundEvent
 *  net.minecraftforge.client.event.ModelRegistryEvent
 *  net.minecraftforge.client.model.ModelLoader
 *  net.minecraftforge.common.util.EnumHelper
 *  net.minecraftforge.fml.common.registry.GameRegistry$ObjectHolder
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.mcreator.plantsvszombies.item;

import net.mcreator.plantsvszombies.ElementsPlantsVsZombiesMod;
import net.mcreator.plantsvszombies.creativetab.TabPvZ;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@ElementsPlantsVsZombiesMod.ModElement.Tag
public class ItemEngineerhelmetArmor
extends ElementsPlantsVsZombiesMod.ModElement {
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:engineerhelmet_armorhelmet")
    public static final Item helmet = null;
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:engineerhelmet_armorbody")
    public static final Item body = null;
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:engineerhelmet_armorlegs")
    public static final Item legs = null;
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:engineerhelmet_armorboots")
    public static final Item boots = null;

    public ItemEngineerhelmetArmor(ElementsPlantsVsZombiesMod instance) {
        super(instance, 10);
    }

    @Override
    public void initElements() {
        ItemArmor.ArmorMaterial enuma = EnumHelper.addArmorMaterial((String)"ENGINEERHELMET_ARMOR", (String)"plants_vs_zombies_:engineerhelmet", (int)30, (int[])new int[]{4, 12, 10, 4}, (int)18, (SoundEvent)((SoundEvent)SoundEvent.field_187505_a.func_82594_a((Object)new ResourceLocation(""))), (float)0.0f);
        this.elements.items.add(() -> ((Item)new ItemArmor(enuma, 0, EntityEquipmentSlot.HEAD).func_77655_b("engineerhelmet_armorhelmet").setRegistryName("engineerhelmet_armorhelmet")).func_77637_a(TabPvZ.tab));
        this.elements.items.add(() -> ((Item)new ItemArmor(enuma, 0, EntityEquipmentSlot.CHEST).func_77655_b("engineerhelmet_armorbody").setRegistryName("engineerhelmet_armorbody")).func_77637_a(TabPvZ.tab));
        this.elements.items.add(() -> ((Item)new ItemArmor(enuma, 0, EntityEquipmentSlot.LEGS).func_77655_b("engineerhelmet_armorlegs").setRegistryName("engineerhelmet_armorlegs")).func_77637_a(TabPvZ.tab));
        this.elements.items.add(() -> ((Item)new ItemArmor(enuma, 0, EntityEquipmentSlot.FEET).func_77655_b("engineerhelmet_armorboots").setRegistryName("engineerhelmet_armorboots")).func_77637_a(TabPvZ.tab));
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    public void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation((Item)helmet, (int)0, (ModelResourceLocation)new ModelResourceLocation("plants_vs_zombies_:engineerhelmet_armorhelmet", "inventory"));
        ModelLoader.setCustomModelResourceLocation((Item)body, (int)0, (ModelResourceLocation)new ModelResourceLocation("plants_vs_zombies_:engineerhelmet_armorbody", "inventory"));
        ModelLoader.setCustomModelResourceLocation((Item)legs, (int)0, (ModelResourceLocation)new ModelResourceLocation("plants_vs_zombies_:engineerhelmet_armorlegs", "inventory"));
        ModelLoader.setCustomModelResourceLocation((Item)boots, (int)0, (ModelResourceLocation)new ModelResourceLocation("plants_vs_zombies_:engineerhelmet_armorboots", "inventory"));
    }
}

