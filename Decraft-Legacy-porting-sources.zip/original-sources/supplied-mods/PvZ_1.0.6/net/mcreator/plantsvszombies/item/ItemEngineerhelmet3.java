/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.renderer.block.model.ModelResourceLocation
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.client.event.ModelRegistryEvent
 *  net.minecraftforge.client.model.ModelLoader
 *  net.minecraftforge.fml.common.registry.GameRegistry$ObjectHolder
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.mcreator.plantsvszombies.item;

import net.mcreator.plantsvszombies.ElementsPlantsVsZombiesMod;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@ElementsPlantsVsZombiesMod.ModElement.Tag
public class ItemEngineerhelmet3
extends ElementsPlantsVsZombiesMod.ModElement {
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:engineerhelmet_3")
    public static final Item block = null;

    public ItemEngineerhelmet3(ElementsPlantsVsZombiesMod instance) {
        super(instance, 9);
    }

    @Override
    public void initElements() {
        this.elements.items.add(() -> new ItemCustom());
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    public void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation((Item)block, (int)0, (ModelResourceLocation)new ModelResourceLocation("plants_vs_zombies_:engineerhelmet_3", "inventory"));
    }

    public static class ItemCustom
    extends Item {
        public ItemCustom() {
            this.func_77656_e(0);
            this.field_77777_bU = 64;
            this.func_77655_b("engineerhelmet_3");
            this.setRegistryName("engineerhelmet_3");
            this.func_77637_a(null);
        }

        public int func_77619_b() {
            return 0;
        }

        public int func_77626_a(ItemStack itemstack) {
            return 0;
        }

        public float func_150893_a(ItemStack par1ItemStack, IBlockState par2Block) {
            return 1.0f;
        }
    }
}

