/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.block.model.ModelResourceLocation
 *  net.minecraft.client.renderer.entity.RenderSnowball
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.entity.projectile.EntityArrow$PickupStatus
 *  net.minecraft.entity.projectile.EntityTippedArrow
 *  net.minecraft.item.EnumAction
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.ActionResult
 *  net.minecraft.util.EnumActionResult
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.SoundCategory
 *  net.minecraft.util.SoundEvent
 *  net.minecraft.world.World
 *  net.minecraftforge.client.event.ModelRegistryEvent
 *  net.minecraftforge.client.model.ModelLoader
 *  net.minecraftforge.fml.client.registry.RenderingRegistry
 *  net.minecraftforge.fml.common.event.FMLPreInitializationEvent
 *  net.minecraftforge.fml.common.registry.EntityEntryBuilder
 *  net.minecraftforge.fml.common.registry.GameRegistry$ObjectHolder
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package net.mcreator.plantsvszombies.item;

import net.mcreator.plantsvszombies.ElementsPlantsVsZombiesMod;
import net.mcreator.plantsvszombies.creativetab.TabPvZ;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.entity.RenderSnowball;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.World;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@ElementsPlantsVsZombiesMod.ModElement.Tag
public class ItemSpike
extends ElementsPlantsVsZombiesMod.ModElement {
    @GameRegistry.ObjectHolder(value="plants_vs_zombies_:spike")
    public static final Item block = null;
    public static final int ENTITYID = 16;

    public ItemSpike(ElementsPlantsVsZombiesMod instance) {
        super(instance, 27);
    }

    @Override
    public void initElements() {
        this.elements.items.add(() -> new RangedItem());
        this.elements.entities.add(() -> EntityEntryBuilder.create().entity(EntityArrowCustom.class).id(new ResourceLocation("plants_vs_zombies_", "entitybulletspike"), 16).name("entitybulletspike").tracker(64, 1, true).build());
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    public void registerModels(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation((Item)block, (int)0, (ModelResourceLocation)new ModelResourceLocation("plants_vs_zombies_:spike", "inventory"));
    }

    @Override
    @SideOnly(value=Side.CLIENT)
    public void preInit(FMLPreInitializationEvent event) {
        RenderingRegistry.registerEntityRenderingHandler(EntityArrowCustom.class, renderManager -> new RenderSnowball(renderManager, new ItemStack(block, 1).func_77973_b(), Minecraft.func_71410_x().func_175599_af()));
    }

    public static class EntityArrowCustom
    extends EntityTippedArrow {
        public EntityArrowCustom(World a) {
            super(a);
        }

        public EntityArrowCustom(World worldIn, double x, double y, double z) {
            super(worldIn, x, y, z);
        }

        public EntityArrowCustom(World worldIn, EntityLivingBase shooter) {
            super(worldIn, shooter);
        }

        protected void func_184548_a(EntityLivingBase entity) {
            super.func_184548_a(entity);
            entity.func_85034_r(entity.func_85035_bI() - 1);
        }

        public void func_70071_h_() {
            super.func_70071_h_();
            int x = (int)this.field_70165_t;
            int y = (int)this.field_70163_u;
            int z = (int)this.field_70161_v;
            World world = this.field_70170_p;
            Entity entity = this.field_70250_c;
            if (this.field_70254_i) {
                this.field_70170_p.func_72900_e((Entity)this);
            }
        }
    }

    public static class RangedItem
    extends Item {
        public RangedItem() {
            this.func_77656_e(100);
            this.func_77664_n();
            this.func_77655_b("spike");
            this.setRegistryName("spike");
            this.field_77777_bU = 1;
            this.func_77637_a(TabPvZ.tab);
        }

        public void onUsingTick(ItemStack itemstack, EntityLivingBase entityLivingBase, int count) {
            World world = entityLivingBase.field_70170_p;
            if (!world.field_72995_K && entityLivingBase instanceof EntityPlayerMP) {
                EntityPlayerMP entity = (EntityPlayerMP)entityLivingBase;
                float power = 3.6f;
                EntityArrowCustom entityarrow = new EntityArrowCustom(world, (EntityLivingBase)entity);
                entityarrow.func_70186_c(entity.func_70040_Z().field_72450_a, entity.func_70040_Z().field_72448_b, entity.func_70040_Z().field_72449_c, power * 2.0f, 0.0f);
                entityarrow.func_174810_b(true);
                entityarrow.func_70243_d(false);
                entityarrow.func_70239_b(5.0);
                entityarrow.func_70240_a(5);
                itemstack.func_77972_a(1, (EntityLivingBase)entity);
                int x = (int)entity.field_70165_t;
                int y = (int)entity.field_70163_u;
                int z = (int)entity.field_70161_v;
                world.func_184148_a((EntityPlayer)null, (double)x, (double)y, (double)z, (SoundEvent)SoundEvent.field_187505_a.func_82594_a((Object)new ResourceLocation("")), SoundCategory.NEUTRAL, 1.0f, 1.0f / (field_77697_d.nextFloat() * 0.5f + 1.0f) + power / 2.0f);
                entityarrow.field_70251_a = EntityArrow.PickupStatus.DISALLOWED;
                if (!world.field_72995_K) {
                    world.func_72838_d((Entity)entityarrow);
                }
                entity.func_184597_cx();
            }
        }

        public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer entity, EnumHand hand) {
            entity.func_184598_c(hand);
            return new ActionResult(EnumActionResult.SUCCESS, (Object)entity.func_184586_b(hand));
        }

        public EnumAction func_77661_b(ItemStack itemstack) {
            return EnumAction.BOW;
        }

        public int func_77626_a(ItemStack itemstack) {
            return 72000;
        }
    }
}

