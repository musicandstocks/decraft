/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package capsule.tabs;

import capsule.items.CapsuleItems;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class CapsuleTabs
extends CreativeTabs {
    public CapsuleTabs(int index, String label) {
        super(index, label);
    }

    @SideOnly(value=Side.CLIENT)
    public ItemStack func_78016_d() {
        return new ItemStack((Item)CapsuleItems.capsule, 1, 2);
    }
}

