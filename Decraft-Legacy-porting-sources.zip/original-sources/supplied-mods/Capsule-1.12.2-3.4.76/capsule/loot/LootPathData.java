/*
 * Decompiled with CFR 0.152.
 */
package capsule.loot;

import java.util.List;

public class LootPathData {
    public int weigth;
    public List<String> files;
}

