/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraftforge.fml.common.network.ByteBufUtils
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package capsule.network;

import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CapsuleContentPreviewAnswerToClient
implements IMessage {
    protected static final Logger LOGGER = LogManager.getLogger(CapsuleContentPreviewAnswerToClient.class);
    private List<AxisAlignedBB> boundingBoxes = null;
    private String structureName = null;

    public CapsuleContentPreviewAnswerToClient(List<AxisAlignedBB> boundingBoxes, String structureName) {
        this.boundingBoxes = boundingBoxes;
        this.structureName = structureName;
    }

    public CapsuleContentPreviewAnswerToClient() {
    }

    public void fromBytes(ByteBuf buf) {
        try {
            this.structureName = ByteBufUtils.readUTF8String((ByteBuf)buf);
            int size = buf.readShort();
            this.boundingBoxes = new ArrayList<AxisAlignedBB>(size);
            for (int i = 0; i < size; ++i) {
                boolean isSingleBlock = buf.readBoolean();
                if (isSingleBlock) {
                    BlockPos p = BlockPos.func_177969_a((long)buf.readLong());
                    this.boundingBoxes.add(new AxisAlignedBB(p, p));
                    continue;
                }
                this.boundingBoxes.add(new AxisAlignedBB(BlockPos.func_177969_a((long)buf.readLong()), BlockPos.func_177969_a((long)buf.readLong())));
            }
        }
        catch (IndexOutOfBoundsException ioe) {
            LOGGER.error("Exception while reading CapsuleContentPreviewMessageToClient: " + ioe);
            return;
        }
    }

    public void toBytes(ByteBuf buf) {
        ByteBufUtils.writeUTF8String((ByteBuf)buf, (String)this.structureName);
        int size = Math.min(this.boundingBoxes.size(), Short.MAX_VALUE);
        buf.writeShort(size);
        for (int i = 0; i < size; ++i) {
            AxisAlignedBB bb = this.boundingBoxes.get(i);
            boolean isSingleBlock = bb.func_72320_b() == 0.0;
            buf.writeBoolean(isSingleBlock);
            buf.writeLong(new BlockPos(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_177986_g());
            if (isSingleBlock) continue;
            buf.writeLong(new BlockPos(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_177986_g());
        }
    }

    public String toString() {
        return this.getClass().toString();
    }

    public List<AxisAlignedBB> getBoundingBoxes() {
        return this.boundingBoxes;
    }

    public String getStructureName() {
        return this.structureName;
    }
}

