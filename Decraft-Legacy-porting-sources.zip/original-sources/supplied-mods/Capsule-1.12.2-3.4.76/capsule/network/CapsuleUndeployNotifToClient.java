/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  net.minecraft.util.math.BlockPos
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package capsule.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CapsuleUndeployNotifToClient
implements IMessage {
    protected static final Logger LOGGER = LogManager.getLogger(CapsuleUndeployNotifToClient.class);
    public BlockPos posFrom = null;
    public BlockPos posTo = null;
    public int size = 0;

    public CapsuleUndeployNotifToClient(BlockPos posFrom, BlockPos posTo, int size) {
        this.posFrom = posFrom;
        this.posTo = posTo;
        this.size = size;
    }

    public CapsuleUndeployNotifToClient() {
    }

    public void fromBytes(ByteBuf buf) {
        try {
            this.posFrom = BlockPos.func_177969_a((long)buf.readLong());
            this.posTo = BlockPos.func_177969_a((long)buf.readLong());
            this.size = buf.readShort();
        }
        catch (IndexOutOfBoundsException ioe) {
            LOGGER.error("Exception while reading CapsuleUndeployNotifToClient: " + ioe);
        }
    }

    public void toBytes(ByteBuf buf) {
        buf.writeLong(this.posFrom.func_177986_g());
        buf.writeLong(this.posTo.func_177986_g());
        buf.writeShort(this.size);
    }

    public String toString() {
        return this.getClass().toString();
    }
}

