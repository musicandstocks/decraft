/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler
 *  net.minecraftforge.fml.common.network.simpleimpl.MessageContext
 *  net.minecraftforge.fml.relauncher.Side
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package capsule.network.client;

import capsule.client.CapsulePreviewHandler;
import capsule.network.CapsuleFullContentAnswerToClient;
import capsule.structure.CapsuleTemplate;
import java.util.Map;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CapsuleFullContentAnswerHandler
implements IMessageHandler<CapsuleFullContentAnswerToClient, IMessage> {
    protected static final Logger LOGGER = LogManager.getLogger(CapsuleFullContentAnswerHandler.class);

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public IMessage onMessage(CapsuleFullContentAnswerToClient message, MessageContext ctx) {
        if (ctx.side != Side.CLIENT) {
            LOGGER.error("CapsuleFullContentAnswerToClient received on wrong side:" + ctx.side);
            return null;
        }
        if (message.getTemplate() != null) {
            Map<String, CapsuleTemplate> map = CapsulePreviewHandler.currentFullPreview;
            synchronized (map) {
                CapsulePreviewHandler.currentFullPreview.put(message.getStructureName(), message.getTemplate());
            }
        }
        return null;
    }
}

