/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler
 *  net.minecraftforge.fml.common.network.simpleimpl.MessageContext
 *  net.minecraftforge.fml.relauncher.Side
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package capsule.network.client;

import capsule.client.CapsulePreviewHandler;
import capsule.network.CapsuleContentPreviewAnswerToClient;
import java.util.List;
import java.util.Map;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CapsuleContentPreviewAnswerHandler
implements IMessageHandler<CapsuleContentPreviewAnswerToClient, IMessage> {
    protected static final Logger LOGGER = LogManager.getLogger(CapsuleContentPreviewAnswerHandler.class);

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public IMessage onMessage(CapsuleContentPreviewAnswerToClient message, MessageContext ctx) {
        if (ctx.side != Side.CLIENT) {
            LOGGER.error("CapsuleContentPreviewMessageToClient received on wrong side:" + ctx.side);
            return null;
        }
        Map<String, List<AxisAlignedBB>> map = CapsulePreviewHandler.currentPreview;
        synchronized (map) {
            CapsulePreviewHandler.currentPreview.put(message.getStructureName(), message.getBoundingBoxes());
        }
        return null;
    }
}

