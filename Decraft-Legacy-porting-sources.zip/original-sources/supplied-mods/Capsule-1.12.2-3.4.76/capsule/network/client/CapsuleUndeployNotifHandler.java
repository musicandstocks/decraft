/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler
 *  net.minecraftforge.fml.common.network.simpleimpl.MessageContext
 *  net.minecraftforge.fml.relauncher.Side
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package capsule.network.client;

import capsule.helpers.Capsule;
import capsule.network.CapsuleUndeployNotifToClient;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CapsuleUndeployNotifHandler
implements IMessageHandler<CapsuleUndeployNotifToClient, IMessage> {
    protected static final Logger LOGGER = LogManager.getLogger(CapsuleUndeployNotifHandler.class);

    public IMessage onMessage(CapsuleUndeployNotifToClient message, MessageContext ctx) {
        if (ctx.side != Side.CLIENT) {
            LOGGER.error("CapsuleContentPreviewMessageToClient received on wrong side:" + ctx.side);
            return null;
        }
        Capsule.showUndeployParticules(Minecraft.func_71410_x().field_71441_e, message.posFrom, message.posTo, message.size);
        return null;
    }
}

