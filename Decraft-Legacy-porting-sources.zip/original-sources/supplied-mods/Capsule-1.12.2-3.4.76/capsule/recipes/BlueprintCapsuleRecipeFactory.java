/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  net.minecraft.inventory.InventoryCrafting
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.crafting.IRecipe
 *  net.minecraft.util.NonNullList
 *  net.minecraft.world.World
 *  net.minecraftforge.common.ForgeHooks
 *  net.minecraftforge.common.crafting.IRecipeFactory
 *  net.minecraftforge.common.crafting.JsonContext
 *  net.minecraftforge.oredict.ShapedOreRecipe
 *  net.minecraftforge.registries.IForgeRegistryEntry$Impl
 */
package capsule.recipes;

import capsule.helpers.Capsule;
import capsule.items.CapsuleItem;
import com.google.gson.JsonObject;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.NonNullList;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.crafting.IRecipeFactory;
import net.minecraftforge.common.crafting.JsonContext;
import net.minecraftforge.oredict.ShapedOreRecipe;
import net.minecraftforge.registries.IForgeRegistryEntry;

public class BlueprintCapsuleRecipeFactory
implements IRecipeFactory {
    public IRecipe parse(JsonContext context, JsonObject json) {
        return new BlueprintCapsuleRecipe(ShapedOreRecipe.factory((JsonContext)context, (JsonObject)json));
    }

    public class BlueprintCapsuleRecipe
    extends IForgeRegistryEntry.Impl<IRecipe>
    implements IRecipe {
        public final ShapedOreRecipe recipe;

        public BlueprintCapsuleRecipe(ShapedOreRecipe recipe) {
            this.recipe = recipe;
        }

        public ItemStack func_77571_b() {
            return this.recipe.func_77571_b();
        }

        public NonNullList<ItemStack> func_179532_b(InventoryCrafting inv) {
            NonNullList nonnulllist = NonNullList.func_191197_a((int)inv.func_70302_i_(), (Object)ItemStack.field_190927_a);
            for (int i = 0; i < nonnulllist.size(); ++i) {
                ItemStack itemstack = inv.func_70301_a(i);
                nonnulllist.set(i, (Object)ForgeHooks.getContainerItem((ItemStack)itemstack));
                if (!(itemstack.func_77973_b() instanceof CapsuleItem)) continue;
                nonnulllist.set(i, (Object)itemstack.func_77946_l());
            }
            return nonnulllist;
        }

        public boolean func_77569_a(InventoryCrafting inv, World worldIn) {
            return this.recipe.func_77569_a(inv, worldIn);
        }

        public ItemStack func_77572_b(InventoryCrafting invC) {
            ItemStack configuredOutput;
            ItemStack referenceCapsule = configuredOutput = this.recipe.func_77571_b();
            for (int i = 0; i < invC.func_174923_h(); ++i) {
                for (int j = 0; j < invC.func_174922_i(); ++j) {
                    ItemStack itemstack = invC.func_70463_b(j, i);
                    if (!CapsuleItem.isLinkedStateCapsule(itemstack) && !CapsuleItem.isReward(itemstack)) continue;
                    referenceCapsule = itemstack;
                }
            }
            try {
                ItemStack blueprintItem = Capsule.newLinkedCapsuleItemStack(CapsuleItem.getStructureName(referenceCapsule), CapsuleItem.getBaseColor(this.recipe.func_77571_b()), 0xFFFFFF, CapsuleItem.getSize(referenceCapsule), CapsuleItem.isOverpowered(referenceCapsule), referenceCapsule.func_77978_p() != null ? referenceCapsule.func_77978_p().func_74779_i("label") : null, 0);
                CapsuleItem.setBlueprint(blueprintItem);
                if (blueprintItem.func_77978_p() != null) {
                    blueprintItem.func_77978_p().func_74757_a("templateShouldBeCopied", true);
                }
                CapsuleItem.setState(blueprintItem, 3);
                return blueprintItem;
            }
            catch (Exception e) {
                e.printStackTrace();
                return ItemStack.field_190927_a;
            }
        }

        public boolean func_194133_a(int width, int height) {
            return this.recipe.func_194133_a(width, height);
        }

        public boolean func_192399_d() {
            return true;
        }
    }
}

