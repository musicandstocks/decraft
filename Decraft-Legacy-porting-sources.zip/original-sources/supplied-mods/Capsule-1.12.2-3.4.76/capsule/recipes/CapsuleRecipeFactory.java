/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  net.minecraft.item.crafting.IRecipe
 *  net.minecraft.util.JsonUtils
 *  net.minecraftforge.common.crafting.IRecipeFactory
 *  net.minecraftforge.common.crafting.JsonContext
 *  net.minecraftforge.oredict.ShapedOreRecipe
 */
package capsule.recipes;

import capsule.Config;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.JsonUtils;
import net.minecraftforge.common.crafting.IRecipeFactory;
import net.minecraftforge.common.crafting.JsonContext;
import net.minecraftforge.oredict.ShapedOreRecipe;

public class CapsuleRecipeFactory
implements IRecipeFactory {
    public IRecipe parse(JsonContext context, JsonObject json) {
        JsonObject result = JsonUtils.func_152754_s((JsonObject)json, (String)"result");
        JsonObject nbt = JsonUtils.func_152754_s((JsonObject)result, (String)"nbt");
        int defaultSize = JsonUtils.func_151203_m((JsonObject)nbt, (String)"size");
        JsonArray conditions = json.get("conditions").getAsJsonArray();
        int configSize = defaultSize;
        for (JsonElement condition : conditions) {
            String property;
            String conditionType = JsonUtils.func_151200_h((JsonObject)condition.getAsJsonObject(), (String)"type");
            if (!"capsule:is_enabled".equals(conditionType) || !Config.capsuleSizes.containsKey(property = JsonUtils.func_151200_h((JsonObject)condition.getAsJsonObject(), (String)"property"))) continue;
            configSize = Config.capsuleSizes.get(property);
        }
        if (defaultSize != configSize) {
            nbt.addProperty("size", (Number)configSize);
        }
        return ShapedOreRecipe.factory((JsonContext)context, (JsonObject)json);
    }
}

