/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonObject
 *  net.minecraft.inventory.InventoryCrafting
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.crafting.IRecipe
 *  net.minecraft.item.crafting.Ingredient
 *  net.minecraft.util.JsonUtils
 *  net.minecraft.util.NonNullList
 *  net.minecraft.world.World
 *  net.minecraftforge.common.ForgeHooks
 *  net.minecraftforge.common.crafting.JsonContext
 *  net.minecraftforge.oredict.ShapedOreRecipe
 *  net.minecraftforge.registries.IForgeRegistryEntry$Impl
 *  org.apache.commons.lang3.tuple.Triple
 */
package capsule.recipes;

import capsule.StructureSaver;
import capsule.items.CapsuleItem;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.NonNullList;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.crafting.JsonContext;
import net.minecraftforge.oredict.ShapedOreRecipe;
import net.minecraftforge.registries.IForgeRegistryEntry;
import org.apache.commons.lang3.tuple.Triple;

public class PrefabsBlueprintCapsuleRecipe
extends IForgeRegistryEntry.Impl<IRecipe>
implements IRecipe {
    public final ShapedOreRecipe recipe;
    private int ingredientOneIndex = 4;
    private int ingredientTwoIndex = 0;
    private int ingredientThreeIndex = 2;

    public PrefabsBlueprintCapsuleRecipe(JsonObject template, Triple<StructureSaver.ItemStackKey, StructureSaver.ItemStackKey, StructureSaver.ItemStackKey> ingredients) {
        this.recipe = ShapedOreRecipe.factory((JsonContext)new JsonContext("capsule"), (JsonObject)template);
        this.buildRecipeFromPattern(template, ingredients);
    }

    public void buildRecipeFromPattern(JsonObject template, Triple<StructureSaver.ItemStackKey, StructureSaver.ItemStackKey, StructureSaver.ItemStackKey> ingredients) {
        JsonArray patternArr = JsonUtils.func_151214_t((JsonObject)template, (String)"pattern");
        String pattern = patternArr.get(0).getAsString() + patternArr.get(1).getAsString() + patternArr.get(2).getAsString();
        this.ingredientOneIndex = pattern.indexOf("1");
        this.ingredientTwoIndex = pattern.indexOf("2");
        this.ingredientThreeIndex = pattern.indexOf("3");
        this.recipe.func_192400_c().set(this.ingredientOneIndex, (Object)Ingredient.func_193369_a((ItemStack[])new ItemStack[]{((StructureSaver.ItemStackKey)ingredients.getLeft()).itemStack}));
        if (ingredients.getMiddle() != null) {
            this.recipe.func_192400_c().set(this.ingredientTwoIndex, (Object)Ingredient.func_193369_a((ItemStack[])new ItemStack[]{((StructureSaver.ItemStackKey)ingredients.getMiddle()).itemStack}));
        }
        if (ingredients.getRight() != null) {
            this.recipe.func_192400_c().set(this.ingredientThreeIndex, (Object)Ingredient.func_193369_a((ItemStack[])new ItemStack[]{((StructureSaver.ItemStackKey)ingredients.getRight()).itemStack}));
        }
    }

    public ItemStack func_77571_b() {
        return this.recipe.func_77571_b();
    }

    public NonNullList<ItemStack> func_179532_b(InventoryCrafting inv) {
        NonNullList nonnulllist = NonNullList.func_191197_a((int)inv.func_70302_i_(), (Object)ItemStack.field_190927_a);
        for (int i = 0; i < nonnulllist.size(); ++i) {
            ItemStack itemstack = inv.func_70301_a(i);
            nonnulllist.set(i, (Object)ForgeHooks.getContainerItem((ItemStack)itemstack));
            if (itemstack.func_77973_b() instanceof CapsuleItem) {
                nonnulllist.set(i, (Object)itemstack.func_77946_l());
                continue;
            }
            if (i != this.ingredientOneIndex && i != this.ingredientTwoIndex && i != this.ingredientThreeIndex) continue;
            ItemStack refund = itemstack.func_77946_l();
            refund.func_190920_e(1);
            nonnulllist.set(i, (Object)refund);
        }
        return nonnulllist;
    }

    public boolean func_77569_a(InventoryCrafting inv, World worldIn) {
        return this.recipe.func_77569_a(inv, worldIn);
    }

    public ItemStack func_77572_b(InventoryCrafting invC) {
        return this.recipe.func_77572_b(invC);
    }

    public boolean func_194133_a(int width, int height) {
        return this.recipe.func_194133_a(width, height);
    }

    public boolean func_192399_d() {
        return true;
    }
}

