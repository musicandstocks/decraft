/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.gson.JsonObject
 *  net.minecraft.init.Items
 *  net.minecraft.inventory.InventoryCrafting
 *  net.minecraft.item.EnumDyeColor
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.crafting.IRecipe
 *  net.minecraft.util.NonNullList
 *  net.minecraft.world.World
 *  net.minecraftforge.common.ForgeHooks
 *  net.minecraftforge.common.crafting.IRecipeFactory
 *  net.minecraftforge.common.crafting.JsonContext
 *  net.minecraftforge.oredict.DyeUtils
 *  net.minecraftforge.registries.IForgeRegistryEntry$Impl
 */
package capsule.recipes;

import capsule.helpers.MinecraftNBT;
import capsule.items.CapsuleItem;
import capsule.items.CapsuleItems;
import com.google.common.collect.Lists;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import net.minecraft.init.Items;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.NonNullList;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.crafting.IRecipeFactory;
import net.minecraftforge.common.crafting.JsonContext;
import net.minecraftforge.oredict.DyeUtils;
import net.minecraftforge.registries.IForgeRegistryEntry;

public class DyeCapsuleRecipeFactory
implements IRecipeFactory {
    public IRecipe parse(JsonContext context, JsonObject json) {
        return new DyeCapsuleRecipe();
    }

    public class DyeCapsuleRecipe
    extends IForgeRegistryEntry.Impl<IRecipe>
    implements IRecipe {
        public boolean func_77569_a(InventoryCrafting inv, World worldIn) {
            ItemStack itemstack = ItemStack.field_190927_a;
            ArrayList arraylist = Lists.newArrayList();
            for (int i = 0; i < inv.func_70302_i_(); ++i) {
                ItemStack itemstack1 = inv.func_70301_a(i);
                if (itemstack1.func_190926_b()) continue;
                if (itemstack1.func_77973_b() instanceof CapsuleItem) {
                    itemstack = itemstack1;
                    continue;
                }
                if (itemstack1.func_77973_b() != Items.field_151100_aR) {
                    return false;
                }
                arraylist.add(itemstack1);
            }
            return !itemstack.func_190926_b() && !arraylist.isEmpty();
        }

        public ItemStack func_77572_b(InventoryCrafting invCrafting) {
            ItemStack itemstack = ItemStack.field_190927_a;
            int[] aint = new int[3];
            int i = 0;
            int j = 0;
            CapsuleItem item = null;
            for (int k = 0; k < invCrafting.func_70302_i_(); ++k) {
                ItemStack itemstack1 = invCrafting.func_70301_a(k);
                if (itemstack1.func_190926_b()) continue;
                if (itemstack1.func_77973_b() instanceof CapsuleItem) {
                    item = (CapsuleItem)itemstack1.func_77973_b();
                    itemstack = itemstack1.func_77946_l();
                    if (!MinecraftNBT.hasColor(itemstack1)) continue;
                    int l = MinecraftNBT.getColor(itemstack);
                    float f = (float)(l >> 16 & 0xFF) / 255.0f;
                    float f1 = (float)(l >> 8 & 0xFF) / 255.0f;
                    float f2 = (float)(l & 0xFF) / 255.0f;
                    i = (int)((float)i + Math.max(f, Math.max(f1, f2)) * 255.0f);
                    aint[0] = (int)((float)aint[0] + f * 255.0f);
                    aint[1] = (int)((float)aint[1] + f1 * 255.0f);
                    aint[2] = (int)((float)aint[2] + f2 * 255.0f);
                    ++j;
                    continue;
                }
                if (!DyeUtils.isDye((ItemStack)itemstack1)) {
                    return ItemStack.field_190927_a;
                }
                float[] afloat = ((EnumDyeColor)DyeUtils.colorFromStack((ItemStack)itemstack1).get()).func_193349_f();
                int l1 = (int)(afloat[0] * 255.0f);
                int i2 = (int)(afloat[1] * 255.0f);
                int j2 = (int)(afloat[2] * 255.0f);
                i += Math.max(l1, Math.max(i2, j2));
                aint[0] = aint[0] + l1;
                aint[1] = aint[1] + i2;
                aint[2] = aint[2] + j2;
                ++j;
            }
            if (item == null) {
                return ItemStack.field_190927_a;
            }
            int i1 = aint[0] / j;
            int j1 = aint[1] / j;
            int k1 = aint[2] / j;
            float f3 = (float)i / (float)j;
            float f4 = Math.max(i1, Math.max(j1, k1));
            i1 = (int)((float)i1 * f3 / f4);
            j1 = (int)((float)j1 * f3 / f4);
            k1 = (int)((float)k1 * f3 / f4);
            int lvt_12_3_ = (i1 << 8) + j1;
            lvt_12_3_ = (lvt_12_3_ << 8) + k1;
            MinecraftNBT.setColor(itemstack, lvt_12_3_);
            return itemstack;
        }

        public boolean func_194133_a(int width, int height) {
            return width * height >= 2;
        }

        public int getRecipeSize() {
            return 10;
        }

        public ItemStack func_77571_b() {
            return new ItemStack((Item)CapsuleItems.capsule, 1, 0);
        }

        public NonNullList<ItemStack> func_179532_b(InventoryCrafting inv) {
            NonNullList nonnulllist = NonNullList.func_191197_a((int)inv.func_70302_i_(), (Object)ItemStack.field_190927_a);
            for (int i = 0; i < nonnulllist.size(); ++i) {
                ItemStack itemstack = inv.func_70301_a(i);
                nonnulllist.set(i, (Object)ForgeHooks.getContainerItem((ItemStack)itemstack));
            }
            return nonnulllist;
        }

        public boolean func_192399_d() {
            return true;
        }
    }
}

