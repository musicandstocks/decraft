/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  net.minecraftforge.common.crafting.IConditionFactory
 *  net.minecraftforge.common.crafting.JsonContext
 */
package capsule.recipes;

import capsule.Config;
import com.google.gson.JsonObject;
import java.util.function.BooleanSupplier;
import net.minecraftforge.common.crafting.IConditionFactory;
import net.minecraftforge.common.crafting.JsonContext;

public class IsEnabledByConfigConditionFactory
implements IConditionFactory {
    public BooleanSupplier parse(JsonContext context, JsonObject json) {
        return Config.isEnabled(json.get("property").getAsString());
    }
}

