/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiTextField
 *  net.minecraft.client.resources.I18n
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.opengl.GL11
 */
package capsule.gui;

import capsule.CommonProxy;
import capsule.network.LabelEditedMessageToServer;
import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class LabelGui
extends GuiScreen {
    public static int GUI_WIDTH = 250;
    public static int GUI_HEIGHT = 20;
    private GuiTextField textInput;
    private EntityPlayer player;
    private GuiButton buttonDone;

    public LabelGui(EntityPlayer player) {
        this.player = player;
    }

    public void func_73866_w_() {
        this.field_146292_n.clear();
        Keyboard.enableRepeatEvents((boolean)true);
        this.textInput = new GuiTextField(0, this.field_146289_q, this.field_146294_l / 2 - GUI_WIDTH / 2, this.field_146295_m / 2 - GUI_HEIGHT / 2, GUI_WIDTH, GUI_HEIGHT);
        this.textInput.func_146203_f(32);
        this.textInput.func_146195_b(true);
        this.buttonDone = new GuiButton(1, this.textInput.field_146209_f + this.textInput.field_146218_h - 98, this.textInput.field_146210_g + this.textInput.field_146219_i + 10, 98, 20, I18n.func_135052_a((String)"gui.done", (Object[])new Object[0]));
        this.buttonDone.field_146124_l = true;
        this.field_146292_n.add(this.buttonDone);
        String label = "";
        ItemStack itemStack = this.getItemStack();
        if (!itemStack.func_190926_b() && itemStack.func_77942_o()) {
            label = itemStack.func_77978_p().func_74779_i("label");
        }
        this.textInput.func_146180_a(label);
    }

    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        super.func_73869_a(typedChar, keyCode);
        if (keyCode == 28) {
            this.closeGui();
        }
        this.textInput.func_146201_a(typedChar, keyCode);
        this.setCurrentItemLabel(this.textInput.func_146179_b());
    }

    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.func_73864_a(mouseX, mouseY, mouseButton);
        this.textInput.func_146192_a(mouseX, mouseY, mouseButton);
    }

    public void func_146284_a(GuiButton button) {
        if (button == this.buttonDone) {
            this.closeGui();
        }
    }

    private void closeGui() {
        this.field_146297_k.func_147108_a(null);
        if (this.field_146297_k.field_71462_r == null) {
            this.field_146297_k.func_71381_h();
        }
    }

    public void func_146281_b() {
    }

    public void func_73876_c() {
        super.func_73876_c();
    }

    public void setCurrentItemLabel(String label) {
        CommonProxy.simpleNetworkWrapper.sendToServer((IMessage)new LabelEditedMessageToServer(label));
    }

    public ItemStack getItemStack() {
        return this.player.func_184614_ca();
    }

    public boolean func_73868_f() {
        return true;
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        if (this.field_146297_k != null) {
            this.func_146276_q_();
        }
        if (this.textInput != null) {
            this.textInput.func_146194_f();
        }
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }
}

