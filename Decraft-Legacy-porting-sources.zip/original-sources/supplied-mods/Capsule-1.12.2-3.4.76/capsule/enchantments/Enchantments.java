/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.Enchantment$Rarity
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.enchantment.EnumEnchantmentType
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.event.RegistryEvent$Register
 *  net.minecraftforge.registries.IForgeRegistryEntry
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package capsule.enchantments;

import capsule.Config;
import capsule.enchantments.RecallEnchant;
import java.util.function.Predicate;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.registries.IForgeRegistryEntry;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Enchantments {
    protected static final Logger LOGGER = LogManager.getLogger(Enchantments.class);
    public static Enchantment recallEnchant = null;
    public static final Predicate hasRecallEnchant = new Predicate(){

        public boolean apply(Entity entityIn) {
            return entityIn instanceof EntityItem && EnchantmentHelper.func_77506_a((Enchantment)recallEnchant, (ItemStack)((EntityItem)entityIn).func_92059_d()) > 0;
        }

        public boolean test(Object obj) {
            return this.apply((Entity)obj);
        }
    };

    public static void registerEnchantments(RegistryEvent.Register<Enchantment> event) {
        Enchantment.Rarity enchantRarity = Enchantment.Rarity.RARE;
        try {
            enchantRarity = Enchantment.Rarity.valueOf((String)Config.enchantRarity);
        }
        catch (Exception e) {
            LOGGER.warn("Couldn't find the rarity " + Config.enchantRarity + ". Using RARE instead.");
        }
        EnumEnchantmentType recallEnchantTypeEnumValue = null;
        try {
            recallEnchantTypeEnumValue = EnumEnchantmentType.valueOf((String)Config.recallEnchantType);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            // empty catch block
        }
        recallEnchant = new RecallEnchant(new ResourceLocation("capsule", "recall"), enchantRarity, recallEnchantTypeEnumValue);
        event.getRegistry().register((IForgeRegistryEntry)recallEnchant);
    }
}

