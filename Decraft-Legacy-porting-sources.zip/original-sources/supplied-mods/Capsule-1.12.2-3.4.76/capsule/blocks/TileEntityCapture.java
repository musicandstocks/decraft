/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.network.NetworkManager
 *  net.minecraft.network.play.server.SPacketUpdateTileEntity
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package capsule.blocks;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class TileEntityCapture
extends TileEntity {
    public static List<TileEntityCapture> instances = new ArrayList<TileEntityCapture>();

    public TileEntityCapture() {
        instances.add(this);
    }

    public void onChunkUnload() {
        this.getTileData().func_74768_a("size", 0);
    }

    @SideOnly(value=Side.CLIENT)
    public double func_145833_n() {
        int MAXIMUM_DISTANCE_IN_BLOCKS = 32;
        return 1024.0;
    }

    public SPacketUpdateTileEntity func_189518_D_() {
        NBTTagCompound nbtTagCompound = new NBTTagCompound();
        this.func_189515_b(nbtTagCompound);
        int metadata = this.func_145832_p();
        return new SPacketUpdateTileEntity(this.field_174879_c, metadata, nbtTagCompound);
    }

    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        this.func_145839_a(pkt.func_148857_g());
    }

    @SideOnly(value=Side.CLIENT)
    public AxisAlignedBB getRenderBoundingBox() {
        return this.getBoundingBox();
    }

    public int getSize() {
        int size = 0;
        if (this.getTileData().func_74764_b("size")) {
            size = this.getTileData().func_74762_e("size");
        }
        return size;
    }

    public int getColor() {
        int color = 0;
        if (this.getTileData().func_74764_b("color")) {
            color = this.getTileData().func_74762_e("color");
        }
        return color;
    }

    public AxisAlignedBB getBoundingBox() {
        int size = this.getSize();
        int exdendLength = (size - 1) / 2;
        BlockPos source = this.func_174877_v().func_177982_a(-exdendLength, 1, -exdendLength);
        BlockPos end = source.func_177982_a(size, size, size);
        AxisAlignedBB box = new AxisAlignedBB((double)source.func_177958_n(), (double)source.func_177956_o(), (double)source.func_177952_p(), (double)end.func_177958_n(), (double)end.func_177956_o(), (double)end.func_177952_p());
        return box;
    }
}

