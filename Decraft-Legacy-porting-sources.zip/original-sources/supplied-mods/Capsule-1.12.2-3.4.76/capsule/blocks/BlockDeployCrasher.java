/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 */
package capsule.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockDeployCrasher
extends Block {
    public BlockDeployCrasher(String name, Material material) {
        super(material);
        this.func_149663_c(name);
        this.func_149711_c(5.0f);
        this.func_149752_b(1000.0f);
    }

    public void func_176213_c(World worldIn, BlockPos pos, IBlockState state) {
        super.func_176213_c(worldIn, pos, state);
        if (pos.func_177956_o() > 70) {
            throw new RuntimeException("testing purpose deploy crasher");
        }
    }
}

