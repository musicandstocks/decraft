/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.material.Material
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.event.RegistryEvent$Register
 *  net.minecraftforge.fml.common.registry.GameRegistry
 *  net.minecraftforge.registries.IForgeRegistryEntry
 */
package capsule.blocks;

import capsule.Main;
import capsule.blocks.BlockCapsuleMarker;
import capsule.blocks.BlockCaptureCrasher;
import capsule.blocks.BlockDeployCrasher;
import capsule.blocks.TileEntityCapture;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.registries.IForgeRegistryEntry;

public class CapsuleBlocks {
    public static BlockCapsuleMarker blockCapsuleMarker;
    public static final String CAPSULE_MARKER_REGISTERY_NAME = "capsulemarker";
    public static final String CAPSULE_MARKER_TE_REGISTERY_NAME = "capsulemarker-te";
    public static BlockCaptureCrasher blockCaptureCrasher;
    public static final String CAPTURE_CRASHER_REGISTERY_NAME = "capturecrasher";
    public static BlockDeployCrasher blockDeployCrasher;
    public static final String DEPLOY_CRASHER_REGISTERY_NAME = "deploycrasher";

    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        blockCapsuleMarker = new BlockCapsuleMarker(CAPSULE_MARKER_REGISTERY_NAME, Material.field_151576_e);
        blockCapsuleMarker.setRegistryName(CAPSULE_MARKER_REGISTERY_NAME);
        blockCapsuleMarker.func_149647_a(Main.tabCapsule);
        event.getRegistry().register((IForgeRegistryEntry)blockCapsuleMarker);
        GameRegistry.registerTileEntity(TileEntityCapture.class, (ResourceLocation)new ResourceLocation("capsule", CAPSULE_MARKER_TE_REGISTERY_NAME));
        Map<String, String> env = System.getenv();
        if ("DEV".equals(env.get("__ENV__"))) {
            blockCaptureCrasher = new BlockCaptureCrasher(CAPTURE_CRASHER_REGISTERY_NAME, Material.field_151576_e);
            blockCaptureCrasher.setRegistryName(CAPTURE_CRASHER_REGISTERY_NAME);
            blockCaptureCrasher.func_149647_a(Main.tabCapsule);
            event.getRegistry().register((IForgeRegistryEntry)blockCaptureCrasher);
            blockDeployCrasher = new BlockDeployCrasher(DEPLOY_CRASHER_REGISTERY_NAME, Material.field_151576_e);
            blockDeployCrasher.setRegistryName(DEPLOY_CRASHER_REGISTERY_NAME);
            blockDeployCrasher.func_149647_a(Main.tabCapsule);
            event.getRegistry().register((IForgeRegistryEntry)blockDeployCrasher);
        }
    }

    public static void registerItemBlocks(RegistryEvent.Register<Item> event) {
        event.getRegistry().register(new ItemBlock((Block)blockCapsuleMarker).setRegistryName(blockCapsuleMarker.getRegistryName()));
        Map<String, String> env = System.getenv();
        if ("DEV".equals(env.get("__ENV__"))) {
            event.getRegistry().register(new ItemBlock((Block)blockCaptureCrasher).setRegistryName(blockCaptureCrasher.getRegistryName()));
            event.getRegistry().register(new ItemBlock((Block)blockDeployCrasher).setRegistryName(blockDeployCrasher.getRegistryName()));
        }
    }
}

