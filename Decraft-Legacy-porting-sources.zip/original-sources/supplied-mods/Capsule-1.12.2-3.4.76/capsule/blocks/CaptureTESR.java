/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.BufferBuilder
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.util.math.AxisAlignedBB
 */
package capsule.blocks;

import capsule.blocks.TileEntityCapture;
import capsule.client.RendererUtils;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.AxisAlignedBB;

public class CaptureTESR
extends TileEntitySpecialRenderer<TileEntityCapture> {
    public static void drawCaptureZone(double relativeX, double relativeY, double relativeZ, int size, int extendSize, int color) {
        RendererUtils.doPositionPrologue();
        RendererUtils.doWirePrologue();
        boolean prevStateEnabled = RendererUtils.disableLightmap();
        AxisAlignedBB boundingBox = new AxisAlignedBB((double)(-extendSize) - 0.01 + relativeX, 1.01 + relativeY, (double)(-extendSize) - 0.01 + relativeZ, (double)extendSize + 1.01 + relativeX, (double)size + 1.01 + relativeY, (double)extendSize + 1.01 + relativeZ);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        RendererUtils.setColor(color, 50);
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181705_e);
        RendererUtils.drawCapsuleCube(boundingBox, bufferBuilder);
        tessellator.func_78381_a();
        RendererUtils.setColor(0xFFFFFF, 255);
        RendererUtils.resetLightmap(prevStateEnabled);
        RendererUtils.doWireEpilogue();
        RendererUtils.doPositionEpilogue();
    }

    public void render(TileEntityCapture tileEntityCapture, double relativeX, double relativeY, double relativeZ, float partialTicks, int blockDamageProgress, float alpha) {
        if (tileEntityCapture == null) {
            return;
        }
        int size = tileEntityCapture.getSize();
        if (size == 0) {
            return;
        }
        int extendSize = (size - 1) / 2;
        int color = tileEntityCapture.getColor();
        CaptureTESR.drawCaptureZone(tileEntityCapture.func_174877_v().func_177958_n(), tileEntityCapture.func_174877_v().func_177956_o(), tileEntityCapture.func_174877_v().func_177952_p(), size, extendSize, color);
    }
}

