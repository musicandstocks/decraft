/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.world.storage.WorldSavedData
 */
package capsule;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.storage.WorldSavedData;

public class CapsuleSavedData
extends WorldSavedData {
    private int capsuleCounter = 0;

    public CapsuleSavedData(String name) {
        super(name);
    }

    public void func_76184_a(NBTTagCompound nbt) {
        this.capsuleCounter = nbt.func_74762_e("counter");
    }

    public NBTTagCompound func_189551_b(NBTTagCompound nbt) {
        nbt.func_74768_a("counter", this.capsuleCounter);
        return nbt;
    }

    public int getNextCount() {
        this.func_76185_a();
        return this.capsuleCounter++;
    }
}

