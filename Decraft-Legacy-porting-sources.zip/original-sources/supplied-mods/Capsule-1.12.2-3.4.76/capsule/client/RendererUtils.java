/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.BufferBuilder
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  org.lwjgl.opengl.GL11
 */
package capsule.client;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

public class RendererUtils {
    public static void doPositionPrologue() {
        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b((double)(-TileEntityRendererDispatcher.field_147554_b), (double)(-TileEntityRendererDispatcher.field_147555_c), (double)(-TileEntityRendererDispatcher.field_147552_d));
    }

    public static void doPositionEpilogue() {
        GlStateManager.func_179121_F();
    }

    public static void doOverlayPrologue() {
        GlStateManager.func_179140_f();
        GlStateManager.func_179090_x();
        GlStateManager.func_179097_i();
        GlStateManager.func_179147_l();
    }

    public static void doOverlayEpilogue() {
        GlStateManager.func_179145_e();
        GlStateManager.func_179098_w();
        GlStateManager.func_179126_j();
        GlStateManager.func_179084_k();
    }

    public static void doWirePrologue() {
        GlStateManager.func_179129_p();
        GlStateManager.func_179140_f();
        GlStateManager.func_179090_x();
        GlStateManager.func_187441_d((float)3.0f);
    }

    public static void doWireEpilogue() {
        GlStateManager.func_187441_d((float)1.0f);
        GlStateManager.func_179098_w();
        GlStateManager.func_179145_e();
        GlStateManager.func_179089_o();
    }

    public static void drawCube(BlockPos pos, float sizeOffset, BufferBuilder buffer) {
        RendererUtils.drawCube((float)pos.func_177958_n() - sizeOffset, (float)pos.func_177956_o() - sizeOffset, (float)pos.func_177952_p() - sizeOffset, (float)(pos.func_177958_n() + 1) + sizeOffset, (float)(pos.func_177956_o() + 1) + sizeOffset, (float)(pos.func_177952_p() + 1) + sizeOffset, buffer);
    }

    public static void drawCube(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, BufferBuilder buffer) {
        RendererUtils.drawPlaneNegX(minX, minY, maxY, minZ, maxZ, buffer);
        RendererUtils.drawPlanePosX(maxX, minY, maxY, minZ, maxZ, buffer);
        RendererUtils.drawPlaneNegY(minY, minX, maxX, minZ, maxZ, buffer);
        RendererUtils.drawPlanePosY(maxY, minX, maxX, minZ, maxZ, buffer);
        RendererUtils.drawPlaneNegZ(minZ, minX, maxX, minY, maxY, buffer);
        RendererUtils.drawPlanePosZ(maxZ, minX, maxX, minY, maxY, buffer);
    }

    public static void drawPlaneNegX(double x, double minY, double maxY, double minZ, double maxZ, BufferBuilder buffer) {
        buffer.func_181662_b(x, minY, minZ).func_181675_d();
        buffer.func_181662_b(x, minY, maxZ).func_181675_d();
        buffer.func_181662_b(x, maxY, maxZ).func_181675_d();
        buffer.func_181662_b(x, maxY, minZ).func_181675_d();
    }

    public static void drawPlanePosX(double x, double minY, double maxY, double minZ, double maxZ, BufferBuilder buffer) {
        buffer.func_181662_b(x, minY, minZ).func_181675_d();
        buffer.func_181662_b(x, maxY, minZ).func_181675_d();
        buffer.func_181662_b(x, maxY, maxZ).func_181675_d();
        buffer.func_181662_b(x, minY, maxZ).func_181675_d();
    }

    public static void drawPlaneNegY(double y, double minX, double maxX, double minZ, double maxZ, BufferBuilder buffer) {
        buffer.func_181662_b(minX, y, minZ).func_181675_d();
        buffer.func_181662_b(maxX, y, minZ).func_181675_d();
        buffer.func_181662_b(maxX, y, maxZ).func_181675_d();
        buffer.func_181662_b(minX, y, maxZ).func_181675_d();
    }

    public static void drawPlanePosY(double y, double minX, double maxX, double minZ, double maxZ, BufferBuilder buffer) {
        buffer.func_181662_b(minX, y, minZ).func_181675_d();
        buffer.func_181662_b(minX, y, maxZ).func_181675_d();
        buffer.func_181662_b(maxX, y, maxZ).func_181675_d();
        buffer.func_181662_b(maxX, y, minZ).func_181675_d();
    }

    public static void drawPlaneNegZ(double z, double minX, double maxX, double minY, double maxY, BufferBuilder buffer) {
        buffer.func_181662_b(minX, minY, z).func_181675_d();
        buffer.func_181662_b(minX, maxY, z).func_181675_d();
        buffer.func_181662_b(maxX, maxY, z).func_181675_d();
        buffer.func_181662_b(maxX, minY, z).func_181675_d();
    }

    public static void drawPlanePosZ(double z, double minX, double maxX, double minY, double maxY, BufferBuilder buffer) {
        buffer.func_181662_b(minX, minY, z).func_181675_d();
        buffer.func_181662_b(maxX, minY, z).func_181675_d();
        buffer.func_181662_b(maxX, maxY, z).func_181675_d();
        buffer.func_181662_b(minX, maxY, z).func_181675_d();
    }

    public static void drawCapsuleCube(AxisAlignedBB boundingBox, BufferBuilder bufferBuilder) {
        RendererUtils.drawCubeBottom(boundingBox, bufferBuilder);
        RendererUtils.drawCubeTop(boundingBox, bufferBuilder);
        RendererUtils.drawCubeSides(boundingBox, bufferBuilder);
    }

    public static void drawCubeBottom(AxisAlignedBB boundingBox, BufferBuilder bufferBuilder) {
        bufferBuilder.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
    }

    public static void drawCubeTop(AxisAlignedBB boundingBox, BufferBuilder bufferBuilder) {
        bufferBuilder.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
    }

    public static void drawCubeSides(AxisAlignedBB boundingBox, BufferBuilder bufferBuilder) {
        bufferBuilder.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
    }

    public static void setColor(int rgb, int alpha) {
        int r = rgb >> 16 & 0xFF;
        int g = rgb >> 8 & 0xFF;
        int b = rgb & 0xFF;
        float af = (float)alpha / 255.0f;
        float rf = (float)r / 255.0f;
        float gf = (float)g / 255.0f;
        float bf = (float)b / 255.0f;
        GlStateManager.func_179131_c((float)rf, (float)gf, (float)bf, (float)af);
    }

    public static void resetLightmap(boolean prevStateEnabled) {
        if (prevStateEnabled) {
            GlStateManager.func_179138_g((int)OpenGlHelper.field_77476_b);
            GlStateManager.func_179098_w();
            GlStateManager.func_179138_g((int)OpenGlHelper.field_77478_a);
        }
    }

    public static boolean disableLightmap() {
        GlStateManager.func_179138_g((int)OpenGlHelper.field_77476_b);
        boolean lightmapState = GL11.glIsEnabled((int)3553);
        if (lightmapState) {
            GlStateManager.func_179090_x();
        }
        GlStateManager.func_179138_g((int)OpenGlHelper.field_77478_a);
        return lightmapState;
    }
}

