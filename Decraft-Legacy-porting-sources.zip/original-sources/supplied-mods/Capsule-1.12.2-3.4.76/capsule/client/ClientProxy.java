/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.renderer.block.model.ModelBakery
 *  net.minecraft.client.renderer.block.model.ModelResourceLocation
 *  net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.Item
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.client.event.ModelRegistryEvent
 *  net.minecraftforge.client.model.ModelLoader
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.client.registry.ClientRegistry
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.event.FMLInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLPreInitializationEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.relauncher.Side
 */
package capsule.client;

import capsule.CommonProxy;
import capsule.blocks.CapsuleBlocks;
import capsule.blocks.CaptureTESR;
import capsule.blocks.TileEntityCapture;
import capsule.client.CapsulePreviewHandler;
import capsule.gui.LabelGui;
import capsule.items.CapsuleItem;
import capsule.items.CapsuleItems;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.block.model.ModelBakery;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(value={Side.CLIENT})
public class ClientProxy
extends CommonProxy {
    @Override
    public void preInit(FMLPreInitializationEvent event) {
        super.preInit(event);
    }

    @Override
    public void init(FMLInitializationEvent event) {
        super.init(event);
        CapsulePreviewHandler cph = new CapsulePreviewHandler();
        MinecraftForge.EVENT_BUS.register((Object)cph);
        Minecraft.func_71410_x().getItemColors().func_186730_a((stack, tintIndex) -> {
            if (stack.func_77973_b() instanceof CapsuleItem) {
                return CapsuleItem.getColorFromItemstack(stack, tintIndex);
            }
            return 0xFFFFFF;
        }, new Item[]{CapsuleItems.capsule});
    }

    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        ClientProxy.registerItemRenderers("capsule");
        ClientProxy.registerBlockRenderer("capsule");
    }

    private static void registerBlockRenderer(String modid) {
        ModelLoader.setCustomModelResourceLocation((Item)Item.func_150898_a((Block)CapsuleBlocks.blockCapsuleMarker), (int)0, (ModelResourceLocation)new ModelResourceLocation(modid + ":capsulemarker", "inventory"));
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityCapture.class, (TileEntitySpecialRenderer)new CaptureTESR());
    }

    public static void registerItemRenderers(String modid) {
        ModelLoader.setCustomModelResourceLocation((Item)CapsuleItems.capsule, (int)0, (ModelResourceLocation)new ModelResourceLocation(modid + ":capsule_empty", "inventory"));
        ModelLoader.setCustomModelResourceLocation((Item)CapsuleItems.capsule, (int)1, (ModelResourceLocation)new ModelResourceLocation(modid + ":capsule_activated", "inventory"));
        ModelLoader.setCustomModelResourceLocation((Item)CapsuleItems.capsule, (int)2, (ModelResourceLocation)new ModelResourceLocation(modid + ":capsule_linked", "inventory"));
        ModelLoader.setCustomModelResourceLocation((Item)CapsuleItems.capsule, (int)3, (ModelResourceLocation)new ModelResourceLocation(modid + ":capsule_deployed", "inventory"));
        ModelLoader.setCustomModelResourceLocation((Item)CapsuleItems.capsule, (int)4, (ModelResourceLocation)new ModelResourceLocation(modid + ":capsule_empty_activated", "inventory"));
        ModelLoader.setCustomModelResourceLocation((Item)CapsuleItems.capsule, (int)5, (ModelResourceLocation)new ModelResourceLocation(modid + ":capsule_one_use", "inventory"));
        ModelLoader.setCustomModelResourceLocation((Item)CapsuleItems.capsule, (int)6, (ModelResourceLocation)new ModelResourceLocation(modid + ":capsule_one_use_activated", "inventory"));
        ModelLoader.setCustomModelResourceLocation((Item)CapsuleItems.capsule, (int)7, (ModelResourceLocation)new ModelResourceLocation(modid + ":capsule_blueprint", "inventory"));
        ModelBakery.registerItemVariants((Item)CapsuleItems.capsule, (ResourceLocation[])new ResourceLocation[]{new ResourceLocation(modid + ":capsule_empty"), new ResourceLocation(modid + ":capsule_activated"), new ResourceLocation(modid + ":capsule_linked"), new ResourceLocation(modid + ":capsule_deployed"), new ResourceLocation(modid + ":capsule_empty_activated"), new ResourceLocation(modid + ":capsule_one_use"), new ResourceLocation(modid + ":capsule_one_use_activated"), new ResourceLocation(modid + ":capsule_blueprint")});
    }

    @Override
    public void openGuiScreen(EntityPlayer playerIn) {
        LabelGui screen = new LabelGui(playerIn);
        Minecraft.func_71410_x().func_147108_a((GuiScreen)screen);
    }
}

