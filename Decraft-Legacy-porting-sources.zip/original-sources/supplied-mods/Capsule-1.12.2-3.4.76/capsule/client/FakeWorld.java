/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.init.Biomes
 *  net.minecraft.init.Blocks
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.WorldType
 *  net.minecraft.world.biome.Biome
 *  net.minecraft.world.gen.structure.template.Template$BlockInfo
 */
package capsule.client;

import java.util.HashMap;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Biomes;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.structure.template.Template;

class FakeWorld
implements IBlockAccess {
    private HashMap<BlockPos, Template.BlockInfo> blocks = new HashMap();

    @Nullable
    public TileEntity func_175625_s(BlockPos pos) {
        return null;
    }

    public int func_175626_b(BlockPos pos, int lightValue) {
        return 15;
    }

    public IBlockState func_180495_p(BlockPos pos) {
        return this.blocks.containsKey(pos) ? this.blocks.get((Object)pos).field_186243_b : Blocks.field_150350_a.func_176223_P();
    }

    public boolean func_175623_d(BlockPos pos) {
        return !this.blocks.containsKey(pos);
    }

    public Biome func_180494_b(BlockPos pos) {
        return Biomes.field_76772_c;
    }

    public int func_175627_a(BlockPos pos, EnumFacing direction) {
        return 0;
    }

    public WorldType func_175624_G() {
        return WorldType.field_77137_b;
    }

    public boolean isSideSolid(BlockPos pos, EnumFacing side, boolean _default) {
        return this.blocks.containsKey(pos) && this.blocks.get((Object)pos).field_186243_b.isSideSolid((IBlockAccess)this, pos, side);
    }

    public void clear() {
        this.blocks.clear();
    }

    public void add(BlockPos blockpos, Template.BlockInfo state) {
        this.blocks.put(blockpos, state);
    }
}

