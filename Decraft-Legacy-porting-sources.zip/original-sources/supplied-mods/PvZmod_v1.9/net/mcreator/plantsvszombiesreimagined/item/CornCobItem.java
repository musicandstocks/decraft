/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.food.FoodProperties$Builder
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.Rarity
 */
package net.mcreator.plantsvszombiesreimagined.item;

import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

public class CornCobItem
extends Item {
    public CornCobItem() {
        super(new Item.Properties().m_41487_(64).m_41497_(Rarity.COMMON).m_41489_(new FoodProperties.Builder().m_38760_(4).m_38758_(0.3f).m_38767_()));
    }
}

