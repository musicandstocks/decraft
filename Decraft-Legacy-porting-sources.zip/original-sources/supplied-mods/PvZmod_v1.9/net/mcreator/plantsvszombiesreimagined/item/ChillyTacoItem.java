/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.food.FoodProperties$Builder
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Rarity
 *  net.minecraft.world.level.Level
 */
package net.mcreator.plantsvszombiesreimagined.item;

import net.mcreator.plantsvszombiesreimagined.procedures.ChillyTacoEatenProcedure;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;

public class ChillyTacoItem
extends Item {
    public ChillyTacoItem() {
        super(new Item.Properties().m_41487_(64).m_41486_().m_41497_(Rarity.EPIC).m_41489_(new FoodProperties.Builder().m_38760_(11).m_38758_(0.8f).m_38765_().m_38757_().m_38767_()));
    }

    public ItemStack m_5922_(ItemStack itemstack, Level world, LivingEntity entity) {
        ItemStack retval = super.m_5922_(itemstack, world, entity);
        double x = entity.m_20185_();
        double y = entity.m_20186_();
        double z = entity.m_20189_();
        ChillyTacoEatenProcedure.execute((Entity)entity);
        return retval;
    }
}

