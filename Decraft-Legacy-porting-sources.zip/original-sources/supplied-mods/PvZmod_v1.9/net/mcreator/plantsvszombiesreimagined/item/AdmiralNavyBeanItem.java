/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.chat.Component
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.entity.projectile.AbstractArrow$Pickup
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.TooltipFlag
 *  net.minecraft.world.item.UseAnim
 *  net.minecraft.world.level.Level
 */
package net.mcreator.plantsvszombiesreimagined.item;

import java.util.List;
import net.mcreator.plantsvszombiesreimagined.entity.AdmiralNavyBeanEntity;
import net.mcreator.plantsvszombiesreimagined.procedures.AdmiralNavyBeanRangedItemUsedProcedure;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

public class AdmiralNavyBeanItem
extends Item {
    public AdmiralNavyBeanItem() {
        super(new Item.Properties().m_41503_(40));
    }

    public InteractionResultHolder<ItemStack> m_7203_(Level world, Player entity, InteractionHand hand) {
        entity.m_6672_(hand);
        return new InteractionResultHolder(InteractionResult.SUCCESS, (Object)entity.m_21120_(hand));
    }

    public void m_7373_(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
        super.m_7373_(itemstack, world, list, flag);
        list.add((Component)Component.m_237113_((String)"Gives a brief strength boost when used!"));
    }

    public UseAnim m_6164_(ItemStack itemstack) {
        return UseAnim.BOW;
    }

    public int m_8105_(ItemStack itemstack) {
        return 72000;
    }

    public void m_5551_(ItemStack itemstack, Level world, LivingEntity entityLiving, int timeLeft) {
        if (!world.m_5776_() && entityLiving instanceof ServerPlayer) {
            ServerPlayer entity = (ServerPlayer)entityLiving;
            double x = entity.m_20185_();
            double y = entity.m_20186_();
            double z = entity.m_20189_();
            AdmiralNavyBeanEntity entityarrow = AdmiralNavyBeanEntity.shoot(world, (LivingEntity)entity, world.m_213780_(), 0.7f, 3.0, 0);
            itemstack.m_41622_(1, (LivingEntity)entity, e -> e.m_21190_(entity.m_7655_()));
            entityarrow.f_36705_ = AbstractArrow.Pickup.DISALLOWED;
            AdmiralNavyBeanRangedItemUsedProcedure.execute((Entity)entity, itemstack);
        }
    }
}

