/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMultimap
 *  com.google.common.collect.ImmutableMultimap$Builder
 *  com.google.common.collect.Multimap
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EquipmentSlot
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.ai.attributes.AttributeModifier
 *  net.minecraft.world.entity.ai.attributes.AttributeModifier$Operation
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.entity.projectile.AbstractArrow$Pickup
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.UseAnim
 *  net.minecraft.world.level.Level
 */
package net.mcreator.plantsvszombiesreimagined.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.mcreator.plantsvszombiesreimagined.entity.CarolinaReaperEntity;
import net.mcreator.plantsvszombiesreimagined.procedures.DoomshroomProteccProcedure;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

public class CarolinaReaperItem
extends Item {
    public CarolinaReaperItem() {
        super(new Item.Properties().m_41503_(2));
    }

    public InteractionResultHolder<ItemStack> m_7203_(Level world, Player entity, InteractionHand hand) {
        entity.m_6672_(hand);
        return new InteractionResultHolder(InteractionResult.SUCCESS, (Object)entity.m_21120_(hand));
    }

    public UseAnim m_6164_(ItemStack itemstack) {
        return UseAnim.BOW;
    }

    public int m_8105_(ItemStack itemstack) {
        return 72000;
    }

    public Multimap<Attribute, AttributeModifier> m_7167_(EquipmentSlot slot) {
        if (slot == EquipmentSlot.MAINHAND) {
            ImmutableMultimap.Builder builder = ImmutableMultimap.builder();
            builder.putAll(super.m_7167_(slot));
            builder.put((Object)Attributes.f_22281_, (Object)new AttributeModifier(f_41374_, "Ranged item modifier", 4.5, AttributeModifier.Operation.ADDITION));
            builder.put((Object)Attributes.f_22283_, (Object)new AttributeModifier(f_41375_, "Ranged item modifier", -2.4, AttributeModifier.Operation.ADDITION));
            return builder.build();
        }
        return super.m_7167_(slot);
    }

    public void m_5551_(ItemStack itemstack, Level world, LivingEntity entityLiving, int timeLeft) {
        if (!world.m_5776_() && entityLiving instanceof ServerPlayer) {
            ServerPlayer entity = (ServerPlayer)entityLiving;
            double x = entity.m_20185_();
            double y = entity.m_20186_();
            double z = entity.m_20189_();
            CarolinaReaperEntity entityarrow = CarolinaReaperEntity.shoot(world, (LivingEntity)entity, world.m_213780_(), 1.0f, 60.0, 5);
            itemstack.m_41622_(1, (LivingEntity)entity, e -> e.m_21190_(entity.m_7655_()));
            entityarrow.f_36705_ = AbstractArrow.Pickup.DISALLOWED;
            DoomshroomProteccProcedure.execute((Entity)entity);
        }
    }
}

