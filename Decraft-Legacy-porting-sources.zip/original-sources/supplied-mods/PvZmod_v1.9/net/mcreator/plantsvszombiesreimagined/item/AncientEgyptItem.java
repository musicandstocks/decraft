/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.context.UseOnContext
 *  net.minecraft.world.level.Level
 */
package net.mcreator.plantsvszombiesreimagined.item;

import net.mcreator.plantsvszombiesreimagined.block.AncientEgyptPortalBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class AncientEgyptItem
extends Item {
    public AncientEgyptItem() {
        super(new Item.Properties().m_41503_(64));
    }

    public InteractionResult m_6225_(UseOnContext context) {
        Player entity = context.m_43723_();
        BlockPos pos = context.m_8083_().m_121945_(context.m_43719_());
        ItemStack itemstack = context.m_43722_();
        Level world = context.m_43725_();
        if (!entity.m_36204_(pos, context.m_43719_(), itemstack)) {
            return InteractionResult.FAIL;
        }
        int x = pos.m_123341_();
        int y = pos.m_123342_();
        int z = pos.m_123343_();
        boolean success = false;
        if (world.m_46859_(pos)) {
            AncientEgyptPortalBlock.portalSpawn(world, pos);
            itemstack.m_41622_(1, (LivingEntity)entity, c -> c.m_21190_(context.m_43724_()));
            success = true;
        }
        return success ? InteractionResult.SUCCESS : InteractionResult.FAIL;
    }
}

