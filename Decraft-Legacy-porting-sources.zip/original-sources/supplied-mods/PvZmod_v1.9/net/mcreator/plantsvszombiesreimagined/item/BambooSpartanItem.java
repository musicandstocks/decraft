/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.SwordItem
 *  net.minecraft.world.item.Tier
 *  net.minecraft.world.item.crafting.Ingredient
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 */
package net.mcreator.plantsvszombiesreimagined.item;

import net.mcreator.plantsvszombiesreimagined.init.PlantsvszombiesreimaginedModItems;
import net.mcreator.plantsvszombiesreimagined.procedures.BambooSpartanRightclickedProcedure;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;

public class BambooSpartanItem
extends SwordItem {
    public BambooSpartanItem() {
        super(new Tier(){

            public int m_6609_() {
                return 80;
            }

            public float m_6624_() {
                return 5.0f;
            }

            public float m_6631_() {
                return 8.0f;
            }

            public int m_6604_() {
                return 5;
            }

            public int m_6601_() {
                return 15;
            }

            public Ingredient m_6282_() {
                return Ingredient.m_43927_((ItemStack[])new ItemStack[]{new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get())});
            }
        }, 3, -2.9f, new Item.Properties());
    }

    public InteractionResultHolder<ItemStack> m_7203_(Level world, Player entity, InteractionHand hand) {
        InteractionResultHolder ar = super.m_7203_(world, entity, hand);
        BambooSpartanRightclickedProcedure.execute((Entity)entity, (ItemStack)ar.m_19095_());
        return ar;
    }
}

