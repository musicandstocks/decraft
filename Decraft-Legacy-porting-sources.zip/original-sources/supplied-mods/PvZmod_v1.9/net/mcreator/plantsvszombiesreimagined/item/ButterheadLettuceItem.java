/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.SwordItem
 *  net.minecraft.world.item.Tier
 *  net.minecraft.world.item.crafting.Ingredient
 *  net.minecraft.world.level.ItemLike
 */
package net.mcreator.plantsvszombiesreimagined.item;

import net.mcreator.plantsvszombiesreimagined.init.PlantsvszombiesreimaginedModItems;
import net.mcreator.plantsvszombiesreimagined.procedures.ButterheadLettuceLivingEntityIsHitWithToolProcedure;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;

public class ButterheadLettuceItem
extends SwordItem {
    public ButterheadLettuceItem() {
        super(new Tier(){

            public int m_6609_() {
                return 85;
            }

            public float m_6624_() {
                return 10.0f;
            }

            public float m_6631_() {
                return 5.0f;
            }

            public int m_6604_() {
                return 3;
            }

            public int m_6601_() {
                return 22;
            }

            public Ingredient m_6282_() {
                return Ingredient.m_43927_((ItemStack[])new ItemStack[]{new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get())});
            }
        }, 3, -2.4f, new Item.Properties());
    }

    public boolean m_7579_(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
        boolean retval = super.m_7579_(itemstack, entity, sourceentity);
        ButterheadLettuceLivingEntityIsHitWithToolProcedure.execute((Entity)entity);
        return retval;
    }
}

