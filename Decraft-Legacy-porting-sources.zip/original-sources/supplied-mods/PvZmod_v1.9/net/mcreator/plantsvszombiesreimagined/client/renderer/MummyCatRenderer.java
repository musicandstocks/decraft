/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.OcelotModel
 *  net.minecraft.client.model.geom.ModelLayers
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.entity.MummyCatEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.OcelotModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MummyCatRenderer
extends MobRenderer<MummyCatEntity, OcelotModel<MummyCatEntity>> {
    public MummyCatRenderer(EntityRendererProvider.Context context) {
        super(context, (EntityModel)new OcelotModel(context.m_174023_(ModelLayers.f_171201_)), 0.5f);
    }

    public ResourceLocation getTextureLocation(MummyCatEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/mummycat.png");
    }
}

