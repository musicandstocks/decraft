/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelcannon;
import net.mcreator.plantsvszombiesreimagined.entity.ImpCannonEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ImpCannonRenderer
extends MobRenderer<ImpCannonEntity, Modelcannon<ImpCannonEntity>> {
    public ImpCannonRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelcannon(context.m_174023_(Modelcannon.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(ImpCannonEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/cannon3.png");
    }
}

