/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modeloctopi;
import net.mcreator.plantsvszombiesreimagined.entity.OctopiEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class OctopiRenderer
extends MobRenderer<OctopiEntity, Modeloctopi<OctopiEntity>> {
    public OctopiRenderer(EntityRendererProvider.Context context) {
        super(context, new Modeloctopi(context.m_174023_(Modeloctopi.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(OctopiEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/octopi.png");
    }
}

