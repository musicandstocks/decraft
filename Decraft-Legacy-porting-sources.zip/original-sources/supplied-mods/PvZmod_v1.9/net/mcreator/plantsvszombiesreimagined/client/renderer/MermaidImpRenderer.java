/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelmermaid_imp;
import net.mcreator.plantsvszombiesreimagined.entity.MermaidImpEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MermaidImpRenderer
extends MobRenderer<MermaidImpEntity, Modelmermaid_imp<MermaidImpEntity>> {
    public MermaidImpRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelmermaid_imp(context.m_174023_(Modelmermaid_imp.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(MermaidImpEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/mermaidimp.png");
    }
}

