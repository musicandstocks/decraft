/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelmummy;
import net.mcreator.plantsvszombiesreimagined.entity.BananaZombieEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class BananaZombieRenderer
extends MobRenderer<BananaZombieEntity, Modelmummy<BananaZombieEntity>> {
    public BananaZombieRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelmummy(context.m_174023_(Modelmummy.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(BananaZombieEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/halloween_banana.png");
    }
}

