/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modeldeepseagarg;
import net.mcreator.plantsvszombiesreimagined.entity.SeaGargantuarEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class SeaGargantuarRenderer
extends MobRenderer<SeaGargantuarEntity, Modeldeepseagarg<SeaGargantuarEntity>> {
    public SeaGargantuarRenderer(EntityRendererProvider.Context context) {
        super(context, new Modeldeepseagarg(context.m_174023_(Modeldeepseagarg.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(SeaGargantuarEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/deepsea_garg3.png");
    }
}

