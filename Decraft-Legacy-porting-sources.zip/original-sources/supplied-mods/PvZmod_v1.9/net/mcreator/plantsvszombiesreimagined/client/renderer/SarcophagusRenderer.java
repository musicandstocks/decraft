/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelsarcaphagus;
import net.mcreator.plantsvszombiesreimagined.entity.SarcophagusEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class SarcophagusRenderer
extends MobRenderer<SarcophagusEntity, Modelsarcaphagus<SarcophagusEntity>> {
    public SarcophagusRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelsarcaphagus(context.m_174023_(Modelsarcaphagus.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(SarcophagusEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/sarcaphagus_2.png");
    }
}

