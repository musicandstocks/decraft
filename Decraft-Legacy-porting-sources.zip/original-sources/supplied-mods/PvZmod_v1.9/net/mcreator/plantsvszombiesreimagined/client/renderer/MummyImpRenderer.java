/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelimp_fixed;
import net.mcreator.plantsvszombiesreimagined.entity.MummyImpEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MummyImpRenderer
extends MobRenderer<MummyImpEntity, Modelimp_fixed<MummyImpEntity>> {
    public MummyImpRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelimp_fixed(context.m_174023_(Modelimp_fixed.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(MummyImpEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/mummy.png");
    }
}

