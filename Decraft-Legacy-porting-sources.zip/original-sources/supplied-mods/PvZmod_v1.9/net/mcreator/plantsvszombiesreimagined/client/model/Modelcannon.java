/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Entity
 */
package net.mcreator.plantsvszombiesreimagined.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

public class Modelcannon<T extends Entity>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("plantsvszombiesreimagined", "modelcannon"), "main");
    public final ModelPart left_wheels;
    public final ModelPart right_wheels2;
    public final ModelPart base;
    public final ModelPart cannon;

    public Modelcannon(ModelPart root) {
        this.left_wheels = root.m_171324_("left_wheels");
        this.right_wheels2 = root.m_171324_("right_wheels2");
        this.base = root.m_171324_("base");
        this.cannon = root.m_171324_("cannon");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.m_171576_();
        PartDefinition left_wheels = partdefinition.m_171599_("left_wheels", CubeListBuilder.m_171558_().m_171514_(55, 4).m_171488_(3.0f, -3.0f, -2.0f, 1.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)).m_171514_(55, 4).m_171488_(3.0f, -3.0f, 3.0f, 1.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)24.0f, (float)1.0f));
        PartDefinition right_wheels2 = partdefinition.m_171599_("right_wheels2", CubeListBuilder.m_171558_().m_171514_(55, 4).m_171488_(3.0f, -3.0f, -2.0f, 1.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)).m_171514_(55, 4).m_171488_(3.0f, -3.0f, 3.0f, 1.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-7.0f, (float)24.0f, (float)1.0f));
        PartDefinition base = partdefinition.m_171599_("base", CubeListBuilder.m_171558_().m_171514_(1, 15).m_171488_(-3.0f, -4.0f, -2.0f, 6.0f, 2.0f, 8.0f, new CubeDeformation(0.0f)).m_171514_(0, 2).m_171488_(2.0f, -7.0f, -2.0f, 1.0f, 3.0f, 8.0f, new CubeDeformation(0.0f)).m_171514_(1, 2).m_171488_(-3.0f, -7.0f, -2.0f, 1.0f, 3.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)24.0f, (float)1.0f));
        PartDefinition cannon = partdefinition.m_171599_("cannon", CubeListBuilder.m_171558_().m_171514_(28, 22).m_171488_(-2.0f, -8.0f, -7.0f, 4.0f, 4.0f, 14.0f, new CubeDeformation(0.0f)).m_171514_(56, 31).m_171488_(-1.0f, -7.0f, 7.0f, 2.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)24.0f, (float)1.0f));
        return LayerDefinition.m_171565_((MeshDefinition)meshdefinition, (int)64, (int)64);
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.left_wheels.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_wheels2.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.base.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.cannon.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void m_6973_(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
    }
}

