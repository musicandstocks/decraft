/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Entity
 */
package net.mcreator.plantsvszombiesreimagined.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

public class Modeldolphinzombie<T extends Entity>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("plantsvszombiesreimagined", "modeldolphinzombie"), "main");
    public final ModelPart zombie;
    public final ModelPart dolphin;

    public Modeldolphinzombie(ModelPart root) {
        this.zombie = root.m_171324_("zombie");
        this.dolphin = root.m_171324_("dolphin");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.m_171576_();
        PartDefinition zombie = partdefinition.m_171599_("zombie", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-7.0f, -34.0f, -3.0f, 8.0f, 8.0f, 8.0f, new CubeDeformation(0.0f)).m_171514_(16, 16).m_171488_(-7.0f, -26.0f, -1.0f, 8.0f, 12.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)3.0f, (float)29.0f, (float)-2.0f));
        PartDefinition cube_r1 = zombie.m_171599_("cube_r1", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171488_(-13.0f, -11.0f, -1.0f, 4.0f, 12.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.5236f));
        PartDefinition cube_r2 = zombie.m_171599_("cube_r2", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171488_(4.0f, -14.0f, -1.0f, 4.0f, 12.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.5236f));
        PartDefinition cube_r3 = zombie.m_171599_("cube_r3", CubeListBuilder.m_171558_().m_171514_(40, 16).m_171488_(-11.0f, -22.0f, -17.0f, 4.0f, 12.0f, 4.0f, new CubeDeformation(0.0f)).m_171514_(40, 16).m_171488_(1.0f, -22.0f, -17.0f, 4.0f, 12.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.6981f, (float)0.0f, (float)0.0f));
        PartDefinition dolphin = partdefinition.m_171599_("dolphin", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)0.0f, (float)24.0f, (float)0.0f));
        PartDefinition head = dolphin.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 35).m_171488_(-4.0f, -3.0f, -3.0f, 8.0f, 7.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-4.0f, (float)-6.0f));
        PartDefinition body = dolphin.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(0, 48).m_171488_(-1.0f, -2.0f, -10.0f, 2.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)).m_171514_(22, 35).m_171488_(-4.0f, -7.0f, 0.0f, 8.0f, 7.0f, 13.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-3.0f));
        PartDefinition tail = dolphin.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(0, 54).m_171488_(-2.0f, -2.5f, -1.0f, 4.0f, 5.0f, 11.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-2.5f, (float)11.0f));
        PartDefinition right_fin = dolphin.m_171599_("right_fin", CubeListBuilder.m_171558_().m_171514_(48, 55).m_171488_(-0.5f, -4.0f, 0.0f, 1.0f, 4.0f, 7.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-4.5f, (float)0.0f, (float)-2.0f));
        PartDefinition left_fin = dolphin.m_171599_("left_fin", CubeListBuilder.m_171558_().m_171514_(48, 55).m_171488_(-0.5f, -4.0f, 0.0f, 1.0f, 4.0f, 7.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)4.5f, (float)0.0f, (float)-2.0f));
        PartDefinition back_fin = dolphin.m_171599_("back_fin", CubeListBuilder.m_171558_().m_171514_(51, 35).m_171488_(-0.5f, 0.0f, 8.0f, 1.0f, 4.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-11.0f, (float)-5.0f));
        PartDefinition tail_fin = dolphin.m_171599_("tail_fin", CubeListBuilder.m_171558_().m_171514_(19, 55).m_171488_(-5.0f, -0.5f, -1.0f, 10.0f, 1.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-2.5f, (float)20.0f));
        return LayerDefinition.m_171565_((MeshDefinition)meshdefinition, (int)70, (int)70);
    }

    public void m_6973_(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.zombie.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.dolphin.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

