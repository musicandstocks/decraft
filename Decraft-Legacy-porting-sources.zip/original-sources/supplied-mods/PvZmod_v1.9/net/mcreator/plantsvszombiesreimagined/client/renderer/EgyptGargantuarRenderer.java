/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelgargantarwimp_egypt;
import net.mcreator.plantsvszombiesreimagined.entity.EgyptGargantuarEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class EgyptGargantuarRenderer
extends MobRenderer<EgyptGargantuarEntity, Modelgargantarwimp_egypt<EgyptGargantuarEntity>> {
    public EgyptGargantuarRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelgargantarwimp_egypt(context.m_174023_(Modelgargantarwimp_egypt.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(EgyptGargantuarEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/gargantarw_imp_egypt3.png");
    }
}

