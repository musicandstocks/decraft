/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelmummy;
import net.mcreator.plantsvszombiesreimagined.entity.DolphinZomEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class DolphinZomRenderer
extends MobRenderer<DolphinZomEntity, Modelmummy<DolphinZomEntity>> {
    public DolphinZomRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelmummy(context.m_174023_(Modelmummy.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(DolphinZomEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/dolphin_zombie_base.png");
    }
}

