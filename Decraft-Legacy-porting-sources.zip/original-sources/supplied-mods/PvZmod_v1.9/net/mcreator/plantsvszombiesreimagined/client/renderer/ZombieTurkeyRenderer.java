/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelturkey;
import net.mcreator.plantsvszombiesreimagined.entity.ZombieTurkeyEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ZombieTurkeyRenderer
extends MobRenderer<ZombieTurkeyEntity, Modelturkey<ZombieTurkeyEntity>> {
    public ZombieTurkeyRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelturkey(context.m_174023_(Modelturkey.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(ZombieTurkeyEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/chicken.png");
    }
}

