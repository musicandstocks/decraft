/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelconehead2;
import net.mcreator.plantsvszombiesreimagined.entity.ConeheadZombieEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ConeheadZombieRenderer
extends MobRenderer<ConeheadZombieEntity, Modelconehead2<ConeheadZombieEntity>> {
    public ConeheadZombieRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelconehead2(context.m_174023_(Modelconehead2.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(ConeheadZombieEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/conehead_fixed.png");
    }
}

