/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Entity
 */
package net.mcreator.plantsvszombiesreimagined.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

public class Modeloctopi<T extends Entity>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("plantsvszombiesreimagined", "modeloctopi"), "main");
    public final ModelPart body;
    public final ModelPart tentacle1;

    public Modeloctopi(ModelPart root) {
        this.body = root.m_171324_("body");
        this.tentacle1 = root.m_171324_("tentacle1");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.m_171576_();
        PartDefinition body = partdefinition.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(9, 4).m_171488_(-2.0f, -2.0f, -4.0f, 8.0f, 10.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.0f, (float)6.0f, (float)1.0f));
        PartDefinition tentacle1 = partdefinition.m_171599_("tentacle1", CubeListBuilder.m_171558_().m_171514_(48, 0).m_171488_(2.0f, 8.0f, 1.0f, 2.0f, 8.0f, 2.0f, new CubeDeformation(0.0f)).m_171514_(48, 0).m_171488_(2.0f, 8.0f, 4.0f, 2.0f, 8.0f, 2.0f, new CubeDeformation(0.0f)).m_171514_(48, 0).m_171488_(2.0f, 8.0f, 7.0f, 2.0f, 8.0f, 2.0f, new CubeDeformation(0.0f)).m_171514_(48, 0).m_171488_(8.0f, 8.0f, 7.0f, 2.0f, 8.0f, 2.0f, new CubeDeformation(0.0f)).m_171514_(48, 0).m_171488_(5.0f, 8.0f, 7.0f, 2.0f, 8.0f, 2.0f, new CubeDeformation(0.0f)).m_171514_(48, 0).m_171488_(8.0f, 8.0f, 1.0f, 2.0f, 8.0f, 2.0f, new CubeDeformation(0.0f)).m_171514_(48, 0).m_171488_(5.0f, 8.0f, 1.0f, 2.0f, 8.0f, 2.0f, new CubeDeformation(0.0f)).m_171514_(48, 0).m_171488_(8.0f, 8.0f, 4.0f, 2.0f, 8.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)5.0f, (float)6.0f, (float)-5.0f, (float)0.0f, (float)-1.5708f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)meshdefinition, (int)64, (int)32);
    }

    public void m_6973_(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.body.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tentacle1.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

