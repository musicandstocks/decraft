/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 */
package net.mcreator.plantsvszombiesreimagined.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

public class Modelseagullzombie<T extends Entity>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("plantsvszombiesreimagined", "modelseagullzombie"), "main");
    public final ModelPart zombie;
    public final ModelPart seagull;
    public final ModelPart left_wing;
    public final ModelPart right_wing;

    public Modelseagullzombie(ModelPart root) {
        this.zombie = root.m_171324_("zombie");
        this.seagull = root.m_171324_("seagull");
        this.left_wing = root.m_171324_("left_wing");
        this.right_wing = root.m_171324_("right_wing");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.m_171576_();
        PartDefinition zombie = partdefinition.m_171599_("zombie", CubeListBuilder.m_171558_(), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)1.0f, (float)0.0f, (float)0.0433f, (float)-3.1359f));
        PartDefinition head = zombie.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-24.0f, (float)0.0f));
        PartDefinition headwear = zombie.m_171599_("headwear", CubeListBuilder.m_171558_().m_171514_(32, 0).m_171488_(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f, new CubeDeformation(0.5f)), PartPose.m_171419_((float)0.0f, (float)-24.0f, (float)0.0f));
        PartDefinition body = zombie.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(16, 16).m_171488_(-4.0f, 0.0f, -2.0f, 8.0f, 12.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-24.0f, (float)0.0f));
        PartDefinition left_arm = zombie.m_171599_("left_arm", CubeListBuilder.m_171558_().m_171514_(32, 48).m_171480_().m_171488_(-1.0f, -2.0f, -2.0f, 4.0f, 12.0f, 4.0f, new CubeDeformation(0.0f)).m_171555_(false), PartPose.m_171419_((float)5.0f, (float)-22.0f, (float)0.0f));
        PartDefinition right_arm = zombie.m_171599_("right_arm", CubeListBuilder.m_171558_().m_171514_(40, 16).m_171488_(-3.0f, -2.0f, -2.0f, 4.0f, 12.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-5.0f, (float)-22.0f, (float)0.0f));
        PartDefinition left_leg = zombie.m_171599_("left_leg", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171480_().m_171488_(-1.9f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f, new CubeDeformation(0.0f)).m_171555_(false), PartPose.m_171419_((float)1.9f, (float)-12.0f, (float)0.0f));
        PartDefinition right_leg = zombie.m_171599_("right_leg", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171488_(-2.1f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-1.9f, (float)-13.0f, (float)0.0f, (float)0.3927f, (float)0.0f, (float)0.0f));
        PartDefinition seagull = partdefinition.m_171599_("seagull", CubeListBuilder.m_171558_().m_171514_(0, 34).m_171488_(-1.0f, 6.0f, -6.0f, 3.0f, 4.0f, 7.0f, new CubeDeformation(0.0f)).m_171514_(38, 41).m_171488_(-1.0f, 10.0f, 0.0f, 1.0f, 3.0f, 1.0f, new CubeDeformation(0.0f)).m_171514_(38, 41).m_171488_(1.0f, 10.0f, 0.0f, 1.0f, 3.0f, 1.0f, new CubeDeformation(0.0f)).m_171514_(4, 41).m_171488_(-1.0f, 6.0f, 1.0f, 3.0f, 1.0f, 3.0f, new CubeDeformation(0.0f)).m_171514_(23, 34).m_171488_(-1.0f, 5.0f, -9.0f, 3.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)).m_171514_(38, 42).m_171488_(-1.0f, 7.0f, -11.0f, 3.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-1.9f, (float)-25.0f, (float)1.0f));
        PartDefinition left_wing = partdefinition.m_171599_("left_wing", CubeListBuilder.m_171558_().m_171514_(20, 40).m_171488_(0.0f, -1.0f, -2.0f, 5.0f, 1.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.1f, (float)-18.0f, (float)-3.0f));
        PartDefinition right_wing = partdefinition.m_171599_("right_wing", CubeListBuilder.m_171558_().m_171514_(43, 35).m_171488_(-5.0f, -1.0f, -2.0f, 5.0f, 1.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.9f, (float)-18.0f, (float)-3.0f));
        return LayerDefinition.m_171565_((MeshDefinition)meshdefinition, (int)64, (int)64);
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.zombie.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.seagull.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_wing.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_wing.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void m_6973_(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.right_wing.f_104205_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * limbSwingAmount;
        this.left_wing.f_104205_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * limbSwingAmount;
    }
}

