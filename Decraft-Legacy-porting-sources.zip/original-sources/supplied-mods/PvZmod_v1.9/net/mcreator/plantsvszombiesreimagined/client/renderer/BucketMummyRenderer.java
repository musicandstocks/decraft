/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelmummybuckethead;
import net.mcreator.plantsvszombiesreimagined.entity.BucketMummyEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class BucketMummyRenderer
extends MobRenderer<BucketMummyEntity, Modelmummybuckethead<BucketMummyEntity>> {
    public BucketMummyRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelmummybuckethead(context.m_174023_(Modelmummybuckethead.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(BucketMummyEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/mummybucket2.png");
    }
}

