/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ChickenModel
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayers
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.entity.ZombieChickenEntity;
import net.minecraft.client.model.ChickenModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ZombieChickenRenderer
extends MobRenderer<ZombieChickenEntity, ChickenModel<ZombieChickenEntity>> {
    public ZombieChickenRenderer(EntityRendererProvider.Context context) {
        super(context, (EntityModel)new ChickenModel(context.m_174023_(ModelLayers.f_171277_)), 0.5f);
    }

    public ResourceLocation getTextureLocation(ZombieChickenEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/zombie-chicken-on-planetminecraft-com.png");
    }
}

