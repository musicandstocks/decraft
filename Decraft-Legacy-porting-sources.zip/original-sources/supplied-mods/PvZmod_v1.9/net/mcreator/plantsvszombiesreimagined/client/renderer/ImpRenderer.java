/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelimp_fixed;
import net.mcreator.plantsvszombiesreimagined.entity.ImpEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ImpRenderer
extends MobRenderer<ImpEntity, Modelimp_fixed<ImpEntity>> {
    public ImpRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelimp_fixed(context.m_174023_(Modelimp_fixed.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(ImpEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/zombie.png");
    }
}

