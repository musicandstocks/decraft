/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelneptuna;
import net.mcreator.plantsvszombiesreimagined.entity.NeptunaEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class NeptunaRenderer
extends MobRenderer<NeptunaEntity, Modelneptuna<NeptunaEntity>> {
    public NeptunaRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelneptuna(context.m_174023_(Modelneptuna.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(NeptunaEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/neptuna3.png");
    }
}

