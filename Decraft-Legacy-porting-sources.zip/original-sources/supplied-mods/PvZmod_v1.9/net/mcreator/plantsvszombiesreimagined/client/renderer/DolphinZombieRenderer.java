/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modeldolphinzombie;
import net.mcreator.plantsvszombiesreimagined.entity.DolphinZombieEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class DolphinZombieRenderer
extends MobRenderer<DolphinZombieEntity, Modeldolphinzombie<DolphinZombieEntity>> {
    public DolphinZombieRenderer(EntityRendererProvider.Context context) {
        super(context, new Modeldolphinzombie(context.m_174023_(Modeldolphinzombie.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(DolphinZombieEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/dolphin_zombie.png");
    }
}

