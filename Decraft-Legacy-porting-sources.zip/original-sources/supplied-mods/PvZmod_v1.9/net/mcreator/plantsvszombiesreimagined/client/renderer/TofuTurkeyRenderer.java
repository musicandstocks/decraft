/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelturkey;
import net.mcreator.plantsvszombiesreimagined.entity.TofuTurkeyEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class TofuTurkeyRenderer
extends MobRenderer<TofuTurkeyEntity, Modelturkey<TofuTurkeyEntity>> {
    public TofuTurkeyRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelturkey(context.m_174023_(Modelturkey.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(TofuTurkeyEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/tofu_turkey.png");
    }
}

