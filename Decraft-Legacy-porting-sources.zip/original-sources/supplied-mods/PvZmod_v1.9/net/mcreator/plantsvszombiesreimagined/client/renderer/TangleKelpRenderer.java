/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelplant7;
import net.mcreator.plantsvszombiesreimagined.entity.TangleKelpEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class TangleKelpRenderer
extends MobRenderer<TangleKelpEntity, Modelplant7<TangleKelpEntity>> {
    public TangleKelpRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelplant7(context.m_174023_(Modelplant7.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(TangleKelpEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/tanglekelp.png");
    }
}

