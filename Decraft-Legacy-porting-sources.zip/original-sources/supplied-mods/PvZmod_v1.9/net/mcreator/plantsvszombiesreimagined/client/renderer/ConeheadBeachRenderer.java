/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelconehead2;
import net.mcreator.plantsvszombiesreimagined.entity.ConeheadBeachEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ConeheadBeachRenderer
extends MobRenderer<ConeheadBeachEntity, Modelconehead2<ConeheadBeachEntity>> {
    public ConeheadBeachRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelconehead2(context.m_174023_(Modelconehead2.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(ConeheadBeachEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/beach_zombie_cone.png");
    }
}

