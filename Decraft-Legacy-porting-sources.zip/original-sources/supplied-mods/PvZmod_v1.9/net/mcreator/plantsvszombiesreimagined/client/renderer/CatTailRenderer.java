/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.math.Axis
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.entity.EntityRenderer
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.texture.OverlayTexture
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelcatprojectile;
import net.mcreator.plantsvszombiesreimagined.entity.CatTailEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

public class CatTailRenderer
extends EntityRenderer<CatTailEntity> {
    private static final ResourceLocation texture = new ResourceLocation("plantsvszombiesreimagined:textures/entities/cat.png");
    private final Modelcatprojectile model;

    public CatTailRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.model = new Modelcatprojectile(context.m_174023_(Modelcatprojectile.LAYER_LOCATION));
    }

    public void render(CatTailEntity entityIn, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource bufferIn, int packedLightIn) {
        VertexConsumer vb = bufferIn.m_6299_(RenderType.m_110452_((ResourceLocation)this.getTextureLocation(entityIn)));
        poseStack.m_85836_();
        poseStack.m_252781_(Axis.f_252436_.m_252977_(Mth.m_14179_((float)partialTicks, (float)entityIn.f_19859_, (float)entityIn.m_146908_()) - 90.0f));
        poseStack.m_252781_(Axis.f_252403_.m_252977_(90.0f + Mth.m_14179_((float)partialTicks, (float)entityIn.f_19860_, (float)entityIn.m_146909_())));
        this.model.m_7695_(poseStack, vb, packedLightIn, OverlayTexture.f_118083_, 1.0f, 1.0f, 1.0f, 0.0625f);
        poseStack.m_85849_();
        super.m_7392_((Entity)entityIn, entityYaw, partialTicks, poseStack, bufferIn, packedLightIn);
    }

    public ResourceLocation getTextureLocation(CatTailEntity entity) {
        return texture;
    }
}

