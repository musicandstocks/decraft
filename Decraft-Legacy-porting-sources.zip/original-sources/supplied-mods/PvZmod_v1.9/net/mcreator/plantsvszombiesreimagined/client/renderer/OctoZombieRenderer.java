/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modeloctozombie;
import net.mcreator.plantsvszombiesreimagined.entity.OctoZombieEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class OctoZombieRenderer
extends MobRenderer<OctoZombieEntity, Modeloctozombie<OctoZombieEntity>> {
    public OctoZombieRenderer(EntityRendererProvider.Context context) {
        super(context, new Modeloctozombie(context.m_174023_(Modeloctozombie.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(OctoZombieEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/octozombie.png");
    }
}

