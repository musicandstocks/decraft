/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelgargantarwimp;
import net.mcreator.plantsvszombiesreimagined.entity.GargantuarEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GargantuarRenderer
extends MobRenderer<GargantuarEntity, Modelgargantarwimp<GargantuarEntity>> {
    public GargantuarRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelgargantarwimp(context.m_174023_(Modelgargantarwimp.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(GargantuarEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/gargantarw_imp.png");
    }
}

