/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelseagullzombie;
import net.mcreator.plantsvszombiesreimagined.entity.SeagullZombieEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class SeagullZombieRenderer
extends MobRenderer<SeagullZombieEntity, Modelseagullzombie<SeagullZombieEntity>> {
    public SeagullZombieRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelseagullzombie(context.m_174023_(Modelseagullzombie.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(SeagullZombieEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/seagull2.png");
    }
}

