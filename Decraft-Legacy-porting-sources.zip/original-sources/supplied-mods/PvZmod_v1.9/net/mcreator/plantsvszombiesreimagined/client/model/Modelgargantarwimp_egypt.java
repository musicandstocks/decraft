/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 */
package net.mcreator.plantsvszombiesreimagined.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

public class Modelgargantarwimp_egypt<T extends Entity>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("plantsvszombiesreimagined", "modelgargantarwimp_egypt"), "main");
    public final ModelPart head;
    public final ModelPart torso;
    public final ModelPart left_arm;
    public final ModelPart right_arm;
    public final ModelPart left_leg;
    public final ModelPart right_leg;

    public Modelgargantarwimp_egypt(ModelPart root) {
        this.head = root.m_171324_("head");
        this.torso = root.m_171324_("torso");
        this.left_arm = root.m_171324_("left_arm");
        this.right_arm = root.m_171324_("right_arm");
        this.left_leg = root.m_171324_("left_leg");
        this.right_leg = root.m_171324_("right_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.m_171576_();
        PartDefinition head = partdefinition.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 32).m_171488_(-5.0f, -7.0f, -9.0f, 10.0f, 10.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-10.0f, (float)-1.0f));
        PartDefinition torso = partdefinition.m_171599_("torso", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-9.0f, -13.0f, -4.0f, 18.0f, 21.0f, 11.0f, new CubeDeformation(0.0f)).m_171514_(62, 96).m_171488_(-8.0f, -10.0f, 1.0f, 16.0f, 15.0f, 16.0f, new CubeDeformation(0.0f)).m_171514_(16, 114).m_171488_(-4.0f, -16.0f, 9.0f, 8.0f, 6.0f, 4.0f, new CubeDeformation(0.0f)).m_171514_(6, 59).m_171488_(4.0f, -16.0f, 5.0f, 3.0f, 3.0f, 7.0f, new CubeDeformation(0.0f)).m_171514_(6, 59).m_171488_(-7.0f, -16.0f, 5.0f, 3.0f, 3.0f, 7.0f, new CubeDeformation(0.0f)).m_171514_(1, 97).m_171488_(-4.0f, -23.0f, 7.0f, 8.0f, 7.0f, 7.0f, new CubeDeformation(0.0f)).m_171514_(50, 77).m_171488_(4.0f, -16.0f, 3.0f, 3.0f, 4.0f, 2.0f, new CubeDeformation(0.0f)).m_171514_(19, 105).m_171488_(-7.0f, -16.0f, 3.0f, 3.0f, 4.0f, 2.0f, new CubeDeformation(0.0f)).m_171514_(29, 119).m_171488_(1.0f, -26.0f, 12.0f, 2.0f, 4.0f, 2.0f, new CubeDeformation(0.0f)).m_171514_(29, 119).m_171488_(-3.0f, -26.0f, 12.0f, 2.0f, 4.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-1.0f));
        PartDefinition left_arm = partdefinition.m_171599_("left_arm", CubeListBuilder.m_171558_().m_171514_(0, 58).m_171488_(-4.0f, 0.0f, -4.0f, 8.0f, 28.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)13.0f, (float)-10.0f, (float)0.0f));
        PartDefinition cube_r1 = left_arm.m_171599_("cube_r1", CubeListBuilder.m_171558_().m_171514_(97, 33).m_171488_(-17.0f, -21.0f, 5.0f, 8.0f, 8.0f, 7.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-13.0f, (float)13.0f, (float)-1.0f, (float)2.0071f, (float)0.0f, (float)-3.1416f));
        PartDefinition cube_r2 = left_arm.m_171599_("cube_r2", CubeListBuilder.m_171558_().m_171514_(81, 0).m_171488_(-5.0f, -5.0f, 16.0f, 10.0f, 22.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-1.789f, (float)0.0f, (float)0.0f));
        PartDefinition right_arm = partdefinition.m_171599_("right_arm", CubeListBuilder.m_171558_().m_171514_(44, 50).m_171488_(-4.0f, 0.0f, -4.0f, 8.0f, 28.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-13.0f, (float)-10.0f, (float)0.0f));
        PartDefinition left_leg = partdefinition.m_171599_("left_leg", CubeListBuilder.m_171558_().m_171514_(76, 76).m_171488_(-3.9f, 0.0f, -3.0f, 6.0f, 13.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)6.0f, (float)11.0f, (float)-1.0f));
        PartDefinition right_leg = partdefinition.m_171599_("right_leg", CubeListBuilder.m_171558_().m_171514_(76, 48).m_171488_(-2.1f, 0.0f, -3.0f, 6.0f, 13.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-6.0f, (float)11.0f, (float)-1.0f));
        return LayerDefinition.m_171565_((MeshDefinition)meshdefinition, (int)128, (int)128);
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.head.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.torso.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_arm.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_arm.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_leg.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_leg.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void m_6973_(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.f_104204_ = netHeadYaw / 57.295776f;
        this.head.f_104203_ = headPitch / 57.295776f;
        this.right_arm.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * limbSwingAmount;
        this.left_leg.f_104203_ = Mth.m_14089_((float)(limbSwing * 1.0f)) * -1.0f * limbSwingAmount;
        this.left_arm.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * limbSwingAmount;
        this.right_leg.f_104203_ = Mth.m_14089_((float)(limbSwing * 1.0f)) * 1.0f * limbSwingAmount;
    }
}

