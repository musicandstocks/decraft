/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 */
package net.mcreator.plantsvszombiesreimagined.client.renderer;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelparrot;
import net.mcreator.plantsvszombiesreimagined.entity.ZombieParrotEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ZombieParrotRenderer
extends MobRenderer<ZombieParrotEntity, Modelparrot<ZombieParrotEntity>> {
    public ZombieParrotRenderer(EntityRendererProvider.Context context) {
        super(context, new Modelparrot(context.m_174023_(Modelparrot.LAYER_LOCATION)), 0.5f);
    }

    public ResourceLocation getTextureLocation(ZombieParrotEntity entity) {
        return new ResourceLocation("plantsvszombiesreimagined:textures/entities/zombieparrot.png");
    }
}

