/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 */
package net.mcreator.plantsvszombiesreimagined.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

public class Modelparrot<T extends Entity>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("plantsvszombiesreimagined", "modelparrot"), "main");
    public final ModelPart head;
    public final ModelPart body;
    public final ModelPart left_wing;
    public final ModelPart right_wing;
    public final ModelPart left_leg;
    public final ModelPart right_leg;
    public final ModelPart tail;

    public Modelparrot(ModelPart root) {
        this.head = root.m_171324_("head");
        this.body = root.m_171324_("body");
        this.left_wing = root.m_171324_("left_wing");
        this.right_wing = root.m_171324_("right_wing");
        this.left_leg = root.m_171324_("left_leg");
        this.right_leg = root.m_171324_("right_leg");
        this.tail = root.m_171324_("tail");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.m_171576_();
        PartDefinition head = partdefinition.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(2, 2).m_171488_(-1.0f, -1.5f, -1.0f, 2.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)).m_171514_(10, 0).m_171488_(-1.0f, -2.5f, -3.0f, 2.0f, 1.0f, 4.0f, new CubeDeformation(0.0f)).m_171514_(11, 7).m_171488_(-0.5f, -1.5f, -2.0f, 1.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)).m_171514_(16, 7).m_171488_(-0.5f, -1.75f, -2.95f, 1.0f, 2.0f, 1.0f, new CubeDeformation(-0.01f)), PartPose.m_171419_((float)0.0f, (float)16.0f, (float)-0.5f));
        PartDefinition feather = head.m_171599_("feather", CubeListBuilder.m_171558_().m_171514_(2, 18).m_171488_(0.0f, -5.0f, 0.0f, 0.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-1.5f, (float)-2.0f, (float)-0.2618f, (float)0.0f, (float)0.0f));
        PartDefinition body = partdefinition.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(2, 8).m_171488_(-1.5f, 0.0f, -1.5f, 3.0f, 6.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)16.5f, (float)-1.0f));
        PartDefinition left_wing = partdefinition.m_171599_("left_wing", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)1.5f, (float)16.9f, (float)-0.8f));
        PartDefinition left_wing_rotation = left_wing.m_171599_("left_wing_rotation", CubeListBuilder.m_171558_().m_171514_(19, 8).m_171488_(-0.5f, -2.5f, -1.5f, 1.0f, 5.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)2.5f, (float)0.0f, (float)0.0f, (float)3.1416f, (float)0.0f));
        PartDefinition right_wing = partdefinition.m_171599_("right_wing", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)-1.5f, (float)16.9f, (float)-0.8f));
        PartDefinition right_wing_rotation = right_wing.m_171599_("right_wing_rotation", CubeListBuilder.m_171558_().m_171514_(19, 8).m_171488_(-0.5f, -2.5f, -1.5f, 1.0f, 5.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)2.5f, (float)0.0f, (float)0.0f, (float)3.1416f, (float)0.0f));
        PartDefinition left_leg = partdefinition.m_171599_("left_leg", CubeListBuilder.m_171558_().m_171514_(14, 18).m_171488_(-2.5f, 0.0f, -0.5f, 1.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)1.0f, (float)22.0f, (float)-1.0f));
        PartDefinition right_leg = partdefinition.m_171599_("right_leg", CubeListBuilder.m_171558_().m_171514_(14, 18).m_171488_(1.5f, 0.0f, -0.5f, 1.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-1.0f, (float)22.0f, (float)-1.0f));
        PartDefinition tail = partdefinition.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(22, 1).m_171488_(-1.5f, -1.0f, -1.0f, 3.0f, 4.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)21.1f, (float)1.2f));
        return LayerDefinition.m_171565_((MeshDefinition)meshdefinition, (int)32, (int)32);
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.head.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.body.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_wing.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_wing.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_leg.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_leg.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void m_6973_(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.f_104204_ = netHeadYaw / 57.295776f;
        this.head.f_104203_ = headPitch / 57.295776f;
        this.left_leg.f_104203_ = Mth.m_14089_((float)(limbSwing * 1.0f)) * -1.0f * limbSwingAmount;
        this.right_wing.f_104205_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * limbSwingAmount;
        this.right_leg.f_104203_ = Mth.m_14089_((float)(limbSwing * 1.0f)) * 1.0f * limbSwingAmount;
        this.left_wing.f_104205_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * limbSwingAmount;
    }
}

