/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.block.Block
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package net.mcreator.plantsvszombiesreimagined.init;

import net.mcreator.plantsvszombiesreimagined.block.AncientEgyptPortalBlock;
import net.mcreator.plantsvszombiesreimagined.block.BabyPoisonMineBlock;
import net.mcreator.plantsvszombiesreimagined.block.BabyPotatoMineBlock;
import net.mcreator.plantsvszombiesreimagined.block.BannanaBlock;
import net.mcreator.plantsvszombiesreimagined.block.BloomerangPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.BonkPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.BowlingBulbPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.ButterheadLettucePlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.CandyCornBlock;
import net.mcreator.plantsvszombiesreimagined.block.ChiliBeanPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.CoconutCannonPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.FleshBlockBlock;
import net.mcreator.plantsvszombiesreimagined.block.GhostPepperPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.HolidayPortalBlock;
import net.mcreator.plantsvszombiesreimagined.block.HollyPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.IcebergPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.JackPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.KernelPultPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.LightningReedPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.MarigoldBlock;
import net.mcreator.plantsvszombiesreimagined.block.MelonPultPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.NavyBeanPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.ParsnipPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.PeaPodPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.PirateBeachPortalBlock;
import net.mcreator.plantsvszombiesreimagined.block.PlanternBlock;
import net.mcreator.plantsvszombiesreimagined.block.PoisonPotatoMineBlock;
import net.mcreator.plantsvszombiesreimagined.block.PotatoMineBlock;
import net.mcreator.plantsvszombiesreimagined.block.PuffshroomPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.PumpPultPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.PumpkinPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.RepeaterPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.SapBlock;
import net.mcreator.plantsvszombiesreimagined.block.SapflingPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.SeaFloraPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.SnapPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.SpikeRockBlock;
import net.mcreator.plantsvszombiesreimagined.block.SpikeWeedBlock;
import net.mcreator.plantsvszombiesreimagined.block.SpringBeanPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.SunflowerBlock;
import net.mcreator.plantsvszombiesreimagined.block.SunshroomBlock;
import net.mcreator.plantsvszombiesreimagined.block.SweetPeaPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.SweetPotatoPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.TallNutPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.TurkeyPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.TwinSunflowerBlock;
import net.mcreator.plantsvszombiesreimagined.block.WasabiWhipPlantBlock;
import net.mcreator.plantsvszombiesreimagined.block.WildWestPortalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;

public class PlantsvszombiesreimaginedModBlocks {
    public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create((IForgeRegistry)ForgeRegistries.BLOCKS, (String)"plantsvszombiesreimagined");
    public static final RegistryObject<Block> SUNFLOWER = REGISTRY.register("sunflower", () -> new SunflowerBlock());
    public static final RegistryObject<Block> SUNSHROOM = REGISTRY.register("sunshroom", () -> new SunshroomBlock());
    public static final RegistryObject<Block> POTATO_MINE = REGISTRY.register("potato_mine", () -> new PotatoMineBlock());
    public static final RegistryObject<Block> BABY_POTATO_MINE = REGISTRY.register("baby_potato_mine", () -> new BabyPotatoMineBlock());
    public static final RegistryObject<Block> PUFFSHROOM_PLANT = REGISTRY.register("puffshroom_plant", () -> new PuffshroomPlantBlock());
    public static final RegistryObject<Block> MARIGOLD = REGISTRY.register("marigold", () -> new MarigoldBlock());
    public static final RegistryObject<Block> FLESH_BLOCK = REGISTRY.register("flesh_block", () -> new FleshBlockBlock());
    public static final RegistryObject<Block> PLANTERN = REGISTRY.register("plantern", () -> new PlanternBlock());
    public static final RegistryObject<Block> ANCIENT_EGYPT_PORTAL = REGISTRY.register("ancient_egypt_portal", () -> new AncientEgyptPortalBlock());
    public static final RegistryObject<Block> REPEATER_PLANT = REGISTRY.register("repeater_plant", () -> new RepeaterPlantBlock());
    public static final RegistryObject<Block> BLOOMERANG_PLANT = REGISTRY.register("bloomerang_plant", () -> new BloomerangPlantBlock());
    public static final RegistryObject<Block> ICEBERG_PLANT = REGISTRY.register("iceberg_plant", () -> new IcebergPlantBlock());
    public static final RegistryObject<Block> BONK_PLANT = REGISTRY.register("bonk_plant", () -> new BonkPlantBlock());
    public static final RegistryObject<Block> TWIN_SUNFLOWER = REGISTRY.register("twin_sunflower", () -> new TwinSunflowerBlock());
    public static final RegistryObject<Block> BABY_POISON_MINE = REGISTRY.register("baby_poison_mine", () -> new BabyPoisonMineBlock());
    public static final RegistryObject<Block> POISON_POTATO_MINE = REGISTRY.register("poison_potato_mine", () -> new PoisonPotatoMineBlock());
    public static final RegistryObject<Block> PIRATE_BEACH_PORTAL = REGISTRY.register("pirate_beach_portal", () -> new PirateBeachPortalBlock());
    public static final RegistryObject<Block> KERNEL_PULT_PLANT = REGISTRY.register("kernel_pult_plant", () -> new KernelPultPlantBlock());
    public static final RegistryObject<Block> SNAP_PLANT = REGISTRY.register("snap_plant", () -> new SnapPlantBlock());
    public static final RegistryObject<Block> SPIKE_WEED = REGISTRY.register("spike_weed", () -> new SpikeWeedBlock());
    public static final RegistryObject<Block> SPIKE_ROCK = REGISTRY.register("spike_rock", () -> new SpikeRockBlock());
    public static final RegistryObject<Block> COCONUT_CANNON_PLANT = REGISTRY.register("coconut_cannon_plant", () -> new CoconutCannonPlantBlock());
    public static final RegistryObject<Block> SPRING_BEAN_PLANT = REGISTRY.register("spring_bean_plant", () -> new SpringBeanPlantBlock());
    public static final RegistryObject<Block> BOWLING_BULB_PLANT = REGISTRY.register("bowling_bulb_plant", () -> new BowlingBulbPlantBlock());
    public static final RegistryObject<Block> BANNANA = REGISTRY.register("bannana", () -> new BannanaBlock());
    public static final RegistryObject<Block> WASABI_WHIP_PLANT = REGISTRY.register("wasabi_whip_plant", () -> new WasabiWhipPlantBlock());
    public static final RegistryObject<Block> NAVY_BEAN_PLANT = REGISTRY.register("navy_bean_plant", () -> new NavyBeanPlantBlock());
    public static final RegistryObject<Block> SEA_FLORA_PLANT = REGISTRY.register("sea_flora_plant", () -> new SeaFloraPlantBlock());
    public static final RegistryObject<Block> CHILI_BEAN_PLANT = REGISTRY.register("chili_bean_plant", () -> new ChiliBeanPlantBlock());
    public static final RegistryObject<Block> HOLIDAY_PORTAL = REGISTRY.register("holiday_portal", () -> new HolidayPortalBlock());
    public static final RegistryObject<Block> PUMPKIN_PLANT = REGISTRY.register("pumpkin_plant", () -> new PumpkinPlantBlock());
    public static final RegistryObject<Block> GHOST_PEPPER_PLANT = REGISTRY.register("ghost_pepper_plant", () -> new GhostPepperPlantBlock());
    public static final RegistryObject<Block> SWEET_PEA_PLANT = REGISTRY.register("sweet_pea_plant", () -> new SweetPeaPlantBlock());
    public static final RegistryObject<Block> CANDY_CORN = REGISTRY.register("candy_corn", () -> new CandyCornBlock());
    public static final RegistryObject<Block> JACK_PLANT = REGISTRY.register("jack_plant", () -> new JackPlantBlock());
    public static final RegistryObject<Block> WILD_WEST_PORTAL = REGISTRY.register("wild_west_portal", () -> new WildWestPortalBlock());
    public static final RegistryObject<Block> LIGHTNING_REED_PLANT = REGISTRY.register("lightning_reed_plant", () -> new LightningReedPlantBlock());
    public static final RegistryObject<Block> MELON_PULT_PLANT = REGISTRY.register("melon_pult_plant", () -> new MelonPultPlantBlock());
    public static final RegistryObject<Block> PUMP_PULT_PLANT = REGISTRY.register("pump_pult_plant", () -> new PumpPultPlantBlock());
    public static final RegistryObject<Block> TURKEY_PLANT = REGISTRY.register("turkey_plant", () -> new TurkeyPlantBlock());
    public static final RegistryObject<Block> SWEET_POTATO_PLANT = REGISTRY.register("sweet_potato_plant", () -> new SweetPotatoPlantBlock());
    public static final RegistryObject<Block> PARSNIP_PLANT = REGISTRY.register("parsnip_plant", () -> new ParsnipPlantBlock());
    public static final RegistryObject<Block> BUTTERHEAD_LETTUCE_PLANT = REGISTRY.register("butterhead_lettuce_plant", () -> new ButterheadLettucePlantBlock());
    public static final RegistryObject<Block> PEA_POD_PLANT = REGISTRY.register("pea_pod_plant", () -> new PeaPodPlantBlock());
    public static final RegistryObject<Block> TALL_NUT_PLANT = REGISTRY.register("tall_nut_plant", () -> new TallNutPlantBlock());
    public static final RegistryObject<Block> HOLLY_PLANT = REGISTRY.register("holly_plant", () -> new HollyPlantBlock());
    public static final RegistryObject<Block> SAP = REGISTRY.register("sap", () -> new SapBlock());
    public static final RegistryObject<Block> SAPFLING_PLANT = REGISTRY.register("sapfling_plant", () -> new SapflingPlantBlock());
}

