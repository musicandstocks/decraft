/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.levelgen.feature.Feature
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package net.mcreator.plantsvszombiesreimagined.init;

import net.mcreator.plantsvszombiesreimagined.world.features.AnubisScalesFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.BasicPirateShipFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.BeachHutFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.BossShipFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.DolphinSpawnFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.GargantuarPyramidFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.GoldStarterPyramidFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.IronStarterPyramidFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.NeptunaBowlFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.PrisonShipFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.RaTempleFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.SeaShroomSpawnFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.SnorkelSpawnFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.SphinxFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.TangleKelpSpawnFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.BabyPoisonMineFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.BabyPotatoMineFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.BannanaFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.BloomerangPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.BonkPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.BowlingBulbPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.ButterheadLettucePlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.CandyCornFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.ChiliBeanPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.CoconutCannonPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.GhostPepperPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.HollyPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.IcebergPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.JackPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.KernelPultPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.LightningReedPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.MarigoldFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.MelonPultPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.NavyBeanPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.ParsnipPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.PeaPodPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.PlanternFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.PoisonPotatoMineFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.PotatoMineFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.PuffshroomPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.PumpPultPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.PumpkinPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.RepeaterPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.SapflingPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.SeaFloraPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.SnapPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.SpikeWeedFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.SpringBeanPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.SunflowerFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.SunshroomFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.SweetPeaPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.SweetPotatoPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.TallNutPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.TurkeyPlantFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.TwinSunflowerFeature;
import net.mcreator.plantsvszombiesreimagined.world.features.plants.WasabiWhipPlantFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber
public class PlantsvszombiesreimaginedModFeatures {
    public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create((IForgeRegistry)ForgeRegistries.FEATURES, (String)"plantsvszombiesreimagined");
    public static final RegistryObject<Feature<?>> SUNFLOWER = REGISTRY.register("sunflower", SunflowerFeature::new);
    public static final RegistryObject<Feature<?>> SUNSHROOM = REGISTRY.register("sunshroom", SunshroomFeature::new);
    public static final RegistryObject<Feature<?>> POTATO_MINE = REGISTRY.register("potato_mine", PotatoMineFeature::new);
    public static final RegistryObject<Feature<?>> BABY_POTATO_MINE = REGISTRY.register("baby_potato_mine", BabyPotatoMineFeature::new);
    public static final RegistryObject<Feature<?>> PUFFSHROOM_PLANT = REGISTRY.register("puffshroom_plant", PuffshroomPlantFeature::new);
    public static final RegistryObject<Feature<?>> MARIGOLD = REGISTRY.register("marigold", MarigoldFeature::new);
    public static final RegistryObject<Feature<?>> PLANTERN = REGISTRY.register("plantern", PlanternFeature::new);
    public static final RegistryObject<Feature<?>> REPEATER_PLANT = REGISTRY.register("repeater_plant", RepeaterPlantFeature::new);
    public static final RegistryObject<Feature<?>> BLOOMERANG_PLANT = REGISTRY.register("bloomerang_plant", BloomerangPlantFeature::new);
    public static final RegistryObject<Feature<?>> ICEBERG_PLANT = REGISTRY.register("iceberg_plant", IcebergPlantFeature::new);
    public static final RegistryObject<Feature<?>> BONK_PLANT = REGISTRY.register("bonk_plant", BonkPlantFeature::new);
    public static final RegistryObject<Feature<?>> TWIN_SUNFLOWER = REGISTRY.register("twin_sunflower", TwinSunflowerFeature::new);
    public static final RegistryObject<Feature<?>> IRON_STARTER_PYRAMID = REGISTRY.register("iron_starter_pyramid", IronStarterPyramidFeature::new);
    public static final RegistryObject<Feature<?>> GOLD_STARTER_PYRAMID = REGISTRY.register("gold_starter_pyramid", GoldStarterPyramidFeature::new);
    public static final RegistryObject<Feature<?>> ANUBIS_SCALES = REGISTRY.register("anubis_scales", AnubisScalesFeature::new);
    public static final RegistryObject<Feature<?>> SPHINX = REGISTRY.register("sphinx", SphinxFeature::new);
    public static final RegistryObject<Feature<?>> RA_TEMPLE = REGISTRY.register("ra_temple", RaTempleFeature::new);
    public static final RegistryObject<Feature<?>> GARGANTUAR_PYRAMID = REGISTRY.register("gargantuar_pyramid", GargantuarPyramidFeature::new);
    public static final RegistryObject<Feature<?>> BABY_POISON_MINE = REGISTRY.register("baby_poison_mine", BabyPoisonMineFeature::new);
    public static final RegistryObject<Feature<?>> POISON_POTATO_MINE = REGISTRY.register("poison_potato_mine", PoisonPotatoMineFeature::new);
    public static final RegistryObject<Feature<?>> BASIC_PIRATE_SHIP = REGISTRY.register("basic_pirate_ship", BasicPirateShipFeature::new);
    public static final RegistryObject<Feature<?>> KERNEL_PULT_PLANT = REGISTRY.register("kernel_pult_plant", KernelPultPlantFeature::new);
    public static final RegistryObject<Feature<?>> SNAP_PLANT = REGISTRY.register("snap_plant", SnapPlantFeature::new);
    public static final RegistryObject<Feature<?>> SPIKE_WEED = REGISTRY.register("spike_weed", SpikeWeedFeature::new);
    public static final RegistryObject<Feature<?>> COCONUT_CANNON_PLANT = REGISTRY.register("coconut_cannon_plant", CoconutCannonPlantFeature::new);
    public static final RegistryObject<Feature<?>> SPRING_BEAN_PLANT = REGISTRY.register("spring_bean_plant", SpringBeanPlantFeature::new);
    public static final RegistryObject<Feature<?>> SEA_SHROOM_SPAWN = REGISTRY.register("sea_shroom_spawn", SeaShroomSpawnFeature::new);
    public static final RegistryObject<Feature<?>> PRISON_SHIP = REGISTRY.register("prison_ship", PrisonShipFeature::new);
    public static final RegistryObject<Feature<?>> TANGLE_KELP_SPAWN = REGISTRY.register("tangle_kelp_spawn", TangleKelpSpawnFeature::new);
    public static final RegistryObject<Feature<?>> BOWLING_BULB_PLANT = REGISTRY.register("bowling_bulb_plant", BowlingBulbPlantFeature::new);
    public static final RegistryObject<Feature<?>> BANNANA = REGISTRY.register("bannana", BannanaFeature::new);
    public static final RegistryObject<Feature<?>> WASABI_WHIP_PLANT = REGISTRY.register("wasabi_whip_plant", WasabiWhipPlantFeature::new);
    public static final RegistryObject<Feature<?>> NAVY_BEAN_PLANT = REGISTRY.register("navy_bean_plant", NavyBeanPlantFeature::new);
    public static final RegistryObject<Feature<?>> SEA_FLORA_PLANT = REGISTRY.register("sea_flora_plant", SeaFloraPlantFeature::new);
    public static final RegistryObject<Feature<?>> BEACH_HUT = REGISTRY.register("beach_hut", BeachHutFeature::new);
    public static final RegistryObject<Feature<?>> BOSS_SHIP = REGISTRY.register("boss_ship", BossShipFeature::new);
    public static final RegistryObject<Feature<?>> NEPTUNA_BOWL = REGISTRY.register("neptuna_bowl", NeptunaBowlFeature::new);
    public static final RegistryObject<Feature<?>> CHILI_BEAN_PLANT = REGISTRY.register("chili_bean_plant", ChiliBeanPlantFeature::new);
    public static final RegistryObject<Feature<?>> DOLPHIN_SPAWN = REGISTRY.register("dolphin_spawn", DolphinSpawnFeature::new);
    public static final RegistryObject<Feature<?>> SNORKEL_SPAWN = REGISTRY.register("snorkel_spawn", SnorkelSpawnFeature::new);
    public static final RegistryObject<Feature<?>> PUMPKIN_PLANT = REGISTRY.register("pumpkin_plant", PumpkinPlantFeature::new);
    public static final RegistryObject<Feature<?>> GHOST_PEPPER_PLANT = REGISTRY.register("ghost_pepper_plant", GhostPepperPlantFeature::new);
    public static final RegistryObject<Feature<?>> SWEET_PEA_PLANT = REGISTRY.register("sweet_pea_plant", SweetPeaPlantFeature::new);
    public static final RegistryObject<Feature<?>> CANDY_CORN = REGISTRY.register("candy_corn", CandyCornFeature::new);
    public static final RegistryObject<Feature<?>> JACK_PLANT = REGISTRY.register("jack_plant", JackPlantFeature::new);
    public static final RegistryObject<Feature<?>> LIGHTNING_REED_PLANT = REGISTRY.register("lightning_reed_plant", LightningReedPlantFeature::new);
    public static final RegistryObject<Feature<?>> MELON_PULT_PLANT = REGISTRY.register("melon_pult_plant", MelonPultPlantFeature::new);
    public static final RegistryObject<Feature<?>> PUMP_PULT_PLANT = REGISTRY.register("pump_pult_plant", PumpPultPlantFeature::new);
    public static final RegistryObject<Feature<?>> TURKEY_PLANT = REGISTRY.register("turkey_plant", TurkeyPlantFeature::new);
    public static final RegistryObject<Feature<?>> SWEET_POTATO_PLANT = REGISTRY.register("sweet_potato_plant", SweetPotatoPlantFeature::new);
    public static final RegistryObject<Feature<?>> PARSNIP_PLANT = REGISTRY.register("parsnip_plant", ParsnipPlantFeature::new);
    public static final RegistryObject<Feature<?>> BUTTERHEAD_LETTUCE_PLANT = REGISTRY.register("butterhead_lettuce_plant", ButterheadLettucePlantFeature::new);
    public static final RegistryObject<Feature<?>> PEA_POD_PLANT = REGISTRY.register("pea_pod_plant", PeaPodPlantFeature::new);
    public static final RegistryObject<Feature<?>> TALL_NUT_PLANT = REGISTRY.register("tall_nut_plant", TallNutPlantFeature::new);
    public static final RegistryObject<Feature<?>> HOLLY_PLANT = REGISTRY.register("holly_plant", HollyPlantFeature::new);
    public static final RegistryObject<Feature<?>> SAPFLING_PLANT = REGISTRY.register("sapfling_plant", SapflingPlantFeature::new);
}

