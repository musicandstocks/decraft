/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.client.event.EntityRenderersEvent$RegisterLayerDefinitions
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 */
package net.mcreator.plantsvszombiesreimagined.init;

import net.mcreator.plantsvszombiesreimagined.client.model.Modelcannon;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelcatprojectile;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelconehead2;
import net.mcreator.plantsvszombiesreimagined.client.model.Modeldeepseagarg;
import net.mcreator.plantsvszombiesreimagined.client.model.Modeldolphinzombie;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelgargantarwimp;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelgargantarwimp_egypt;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelimp_fixed;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelmermaid_imp;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelmummy;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelmummybuckethead;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelneptuna;
import net.mcreator.plantsvszombiesreimagined.client.model.Modeloctopi;
import net.mcreator.plantsvszombiesreimagined.client.model.Modeloctozombie;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelparrot;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelplant7;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelsarcaphagus;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelseagullzombie;
import net.mcreator.plantsvszombiesreimagined.client.model.Modeltallnut;
import net.mcreator.plantsvszombiesreimagined.client.model.Modelturkey;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(bus=Mod.EventBusSubscriber.Bus.MOD, value={Dist.CLIENT})
public class PlantsvszombiesreimaginedModModels {
    @SubscribeEvent
    public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(Modelmermaid_imp.LAYER_LOCATION, Modelmermaid_imp::createBodyLayer);
        event.registerLayerDefinition(Modelneptuna.LAYER_LOCATION, Modelneptuna::createBodyLayer);
        event.registerLayerDefinition(Modelseagullzombie.LAYER_LOCATION, Modelseagullzombie::createBodyLayer);
        event.registerLayerDefinition(Modeldeepseagarg.LAYER_LOCATION, Modeldeepseagarg::createBodyLayer);
        event.registerLayerDefinition(Modeloctozombie.LAYER_LOCATION, Modeloctozombie::createBodyLayer);
        event.registerLayerDefinition(Modelturkey.LAYER_LOCATION, Modelturkey::createBodyLayer);
        event.registerLayerDefinition(Modelimp_fixed.LAYER_LOCATION, Modelimp_fixed::createBodyLayer);
        event.registerLayerDefinition(Modelmummy.LAYER_LOCATION, Modelmummy::createBodyLayer);
        event.registerLayerDefinition(Modeltallnut.LAYER_LOCATION, Modeltallnut::createBodyLayer);
        event.registerLayerDefinition(Modeloctopi.LAYER_LOCATION, Modeloctopi::createBodyLayer);
        event.registerLayerDefinition(Modelmummybuckethead.LAYER_LOCATION, Modelmummybuckethead::createBodyLayer);
        event.registerLayerDefinition(Modelcannon.LAYER_LOCATION, Modelcannon::createBodyLayer);
        event.registerLayerDefinition(Modelgargantarwimp.LAYER_LOCATION, Modelgargantarwimp::createBodyLayer);
        event.registerLayerDefinition(Modelsarcaphagus.LAYER_LOCATION, Modelsarcaphagus::createBodyLayer);
        event.registerLayerDefinition(Modelplant7.LAYER_LOCATION, Modelplant7::createBodyLayer);
        event.registerLayerDefinition(Modelparrot.LAYER_LOCATION, Modelparrot::createBodyLayer);
        event.registerLayerDefinition(Modelconehead2.LAYER_LOCATION, Modelconehead2::createBodyLayer);
        event.registerLayerDefinition(Modelgargantarwimp_egypt.LAYER_LOCATION, Modelgargantarwimp_egypt::createBodyLayer);
        event.registerLayerDefinition(Modeldolphinzombie.LAYER_LOCATION, Modeldolphinzombie::createBodyLayer);
        event.registerLayerDefinition(Modelcatprojectile.LAYER_LOCATION, Modelcatprojectile::createBodyLayer);
    }
}

