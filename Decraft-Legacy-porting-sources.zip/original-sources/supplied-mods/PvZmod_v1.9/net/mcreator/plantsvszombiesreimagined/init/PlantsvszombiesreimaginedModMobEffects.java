/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package net.mcreator.plantsvszombiesreimagined.init;

import net.mcreator.plantsvszombiesreimagined.potion.ButteredMobEffect;
import net.mcreator.plantsvszombiesreimagined.potion.ChillMobEffect;
import net.mcreator.plantsvszombiesreimagined.potion.ExtinguishMobEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;

public class PlantsvszombiesreimaginedModMobEffects {
    public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create((IForgeRegistry)ForgeRegistries.MOB_EFFECTS, (String)"plantsvszombiesreimagined");
    public static final RegistryObject<MobEffect> CHILL = REGISTRY.register("chill", () -> new ChillMobEffect());
    public static final RegistryObject<MobEffect> EXTINGUISH = REGISTRY.register("extinguish", () -> new ExtinguishMobEffect());
    public static final RegistryObject<MobEffect> BUTTERED = REGISTRY.register("buttered", () -> new ButteredMobEffect());
}

