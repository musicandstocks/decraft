/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraftforge.common.BasicItemListing
 *  net.minecraftforge.event.village.VillagerTradesEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 */
package net.mcreator.plantsvszombiesreimagined.init;

import java.util.List;
import net.mcreator.plantsvszombiesreimagined.init.PlantsvszombiesreimaginedModBlocks;
import net.mcreator.plantsvszombiesreimagined.init.PlantsvszombiesreimaginedModItems;
import net.mcreator.plantsvszombiesreimagined.init.PlantsvszombiesreimaginedModVillagerProfessions;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.common.BasicItemListing;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(bus=Mod.EventBusSubscriber.Bus.FORGE)
public class PlantsvszombiesreimaginedModTrades {
    @SubscribeEvent
    public static void registerTrades(VillagerTradesEvent event) {
        if (event.getType() == PlantsvszombiesreimaginedModVillagerProfessions.CRAZY_DAVE.get()) {
            ((List)event.getTrades().get(1)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModBlocks.SUNFLOWER.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get()), 100, 5, 0.0f));
            ((List)event.getTrades().get(1)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 4), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PEASHOOTER.get()), 16, 10, 0.05f));
            ((List)event.getTrades().get(2)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 2), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.WALLNUT_HELMET.get()), 8, 15, 0.05f));
            ((List)event.getTrades().get(2)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 7), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SNOW_PEA.get()), 5, 15, 0.05f));
            ((List)event.getTrades().get(3)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 8), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.REPEATER.get()), 5, 15, 0.05f));
            ((List)event.getTrades().get(4)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 6), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.CHOMPER.get()), 4, 20, 0.05f));
            ((List)event.getTrades().get(4)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 12), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.THREEPEATER.get()), 5, 33, 0.05f));
            ((List)event.getTrades().get(5)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 8), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.ELECTRIC_PEA.get()), 10, 26, 0.05f));
            ((List)event.getTrades().get(5)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 3), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.CHERRY_BOMB.get()), 3, 65, 0.05f));
            ((List)event.getTrades().get(3)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.POTATO_MINE_BOMB.get()), 10, 5, 0.05f));
            ((List)event.getTrades().get(4)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModBlocks.POTATO_MINE.get()), 10, 10, 0.05f));
            ((List)event.getTrades().get(5)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 8), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.REPEATER.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.GATLING_PEA.get()), 2, 55, 0.05f));
            ((List)event.getTrades().get(3)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 7), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PRIMAL_PEA.get()), 4, 15, 0.05f));
            ((List)event.getTrades().get(4)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 7), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.FIRE_PEA.get()), 5, 25, 0.05f));
            ((List)event.getTrades().get(4)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PEASHOOTER.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.CHOMPER.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SNAP_PEA.get()), 5, 55, 0.05f));
            ((List)event.getTrades().get(4)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 2), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.MAGNIFYING_GRASS.get()), 10, 8, 0.05f));
            ((List)event.getTrades().get(2)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModBlocks.TWIN_SUNFLOWER.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 2), 10, 10, 0.05f));
            ((List)event.getTrades().get(4)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 7), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.TORCH_WOOD.get()), 6, 5, 0.05f));
            ((List)event.getTrades().get(5)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 8), new ItemStack((ItemLike)Items.f_42415_), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.POWER_LILY.get()), 1, 80, 0.05f));
        }
        if (event.getType() == PlantsvszombiesreimaginedModVillagerProfessions.NOCTORNOL_DAVE.get()) {
            ((List)event.getTrades().get(1)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModBlocks.SUNSHROOM.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get()), 100, 5, 0.05f));
            ((List)event.getTrades().get(2)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PUFFSHROOM.get()), new ItemStack((ItemLike)Items.f_42399_), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PUFFMUSHROOM_STEW.get()), 10, 25, 0.05f));
            ((List)event.getTrades().get(2)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SCAREDYSHROOM.get()), 16, 10, 0.05f));
            ((List)event.getTrades().get(2)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 6), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.FUMESHROOM.get()), 10, 18, 0.05f));
            ((List)event.getTrades().get(3)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 3), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.HYPNOSHROOM.get()), 10, 30, 0.05f));
            ((List)event.getTrades().get(5)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 5), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.DOOMSHROOM.get()), 3, 55, 0.05f));
            ((List)event.getTrades().get(4)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 6), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.CHOMPER.get()), 4, 35, 0.05f));
            ((List)event.getTrades().get(5)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 3), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.ALOE.get()), 4, 35, 0.05f));
            ((List)event.getTrades().get(1)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModBlocks.PLANTERN.get()), 10, 5, 0.05f));
            ((List)event.getTrades().get(3)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 4), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.BLOVER.get()), 10, 10, 0.05f));
            ((List)event.getTrades().get(4)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 3), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.WALLNUT_HELMET.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.INFINUT_HELMET.get()), 2, 35, 0.05f));
            ((List)event.getTrades().get(3)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 5), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.STARFRUIT.get()), 4, 28, 0.05f));
            ((List)event.getTrades().get(5)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 8), new ItemStack((ItemLike)Items.f_42415_), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.POWER_LILY.get()), 1, 65, 0.05f));
            ((List)event.getTrades().get(4)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get(), 5), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PUMPKIN_CHESTPLATE.get()), 1, 10, 0.05f));
        }
        if (event.getType() == PlantsvszombiesreimaginedModVillagerProfessions.TACO_TRADER.get()) {
            ((List)event.getTrades().get(1)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.JALAPENO.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.GUACADILE.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.TACO.get()), 2, 50, 0.05f));
            ((List)event.getTrades().get(1)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PUFFSHROOM.get()), new ItemStack((ItemLike)Items.f_42399_), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PUFFMUSHROOM_STEW.get()), 20, 15, 0.05f));
            ((List)event.getTrades().get(2)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.TACO.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.CHILLY_PEPPER.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.CHILLY_TACO.get()), 2, 25, 0.05f));
            ((List)event.getTrades().get(2)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.TACO.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SNAP_DRAGON.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.ENDER_SNAP_DRAGON.get()), 2, 25, 0.05f));
            ((List)event.getTrades().get(2)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.TACO.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SPRING_BEAN.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SPRINGTRAP_BEAN.get()), 2, 25, 0.05f));
            ((List)event.getTrades().get(3)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.TACO.get()), new ItemStack((ItemLike)Blocks.f_50567_), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PICKLE_WICK.get()), 2, 25, 0.05f));
            ((List)event.getTrades().get(2)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.JALAPENO.get()), new ItemStack((ItemLike)Blocks.f_50567_, 2), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PICKLED_PEPPER.get()), 3, 15, 0.05f));
            ((List)event.getTrades().get(3)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.TACO.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.POWER_LILY.get(), 2), 1, 5, 0.05f));
            ((List)event.getTrades().get(2)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.TACO.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PUMPKIN_CHESTPLATE.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.MELON_ARMOR_CHESTPLATE.get()), 2, 5, 0.05f));
            ((List)event.getTrades().get(4)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.TACO.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.SWEET_PEA.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.DEADPLANTZ.get()), 1, 25, 0.05f));
            ((List)event.getTrades().get(3)).add(new BasicItemListing(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.TACO.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.GHOST_PEPPER.get()), new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PEPPER_X.get()), 4, 5, 0.05f));
        }
    }
}

