/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package net.mcreator.plantsvszombiesreimagined.init;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;

public class PlantsvszombiesreimaginedModSounds {
    public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create((IForgeRegistry)ForgeRegistries.SOUND_EVENTS, (String)"plantsvszombiesreimagined");
    public static final RegistryObject<SoundEvent> BLOOMERANG_SFX = REGISTRY.register("bloomerang_sfx", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "bloomerang_sfx")));
    public static final RegistryObject<SoundEvent> PEASHOOTER_SFX = REGISTRY.register("peashooter_sfx", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "peashooter_sfx")));
    public static final RegistryObject<SoundEvent> PVZTHEME = REGISTRY.register("pvztheme", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "pvztheme")));
    public static final RegistryObject<SoundEvent> PEASHOOTER_HIT = REGISTRY.register("peashooter_hit", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "peashooter_hit")));
    public static final RegistryObject<SoundEvent> PEASHOOTER_SFX2 = REGISTRY.register("peashooter_sfx2", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "peashooter_sfx2")));
    public static final RegistryObject<SoundEvent> PEASHOOTER_SFX3 = REGISTRY.register("peashooter_sfx3", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "peashooter_sfx3")));
    public static final RegistryObject<SoundEvent> PEASHOOTER_SFX4 = REGISTRY.register("peashooter_sfx4", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "peashooter_sfx4")));
    public static final RegistryObject<SoundEvent> BLOOMERANG_SFX2 = REGISTRY.register("bloomerang_sfx2", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "bloomerang_sfx2")));
    public static final RegistryObject<SoundEvent> CHOMPERBITE = REGISTRY.register("chomperbite", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "chomperbite")));
    public static final RegistryObject<SoundEvent> BLOVER = REGISTRY.register("blover", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "blover")));
    public static final RegistryObject<SoundEvent> CHERRYBOMB = REGISTRY.register("cherrybomb", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "cherrybomb")));
    public static final RegistryObject<SoundEvent> EXPLOSION = REGISTRY.register("explosion", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "explosion")));
    public static final RegistryObject<SoundEvent> FUMESHROOM = REGISTRY.register("fumeshroom", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "fumeshroom")));
    public static final RegistryObject<SoundEvent> PORTAL = REGISTRY.register("portal", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "portal")));
    public static final RegistryObject<SoundEvent> JALAPENO = REGISTRY.register("jalapeno", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "jalapeno")));
    public static final RegistryObject<SoundEvent> HYPNOSHROOM = REGISTRY.register("hypnoshroom", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "hypnoshroom")));
    public static final RegistryObject<SoundEvent> GARGANTUARDIES = REGISTRY.register("gargantuardies", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "gargantuardies")));
    public static final RegistryObject<SoundEvent> ZOMBIEGROAN = REGISTRY.register("zombiegroan", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "zombiegroan")));
    public static final RegistryObject<SoundEvent> IMPSFX = REGISTRY.register("impsfx", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "impsfx")));
    public static final RegistryObject<SoundEvent> GARGANTUARSTOMP = REGISTRY.register("gargantuarstomp", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "gargantuarstomp")));
    public static final RegistryObject<SoundEvent> SNOWPEA = REGISTRY.register("snowpea", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "snowpea")));
    public static final RegistryObject<SoundEvent> PLANTERN = REGISTRY.register("plantern", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "plantern")));
    public static final RegistryObject<SoundEvent> PLANT = REGISTRY.register("plant", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "plant")));
    public static final RegistryObject<SoundEvent> DOOMSHROOM = REGISTRY.register("doomshroom", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "doomshroom")));
    public static final RegistryObject<SoundEvent> PUFF = REGISTRY.register("puff", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "puff")));
    public static final RegistryObject<SoundEvent> CRAZYDAVE = REGISTRY.register("crazydave", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "crazydave")));
    public static final RegistryObject<SoundEvent> EGYPTAMBIENT = REGISTRY.register("egyptambient", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "egyptambient")));
    public static final RegistryObject<SoundEvent> EGYPTMUSIC = REGISTRY.register("egyptmusic", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "egyptmusic")));
    public static final RegistryObject<SoundEvent> BLOOMERALT = REGISTRY.register("bloomeralt", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "bloomeralt")));
    public static final RegistryObject<SoundEvent> IMP2 = REGISTRY.register("imp2", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "imp2")));
    public static final RegistryObject<SoundEvent> IMPYUCK = REGISTRY.register("impyuck", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "impyuck")));
    public static final RegistryObject<SoundEvent> CHEETO = REGISTRY.register("cheeto", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "cheeto")));
    public static final RegistryObject<SoundEvent> GUN = REGISTRY.register("gun", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "gun")));
    public static final RegistryObject<SoundEvent> PULTTHROW = REGISTRY.register("pultthrow", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "pultthrow")));
    public static final RegistryObject<SoundEvent> PULTHIT = REGISTRY.register("pulthit", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "pulthit")));
    public static final RegistryObject<SoundEvent> BWB = REGISTRY.register("bwb", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "bwb")));
    public static final RegistryObject<SoundEvent> PIRATESEAS = REGISTRY.register("pirateseas", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "pirateseas")));
    public static final RegistryObject<SoundEvent> PVZHALLOWEEN = REGISTRY.register("pvzhalloween", () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("plantsvszombiesreimagined", "pvzhalloween")));
}

