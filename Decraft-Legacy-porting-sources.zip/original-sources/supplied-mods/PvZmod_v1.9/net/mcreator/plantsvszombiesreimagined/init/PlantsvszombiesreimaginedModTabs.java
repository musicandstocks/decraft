/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.network.chat.Component
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.item.CreativeModeTab
 *  net.minecraft.world.item.CreativeModeTabs
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraftforge.event.BuildCreativeModeTabContentsEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.RegistryObject
 */
package net.mcreator.plantsvszombiesreimagined.init;

import net.mcreator.plantsvszombiesreimagined.init.PlantsvszombiesreimaginedModBlocks;
import net.mcreator.plantsvszombiesreimagined.init.PlantsvszombiesreimaginedModItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(bus=Mod.EventBusSubscriber.Bus.MOD)
public class PlantsvszombiesreimaginedModTabs {
    public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create((ResourceKey)Registries.f_279569_, (String)"plantsvszombiesreimagined");
    public static final RegistryObject<CreativeModeTab> PLANTS = REGISTRY.register("plants", () -> CreativeModeTab.builder().m_257941_((Component)Component.m_237115_((String)"item_group.plantsvszombiesreimagined.plants")).m_257737_(() -> new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.PEASHOOTER.get())).m_257501_((parameters, tabData) -> {
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PEASHOOTER.get());
        tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.SUNFLOWER.get()).m_5456_());
        tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.SUNSHROOM.get()).m_5456_());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.WALLNUT_HELMET.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CHERRY_BOMB.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.POTATO_MINE_BOMB.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CHOMPER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SNOW_PEA.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.REPEATER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.FIRE_PEA.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.ELECTRIC_PEA.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PRIMAL_PEA.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.GATLING_PEA.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.THREEPEATER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PUFFSHROOM.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SCAREDYSHROOM.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.FUMESHROOM.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.HYPNOSHROOM.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.DOOMSHROOM.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SNAP_PEA.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.MAGNIFYING_GRASS.get());
        tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.MARIGOLD.get()).m_5456_());
        tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.PLANTERN.get()).m_5456_());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.ALOE.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.INFINUT_HELMET.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BLOVER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BLOOMERANG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.ICEBERG_LETUCE.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BONK_CHOY.get());
        tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.TWIN_SUNFLOWER.get()).m_5456_());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CAT_TAIL.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CHAI_TAIL.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.JALAPENO.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.GUACADILE.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.POWER_LILY.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CHESTER_CHOMPER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.GLOOM_SHROOM.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.STARFRUIT.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BERRY_SHOOTER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SOUL_FIRE_PEA.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BAMBOO_SPARTAN.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.JUGGER_NUT_HELMET.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.TORCH_WOOD.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SOUL_FIRE_TORCH_WOOD.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CAULIPOWER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CHILLY_PEPPER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PICKLED_PEPPER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PICKLE_WICK.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.POISON_POTATO_MINE_BOMB.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.KERNEL_PULT.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SNAP_DRAGON.get());
        tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.SPIKE_WEED.get()).m_5456_());
        tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.SPIKE_ROCK.get()).m_5456_());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SPRING_BEAN.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.COCONUT_CANNON.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SEA_SHROOM.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.LILYPAD.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.TANGLE_KELP_ITEM.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BOWLING_BULB.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BANANA_LAUNCHER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.WASABI_WHIP.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SOUL_WASABI_WHIP.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.NAVY_BEAN.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.ADMIRAL_NAVY_BEAN.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.COOL_BEAN.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SPRINGTRAP_BEAN.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SEA_FLORA.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.COLD_SNAP_DRAGON.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.ENDER_SNAP_DRAGON.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.COB_CANNON.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CHILI_BEAN.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PUMPKIN_CHESTPLATE.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.GHOST_PEPPER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.MELON_ARMOR_CHESTPLATE.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SWEET_PEA.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.DEADPLANTZ.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CANDY_KERNEL_PULT.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.JACKO_LANTERN.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.WHITE_PUMPKIN_CHESTPLATE.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CAROLINA_REAPER.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PEPPER_X.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.LIGHTNING_REED.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.MELON_PULT.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.WINTER_MELON.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PUMPKIN_PULT.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.TURKEY_PULT.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SWEET_POTATO_HELMET.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PARSNIP.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BUTTERHEAD_LETTUCE.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PEAPOD.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PEAPOD_2.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PEAPOD_3.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PEAPOD_4.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PEAPOD_5.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.TALLNUT_HELMET.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.HOLLY_BARRIER_BOOTS.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SAPFLING.get());
    }).m_257652_());
    public static final RegistryObject<CreativeModeTab> ZOMBIES = REGISTRY.register("zombies", () -> CreativeModeTab.builder().m_257941_((Component)Component.m_237115_((String)"item_group.plantsvszombiesreimagined.zombies")).m_257737_(() -> new ItemStack((ItemLike)Blocks.f_50314_)).m_257501_((parameters, tabData) -> {
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BASIC_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.MUMMY_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BUCKET_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BUCKET_MUMMY_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.FLESH_BLOCK.get()).m_5456_());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.GARGANTUAR_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BRICKHEAD_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CONEHEAD_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CONEHEAD_MUMMY_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.RA_MUMMY_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SARCOPHAGUS_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CLEOPATRA_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.MUMMY_CAT_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.IMP_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.MUMMY_IMP_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.EGYPT_GARGANTUAR_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.EXPLORER_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.ANUBIS_MUMMY_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PLANT_FOOD_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PLANT_FOOD_MUMMY_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PIRATE_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CONEHEAD_PIRATE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BUCKET_PIRATE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PIRATE_CAPTAIN_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.ZOMBIE_PARROT_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PIRATE_IMP_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.IMP_CANNON_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SEAGULL_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BEACH_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CONEHEAD_BEACH_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BUCKET_BEACH_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SWIMSUIT_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CONEHEAD_SWIMSUIT_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BUCKET_SWIMSUIT_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.OCTO_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.MERMAID_IMP_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SEA_GARGANTUAR_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.NEPTUNA_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BARREL_HEAD_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SEA_BRICK_HEAD_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SNORKEL_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.DOLPHIN_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.DOLPHIN_ZOM_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.HALLOWEEN_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CONEHEAD_HALLOWEEN_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BUCKET_HALLOWEEN_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.FORTNITE_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BANANA_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.COWBOY_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CHICKEN_WRANGLER_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.ZOMBIE_CHICKEN_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.TURKEY_WRANGLER_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.ZOMBIE_TURKEY_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BASIC_THANKGIVING_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.XMAS_ZOMBIE_SPAWN_EGG.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.YETI_IMP_SPAWN_EGG.get());
    }).m_257652_());
    public static final RegistryObject<CreativeModeTab> PVZ_WORLDS = REGISTRY.register("pvz_worlds", () -> CreativeModeTab.builder().m_257941_((Component)Component.m_237115_((String)"item_group.plantsvszombiesreimagined.pvz_worlds")).m_257737_(() -> new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.ANCIENT_EGYPT.get())).m_257501_((parameters, tabData) -> {
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.ANCIENT_EGYPT.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.RA_STAFF.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.RA_HELMET_HELMET.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.ANUBIS_HELMET_HELMET.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PIRATE_BEACH.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SUSHI.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SPICY_SUSHI.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.OCTOPUS.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SNORKEL_HELMET.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.DOLPHIN_TOTEM.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.HOLIDAY.get());
        tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.WILD_WEST.get());
    }).m_257652_());

    @SubscribeEvent
    public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
        if (tabData.getTabKey() == CreativeModeTabs.f_256731_) {
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SEA_SHROOM_PLANT_SPAWN_EGG.get());
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.TANGLE_KELP_SPAWN_EGG.get());
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.OCTOPI_SPAWN_EGG.get());
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.TOFU_TURKEY_SPAWN_EGG.get());
        }
        if (tabData.getTabKey() == CreativeModeTabs.f_256968_) {
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SUN.get());
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PLANT_FOOD.get());
        }
        if (tabData.getTabKey() == CreativeModeTabs.f_256776_) {
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.POTATO_MINE.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.BABY_POTATO_MINE.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.PUFFSHROOM_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.REPEATER_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.BLOOMERANG_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.ICEBERG_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.BONK_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.BABY_POISON_MINE.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.POISON_POTATO_MINE.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.KERNEL_PULT_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.SNAP_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.COCONUT_CANNON_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.SPRING_BEAN_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.BOWLING_BULB_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.BANNANA.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.WASABI_WHIP_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.NAVY_BEAN_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.SEA_FLORA_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.CHILI_BEAN_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.PUMPKIN_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.GHOST_PEPPER_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.SWEET_PEA_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.CANDY_CORN.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.JACK_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.LIGHTNING_REED_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.MELON_PULT_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.PUMP_PULT_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.TURKEY_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.SWEET_POTATO_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.PARSNIP_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.BUTTERHEAD_LETTUCE_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.PEA_POD_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.TALL_NUT_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.HOLLY_PLANT.get()).m_5456_());
            tabData.m_246326_((ItemLike)((Block)PlantsvszombiesreimaginedModBlocks.SAPFLING_PLANT.get()).m_5456_());
        }
        if (tabData.getTabKey() == CreativeModeTabs.f_256839_) {
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PUFFMUSHROOM_STEW.get());
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.TACO.get());
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.CHILLY_TACO.get());
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.SPLIT_PEA_SOUP.get());
        }
        if (tabData.getTabKey() == CreativeModeTabs.f_256869_) {
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PVZ_THEME.get());
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.EGYPT_THEME.get());
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.BWB_DISC.get());
            tabData.m_246326_((ItemLike)PlantsvszombiesreimaginedModItems.PS_DISC.get());
        }
    }
}

