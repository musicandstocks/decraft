/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.world.effect.MobEffects
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.FlowerBlock
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.state.BlockBehaviour$OffsetType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.material.MapColor
 *  net.minecraft.world.level.material.PushReaction
 *  net.minecraft.world.level.storage.loot.LootParams$Builder
 */
package net.mcreator.plantsvszombiesreimagined.block;

import java.util.Collections;
import java.util.List;
import net.mcreator.plantsvszombiesreimagined.init.PlantsvszombiesreimaginedModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.storage.loot.LootParams;

public class HollyPlantBlock
extends FlowerBlock {
    public HollyPlantBlock() {
        super(() -> MobEffects.f_19596_, 100, BlockBehaviour.Properties.m_284310_().m_284180_(MapColor.f_283915_).m_60918_(SoundType.f_56740_).m_60913_(1.0f, 1.4f).m_60955_().m_60988_().m_222979_(BlockBehaviour.OffsetType.XZ).m_278166_(PushReaction.DESTROY));
    }

    public int m_53522_() {
        return 100;
    }

    public int getFlammability(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
        return 100;
    }

    public int getFireSpreadSpeed(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
        return 60;
    }

    public List<ItemStack> m_49635_(BlockState state, LootParams.Builder builder) {
        List dropsOriginal = super.m_49635_(state, builder);
        if (!dropsOriginal.isEmpty()) {
            return dropsOriginal;
        }
        return Collections.singletonList(new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.HOLLY_BARRIER_BOOTS.get()));
    }

    public boolean m_6266_(BlockState groundState, BlockGetter worldIn, BlockPos pos) {
        return groundState.m_60713_(Blocks.f_50440_) || groundState.m_60713_(Blocks.f_152481_) || groundState.m_60713_(Blocks.f_50195_) || groundState.m_60713_(Blocks.f_50493_) || groundState.m_60713_(Blocks.f_50546_) || groundState.m_60713_(Blocks.f_50599_) || groundState.m_60713_(Blocks.f_152549_) || groundState.m_60713_(Blocks.f_220864_) || groundState.m_60713_(Blocks.f_49992_) || groundState.m_60713_(Blocks.f_49993_) || groundState.m_60713_(Blocks.f_50069_) || groundState.m_60713_(Blocks.f_50705_) || groundState.m_60713_(Blocks.f_50741_) || groundState.m_60713_(Blocks.f_50742_) || groundState.m_60713_(Blocks.f_50743_) || groundState.m_60713_(Blocks.f_50744_) || groundState.m_60713_(Blocks.f_50745_) || groundState.m_60713_(Blocks.f_50655_) || groundState.m_60713_(Blocks.f_50656_) || groundState.m_60713_(Blocks.f_220865_) || groundState.m_60713_(Blocks.f_271304_) || groundState.m_60713_(Blocks.f_244477_) || groundState.m_60713_(Blocks.f_50062_) || groundState.m_60713_(Blocks.f_50129_);
    }

    public boolean m_7898_(BlockState blockstate, LevelReader worldIn, BlockPos pos) {
        BlockPos blockpos = pos.m_7495_();
        BlockState groundState = worldIn.m_8055_(blockpos);
        return this.m_6266_(groundState, (BlockGetter)worldIn, blockpos);
    }
}

