/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.protocol.Packet
 *  net.minecraft.network.protocol.game.ClientGamePacketListener
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.projectile.AbstractArrow
 *  net.minecraft.world.entity.projectile.ItemSupplier
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.network.NetworkHooks
 *  net.minecraftforge.network.PlayMessages$SpawnEntity
 */
package net.mcreator.plantsvszombiesreimagined.entity;

import net.mcreator.plantsvszombiesreimagined.init.PlantsvszombiesreimaginedModEntities;
import net.mcreator.plantsvszombiesreimagined.init.PlantsvszombiesreimaginedModItems;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.network.PlayMessages;

@OnlyIn(value=Dist.CLIENT, _interface=ItemSupplier.class)
public class BananaZombieEntityProjectile
extends AbstractArrow
implements ItemSupplier {
    public BananaZombieEntityProjectile(PlayMessages.SpawnEntity packet, Level world) {
        super((EntityType)PlantsvszombiesreimaginedModEntities.BANANA_ZOMBIE_PROJECTILE.get(), world);
    }

    public BananaZombieEntityProjectile(EntityType<? extends BananaZombieEntityProjectile> type, Level world) {
        super(type, world);
    }

    public BananaZombieEntityProjectile(EntityType<? extends BananaZombieEntityProjectile> type, double x, double y, double z, Level world) {
        super(type, x, y, z, world);
    }

    public BananaZombieEntityProjectile(EntityType<? extends BananaZombieEntityProjectile> type, LivingEntity entity, Level world) {
        super(type, entity, world);
    }

    public Packet<ClientGamePacketListener> m_5654_() {
        return NetworkHooks.getEntitySpawningPacket((Entity)this);
    }

    protected void m_7761_(LivingEntity livingEntity) {
        super.m_7761_(livingEntity);
        livingEntity.m_21317_(livingEntity.m_21234_() - 1);
    }

    @OnlyIn(value=Dist.CLIENT)
    public ItemStack m_7846_() {
        return new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.BANANA.get());
    }

    protected ItemStack m_7941_() {
        return new ItemStack((ItemLike)PlantsvszombiesreimaginedModItems.BANANA.get());
    }
}

