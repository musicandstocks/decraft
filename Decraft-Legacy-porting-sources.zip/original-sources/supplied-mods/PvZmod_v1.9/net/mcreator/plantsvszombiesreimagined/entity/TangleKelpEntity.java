/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.protocol.Packet
 *  net.minecraft.network.protocol.game.ClientGamePacketListener
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.damagesource.DamageTypes
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.EquipmentSlot
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.MobType
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.FloatGoal
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.MeleeAttackGoal
 *  net.minecraft.world.entity.ai.goal.RandomLookAroundGoal
 *  net.minecraft.world.entity.ai.goal.RandomStrollGoal
 *  net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal
 *  net.minecraft.world.entity.monster.Monster
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraftforge.network.NetworkHooks
 *  net.minecraftforge.network.PlayMessages$SpawnEntity
 *  net.minecraftforge.registries.ForgeRegistries
 */
package net.mcreator.plantsvszombiesreimagined.entity;

import net.mcreator.plantsvszombiesreimagined.entity.AnubisMummyEntity;
import net.mcreator.plantsvszombiesreimagined.entity.BasicZombieEntity;
import net.mcreator.plantsvszombiesreimagined.entity.BeachZombieEntity;
import net.mcreator.plantsvszombiesreimagined.entity.BrickheadZombieEntity;
import net.mcreator.plantsvszombiesreimagined.entity.BucketBeachEntity;
import net.mcreator.plantsvszombiesreimagined.entity.BucketMummyEntity;
import net.mcreator.plantsvszombiesreimagined.entity.BucketPirateEntity;
import net.mcreator.plantsvszombiesreimagined.entity.BucketSwimsuitEntity;
import net.mcreator.plantsvszombiesreimagined.entity.BucketZombieEntity;
import net.mcreator.plantsvszombiesreimagined.entity.CleopatraEntity;
import net.mcreator.plantsvszombiesreimagined.entity.ConeheadBeachEntity;
import net.mcreator.plantsvszombiesreimagined.entity.ConeheadMummyEntity;
import net.mcreator.plantsvszombiesreimagined.entity.ConeheadPirateEntity;
import net.mcreator.plantsvszombiesreimagined.entity.ConeheadSwimsuitEntity;
import net.mcreator.plantsvszombiesreimagined.entity.ConeheadZombieEntity;
import net.mcreator.plantsvszombiesreimagined.entity.DolphinZomEntity;
import net.mcreator.plantsvszombiesreimagined.entity.DolphinZombieEntity;
import net.mcreator.plantsvszombiesreimagined.entity.EgyptGargantuarEntity;
import net.mcreator.plantsvszombiesreimagined.entity.ExplorerEntity;
import net.mcreator.plantsvszombiesreimagined.entity.GargantuarEntity;
import net.mcreator.plantsvszombiesreimagined.entity.ImpCannonEntity;
import net.mcreator.plantsvszombiesreimagined.entity.ImpEntity;
import net.mcreator.plantsvszombiesreimagined.entity.MummyCatEntity;
import net.mcreator.plantsvszombiesreimagined.entity.MummyEntity;
import net.mcreator.plantsvszombiesreimagined.entity.MummyImpEntity;
import net.mcreator.plantsvszombiesreimagined.entity.NeptunaEntity;
import net.mcreator.plantsvszombiesreimagined.entity.OctoZombieEntity;
import net.mcreator.plantsvszombiesreimagined.entity.OctopiEntity;
import net.mcreator.plantsvszombiesreimagined.entity.PirateCaptainEntity;
import net.mcreator.plantsvszombiesreimagined.entity.PirateImpEntity;
import net.mcreator.plantsvszombiesreimagined.entity.PirateZombieEntity;
import net.mcreator.plantsvszombiesreimagined.entity.PlantFoodMummyEntity;
import net.mcreator.plantsvszombiesreimagined.entity.PlantFoodZombieEntity;
import net.mcreator.plantsvszombiesreimagined.entity.RaMummyEntity;
import net.mcreator.plantsvszombiesreimagined.entity.SarcophagusEntity;
import net.mcreator.plantsvszombiesreimagined.entity.SeaGargantuarEntity;
import net.mcreator.plantsvszombiesreimagined.entity.SeagullZombieEntity;
import net.mcreator.plantsvszombiesreimagined.entity.SnorkelZombieEntity;
import net.mcreator.plantsvszombiesreimagined.entity.SwimsuitZombieEntity;
import net.mcreator.plantsvszombiesreimagined.init.PlantsvszombiesreimaginedModEntities;
import net.mcreator.plantsvszombiesreimagined.procedures.TangleKelpEntityDiesProcedure;
import net.mcreator.plantsvszombiesreimagined.procedures.TangleKelpOnEntityTickUpdateProcedure;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.registries.ForgeRegistries;

public class TangleKelpEntity
extends PathfinderMob {
    public TangleKelpEntity(PlayMessages.SpawnEntity packet, Level world) {
        this((EntityType<TangleKelpEntity>)((EntityType)PlantsvszombiesreimaginedModEntities.TANGLE_KELP.get()), world);
    }

    public TangleKelpEntity(EntityType<TangleKelpEntity> type, Level world) {
        super(type, world);
        this.m_274367_(0.0f);
        this.f_21364_ = 0;
        this.m_21557_(false);
        this.m_8061_(EquipmentSlot.MAINHAND, new ItemStack((ItemLike)Blocks.f_50575_));
    }

    public Packet<ClientGamePacketListener> m_5654_() {
        return NetworkHooks.getEntitySpawningPacket((Entity)this);
    }

    protected void m_8099_() {
        super.m_8099_();
        this.f_21345_.m_25352_(1, (Goal)new RandomStrollGoal((PathfinderMob)this, 0.0));
        this.f_21345_.m_25352_(2, (Goal)new RandomLookAroundGoal((Mob)this));
        this.f_21345_.m_25352_(3, (Goal)new FloatGoal((Mob)this));
        this.f_21346_.m_25352_(4, (Goal)new NearestAttackableTargetGoal((Mob)this, Monster.class, false, false));
        this.f_21346_.m_25352_(5, (Goal)new NearestAttackableTargetGoal((Mob)this, AnubisMummyEntity.class, false, false));
        this.f_21346_.m_25352_(6, (Goal)new NearestAttackableTargetGoal((Mob)this, BucketPirateEntity.class, false, false));
        this.f_21346_.m_25352_(7, (Goal)new NearestAttackableTargetGoal((Mob)this, PirateZombieEntity.class, false, false));
        this.f_21346_.m_25352_(8, (Goal)new NearestAttackableTargetGoal((Mob)this, ConeheadPirateEntity.class, false, false));
        this.f_21346_.m_25352_(9, (Goal)new NearestAttackableTargetGoal((Mob)this, BasicZombieEntity.class, false, false));
        this.f_21346_.m_25352_(10, (Goal)new NearestAttackableTargetGoal((Mob)this, BrickheadZombieEntity.class, false, false));
        this.f_21346_.m_25352_(11, (Goal)new NearestAttackableTargetGoal((Mob)this, BucketMummyEntity.class, false, false));
        this.f_21346_.m_25352_(12, (Goal)new NearestAttackableTargetGoal((Mob)this, BucketZombieEntity.class, false, false));
        this.f_21346_.m_25352_(13, (Goal)new NearestAttackableTargetGoal((Mob)this, MummyCatEntity.class, false, false));
        this.f_21346_.m_25352_(14, (Goal)new NearestAttackableTargetGoal((Mob)this, ConeheadMummyEntity.class, false, false));
        this.f_21346_.m_25352_(15, (Goal)new NearestAttackableTargetGoal((Mob)this, ConeheadZombieEntity.class, false, false));
        this.f_21346_.m_25352_(16, (Goal)new NearestAttackableTargetGoal((Mob)this, CleopatraEntity.class, false, false));
        this.f_21346_.m_25352_(17, (Goal)new NearestAttackableTargetGoal((Mob)this, EgyptGargantuarEntity.class, false, false));
        this.f_21346_.m_25352_(18, (Goal)new NearestAttackableTargetGoal((Mob)this, ExplorerEntity.class, false, false));
        this.f_21346_.m_25352_(19, (Goal)new NearestAttackableTargetGoal((Mob)this, GargantuarEntity.class, false, false));
        this.f_21346_.m_25352_(20, (Goal)new NearestAttackableTargetGoal((Mob)this, ImpEntity.class, false, false));
        this.f_21346_.m_25352_(21, (Goal)new NearestAttackableTargetGoal((Mob)this, MummyEntity.class, false, false));
        this.f_21346_.m_25352_(22, (Goal)new NearestAttackableTargetGoal((Mob)this, MummyImpEntity.class, false, false));
        this.f_21346_.m_25352_(23, (Goal)new NearestAttackableTargetGoal((Mob)this, RaMummyEntity.class, false, false));
        this.f_21346_.m_25352_(24, (Goal)new NearestAttackableTargetGoal((Mob)this, SarcophagusEntity.class, false, false));
        this.f_21346_.m_25352_(25, (Goal)new NearestAttackableTargetGoal((Mob)this, PlantFoodMummyEntity.class, false, false));
        this.f_21346_.m_25352_(26, (Goal)new NearestAttackableTargetGoal((Mob)this, PlantFoodZombieEntity.class, false, false));
        this.f_21346_.m_25352_(27, (Goal)new NearestAttackableTargetGoal((Mob)this, SeagullZombieEntity.class, false, false));
        this.f_21346_.m_25352_(28, (Goal)new NearestAttackableTargetGoal((Mob)this, ImpCannonEntity.class, false, false));
        this.f_21346_.m_25352_(29, (Goal)new NearestAttackableTargetGoal((Mob)this, PirateImpEntity.class, false, false));
        this.f_21346_.m_25352_(30, (Goal)new NearestAttackableTargetGoal((Mob)this, PirateCaptainEntity.class, false, false));
        this.f_21346_.m_25352_(31, (Goal)new NearestAttackableTargetGoal((Mob)this, SwimsuitZombieEntity.class, false, false));
        this.f_21346_.m_25352_(32, (Goal)new NearestAttackableTargetGoal((Mob)this, BeachZombieEntity.class, false, false));
        this.f_21346_.m_25352_(33, (Goal)new NearestAttackableTargetGoal((Mob)this, BucketSwimsuitEntity.class, false, false));
        this.f_21346_.m_25352_(34, (Goal)new NearestAttackableTargetGoal((Mob)this, BucketBeachEntity.class, false, false));
        this.f_21346_.m_25352_(35, (Goal)new NearestAttackableTargetGoal((Mob)this, ConeheadBeachEntity.class, false, false));
        this.f_21346_.m_25352_(36, (Goal)new NearestAttackableTargetGoal((Mob)this, ConeheadSwimsuitEntity.class, false, false));
        this.f_21346_.m_25352_(37, (Goal)new NearestAttackableTargetGoal((Mob)this, OctoZombieEntity.class, false, false));
        this.f_21346_.m_25352_(38, (Goal)new NearestAttackableTargetGoal((Mob)this, OctopiEntity.class, false, false));
        this.f_21346_.m_25352_(39, (Goal)new NearestAttackableTargetGoal((Mob)this, NeptunaEntity.class, false, false));
        this.f_21346_.m_25352_(40, (Goal)new NearestAttackableTargetGoal((Mob)this, SeaGargantuarEntity.class, false, false));
        this.f_21346_.m_25352_(41, (Goal)new NearestAttackableTargetGoal((Mob)this, SnorkelZombieEntity.class, false, false));
        this.f_21346_.m_25352_(42, (Goal)new NearestAttackableTargetGoal((Mob)this, DolphinZombieEntity.class, false, false));
        this.f_21346_.m_25352_(43, (Goal)new NearestAttackableTargetGoal((Mob)this, DolphinZomEntity.class, false, false));
        this.f_21345_.m_25352_(44, (Goal)new MeleeAttackGoal(this, 1.2, false){

            protected double m_6639_(LivingEntity entity) {
                return this.f_25540_.m_20205_() * this.f_25540_.m_20205_() + entity.m_20205_();
            }
        });
    }

    public MobType m_6336_() {
        return MobType.f_21640_;
    }

    protected void m_7472_(DamageSource source, int looting, boolean recentlyHitIn) {
        super.m_7472_(source, looting, recentlyHitIn);
        this.m_19983_(new ItemStack((ItemLike)Blocks.f_50575_));
    }

    public SoundEvent m_7975_(DamageSource ds) {
        return (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.hurt"));
    }

    public SoundEvent m_5592_() {
        return (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.death"));
    }

    public boolean m_6469_(DamageSource source, float amount) {
        if (source.m_276093_(DamageTypes.f_268722_)) {
            return false;
        }
        return super.m_6469_(source, amount);
    }

    public void m_6667_(DamageSource source) {
        super.m_6667_(source);
        TangleKelpEntityDiesProcedure.execute((LevelAccessor)this.m_9236_(), this.m_20185_(), this.m_20186_(), this.m_20189_());
    }

    public void m_6075_() {
        super.m_6075_();
        TangleKelpOnEntityTickUpdateProcedure.execute((LevelAccessor)this.m_9236_(), (Entity)this);
    }

    public static void init() {
    }

    public static AttributeSupplier.Builder createAttributes() {
        AttributeSupplier.Builder builder = Mob.m_21552_();
        builder = builder.m_22268_(Attributes.f_22279_, 0.2);
        builder = builder.m_22268_(Attributes.f_22276_, 5.0);
        builder = builder.m_22268_(Attributes.f_22284_, 1.0);
        builder = builder.m_22268_(Attributes.f_22281_, 20.0);
        builder = builder.m_22268_(Attributes.f_22277_, 15.0);
        return builder;
    }
}

