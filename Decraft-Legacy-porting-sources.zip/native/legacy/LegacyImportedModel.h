#pragma once
#include "Model.h"
#include "model_mesh.hpp"

// Engine integration source: requires the actual Legacy client MSVC build.
class LegacyImportedModel : public Model {
    decraft::Mesh mesh;
public:
    std::vector<decraft::BonePose> pose;
    explicit LegacyImportedModel(const char *meshPath);
    virtual void render(shared_ptr<Entity> entity,float time,float r,float bob,float yRot,float xRot,float scale,bool usecompiled);
};
