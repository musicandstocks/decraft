#include "stdafx.h"
#include "IsaacModModel.h"
#include "ModelPart.h"
#include <cmath>
IsaacModModel::IsaacModModel() {
    texWidth=texHeight=32;
    head=new ModelPart(this,0,0);head->addBox(-4,-8,-4,8,8,8);head->setPos(0,13,0);
    body=new ModelPart(this,0,16);body->addBox(-3,0,-2,6,7,4);body->setPos(0,13,0);
    leftArm=new ModelPart(this,24,0);leftArm->addBox(0,-1,-1,2,6,2);leftArm->setPos(3,14,0);
    rightArm=new ModelPart(this,0,0);rightArm->addBox(-2,-1,-1,2,6,2);rightArm->setPos(-3,14,0);
    leftLeg=new ModelPart(this,24,22);leftLeg->addBox(-1,0,-1,2,4,2);leftLeg->setPos(2,20,0);
    rightLeg=new ModelPart(this,24,16);rightLeg->addBox(-1,0,-1,2,4,2);rightLeg->setPos(-2,20,0);
}
void IsaacModModel::setupAnim(float time,float amount,float,float yaw,float pitch,float,unsigned int) {
    leftLeg->xRot=std::cos(time)*-amount;rightLeg->xRot=std::cos(time)*amount;
    leftArm->xRot=std::cos(time*0.6662f)*amount;
    rightArm->xRot=std::cos(time*0.6662f+3.14159265358979323846f)*amount;
    head->yRot=yaw/57.295776f;head->xRot=pitch/57.295776f;
}
void IsaacModModel::render(shared_ptr<Entity>,float time,float amount,float bob,float yaw,float pitch,float scale,bool usecompiled) {
    setupAnim(time,amount,bob,yaw,pitch,scale);
    head->render(scale,usecompiled);body->render(scale,usecompiled);
    leftArm->render(scale,usecompiled);rightArm->render(scale,usecompiled);
    leftLeg->render(scale,usecompiled);rightLeg->render(scale,usecompiled);
}
