#pragma once
#include <cstdint>
#include <istream>
#include <string>
#include <vector>

namespace decraft {
struct Vec3 { float x,y,z; Vec3(float X=0,float Y=0,float Z=0):x(X),y(Y),z(Z) {} };
struct Vertex { Vec3 p; float u,v; };
struct Bone { int parent; Vec3 pivot,rotation; bool hidden; std::string name; };
struct Quad { unsigned bone; Vertex v[4]; };
struct Mesh { std::vector<Bone> bones; std::vector<Quad> quads; };
struct BonePose { Vec3 translation,rotation,scale; BonePose():scale(1,1,1) {} };
struct PosedQuad { Vertex v[4]; Vec3 normal; };
Mesh readMesh(std::istream &input);
std::vector<PosedQuad> poseMesh(const Mesh &mesh,const std::vector<BonePose> &pose);
}
