#pragma once
#include "Model.h"
class ModelPart;
// Geometry and animation port of the supplied Suzu ModelIsaac, not campaign logic.
class IsaacModModel : public Model {
    ModelPart *head,*body,*leftArm,*rightArm,*leftLeg,*rightLeg;
public:
    IsaacModModel();
    virtual void setupAnim(float time,float amount,float bob,float yaw,float pitch,float scale,unsigned int flags=0);
    virtual void render(shared_ptr<Entity> entity,float time,float amount,float bob,float yaw,float pitch,float scale,bool usecompiled);
};
