#include "stdafx.h"
#include "LegacyImportedModel.h"
#include "Tesselator.h"
#include <fstream>

LegacyImportedModel::LegacyImportedModel(const char *path) {
    std::ifstream file(path,std::ios::binary);mesh=decraft::readMesh(file);pose.resize(mesh.bones.size());
}
void LegacyImportedModel::render(shared_ptr<Entity>,float,float,float,float,float,float scale,bool) {
    const std::vector<decraft::PosedQuad> quads=decraft::poseMesh(mesh,pose);
    Tesselator *t=Tesselator::getInstance();
    for(size_t i=0;i<quads.size();++i) {
        const decraft::PosedQuad &q=quads[i];t->begin();t->normal(q.normal.x,q.normal.y,q.normal.z);
        for(int j=0;j<4;++j)t->vertexUV(q.v[j].p.x*scale,q.v[j].p.y*scale,q.v[j].p.z*scale,q.v[j].u,q.v[j].v);
        t->end();
    }
}
