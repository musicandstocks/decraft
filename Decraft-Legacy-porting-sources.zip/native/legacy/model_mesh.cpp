#include "model_mesh.hpp"
#include <cmath>
#include <cstring>
#include <stdexcept>
#include <float.h>

namespace decraft {
static uint32_t word(std::istream &s) {
    unsigned char b[4];if(!s.read(reinterpret_cast<char*>(b),4))throw std::runtime_error("Truncated native mesh");
    return uint32_t(b[0])|(uint32_t(b[1])<<8)|(uint32_t(b[2])<<16)|(uint32_t(b[3])<<24);
}
static float number(std::istream &s) {
    uint32_t b=word(s);float v;std::memcpy(&v,&b,4);
#if defined(_MSC_VER) && _MSC_VER < 1800
    if(!_finite(v))throw std::runtime_error("Nonfinite native mesh coordinate");
#else
    if(!std::isfinite(v))throw std::runtime_error("Nonfinite native mesh coordinate");
#endif
    return v;
}
static Vec3 vector(std::istream &s) {Vec3 v;v.x=number(s);v.y=number(s);v.z=number(s);return v;}
Mesh readMesh(std::istream &s) {
    if(word(s)!=0x48534d44 || word(s)!=1)throw std::runtime_error("Unsupported native mesh format");
    uint32_t nb=word(s),nq=word(s);
    if(nb>4096||nq>1000000)throw std::runtime_error("Native mesh exceeds allocation limits");
    Mesh m;m.bones.reserve(nb);m.quads.reserve(nq);
    for(uint32_t i=0;i<nb;++i) {
        Bone b;b.parent=static_cast<int32_t>(word(s));b.pivot=vector(s);b.rotation=vector(s);
        b.hidden=word(s)!=0;uint32_t n=word(s);
        if(n>1024||b.parent<-1||b.parent>=static_cast<int>(i))throw std::runtime_error("Invalid native bone hierarchy");
        b.name.resize(n);if(n&&!s.read(&b.name[0],n))throw std::runtime_error("Truncated bone name");m.bones.push_back(b);
    }
    for(uint32_t i=0;i<nq;++i) {
        Quad q;q.bone=word(s);if(q.bone>=nb)throw std::runtime_error("Invalid native mesh bone index");
        for(int j=0;j<4;++j){q.v[j].p=vector(s);q.v[j].u=number(s);q.v[j].v=number(s);}m.quads.push_back(q);
    }
    if(s.peek()!=std::char_traits<char>::eof())throw std::runtime_error("Trailing native mesh data");
    return m;
}
struct Matrix {float a[16];};
static Matrix identity(){Matrix m={{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1}};return m;}
static Matrix multiply(const Matrix &a,const Matrix &b) {
    Matrix r={{0}};for(int y=0;y<4;++y)for(int x=0;x<4;++x)for(int k=0;k<4;++k)r.a[y*4+x]+=a.a[y*4+k]*b.a[k*4+x];return r;
}
static Matrix translation(Vec3 v){Matrix m=identity();m.a[3]=v.x;m.a[7]=v.y;m.a[11]=v.z;return m;}
static Matrix rotation(Vec3 v) {
    Matrix x=identity(),y=identity(),z=identity();
    x.a[5]=x.a[10]=std::cos(v.x);x.a[6]=-std::sin(v.x);x.a[9]=std::sin(v.x);
    y.a[0]=y.a[10]=std::cos(v.y);y.a[2]=std::sin(v.y);y.a[8]=-std::sin(v.y);
    z.a[0]=z.a[5]=std::cos(v.z);z.a[1]=-std::sin(v.z);z.a[4]=std::sin(v.z);
    return multiply(multiply(z,y),x);
}
static Vec3 transform(const Matrix &m,Vec3 v) {
    return Vec3(m.a[0]*v.x+m.a[1]*v.y+m.a[2]*v.z+m.a[3],m.a[4]*v.x+m.a[5]*v.y+m.a[6]*v.z+m.a[7],m.a[8]*v.x+m.a[9]*v.y+m.a[10]*v.z+m.a[11]);
}
std::vector<PosedQuad> poseMesh(const Mesh &m,const std::vector<BonePose> &pose) {
    if(!pose.empty()&&pose.size()!=m.bones.size())throw std::runtime_error("Native pose has wrong bone count");
    std::vector<Matrix> matrices;std::vector<bool> visible;std::vector<PosedQuad> output;
    for(size_t i=0;i<m.bones.size();++i) {
        const Bone &b=m.bones[i];BonePose p=pose.empty()?BonePose():pose[i];
        Matrix scale=identity();scale.a[0]=p.scale.x;scale.a[5]=p.scale.y;scale.a[10]=p.scale.z;
        Vec3 r(b.rotation.x+p.rotation.x,b.rotation.y+p.rotation.y,b.rotation.z+p.rotation.z);
        Vec3 minus(-b.pivot.x,-b.pivot.y,-b.pivot.z);
        Matrix local=multiply(translation(p.translation),multiply(translation(b.pivot),multiply(rotation(r),multiply(scale,translation(minus)))));
        matrices.push_back(b.parent<0?local:multiply(matrices.at(b.parent),local));
        visible.push_back(!b.hidden&&(b.parent<0||visible.at(b.parent)));
    }
    for(const Quad &q:m.quads) {
        if(!visible.at(q.bone))continue;
        PosedQuad out;
        for(int j=0;j<4;++j){out.v[j]=q.v[j];out.v[j].p=transform(matrices.at(q.bone),q.v[j].p);}
        Vec3 a(out.v[1].p.x-out.v[0].p.x,out.v[1].p.y-out.v[0].p.y,out.v[1].p.z-out.v[0].p.z);
        Vec3 b(out.v[2].p.x-out.v[0].p.x,out.v[2].p.y-out.v[0].p.y,out.v[2].p.z-out.v[0].p.z);
        out.normal=Vec3(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x);
        float n=std::sqrt(out.normal.x*out.normal.x+out.normal.y*out.normal.y+out.normal.z*out.normal.z);
        if(n>0){out.normal.x/=n;out.normal.y/=n;out.normal.z/=n;}output.push_back(out);
    }
    return output;
}
}
