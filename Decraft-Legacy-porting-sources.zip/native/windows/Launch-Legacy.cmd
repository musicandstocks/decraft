@echo off
setlocal
title Decraft - Legacy Console client
"%~dp0Launch-Legacy.exe" %*
set "DECRAFT_LEGACY_EXIT=%ERRORLEVEL%"
echo.
if not "%DECRAFT_LEGACY_EXIT%"=="0" echo Launch failed. The error is above. Logs are in the selected client folder under legacy-logs.
echo Press any key to close this launcher window.
pause >nul
exit /b %DECRAFT_LEGACY_EXIT%
