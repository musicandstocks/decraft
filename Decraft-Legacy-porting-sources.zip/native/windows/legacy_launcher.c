/* Launch only the supplied native Legacy client; preserve worlds and input backups. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include "legacy_input_hashes.h"
static void fail(const WCHAR *message) {fwprintf(stderr,L"LEGACY LAUNCH ERROR: %ls (Windows error %lu)\n",message,GetLastError());}
static int join(WCHAR *out,const WCHAR *root,const WCHAR *name) {
    if(wcslen(root)+wcslen(name)+2>=MAX_PATH){SetLastError(ERROR_FILENAME_EXCED_RANGE);return 0;}
    wcscpy(out,root);wcscat(out,L"\\");wcscat(out,name);return 1;
}
static int exists(const WCHAR *p) {return GetFileAttributesW(p)!=INVALID_FILE_ATTRIBUTES;}
static int hash(const WCHAR *path,char out[65]) {
    HANDLE file=INVALID_HANDLE_VALUE;BCRYPT_ALG_HANDLE alg=NULL;BCRYPT_HASH_HANDLE h=NULL;
    BYTE buffer[65536],value[32];DWORD got;int ok=0,i;
    file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(file==INVALID_HANDLE_VALUE)goto done;
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,NULL,0)<0)goto done;
    if(BCryptCreateHash(alg,&h,NULL,0,NULL,0,0)<0)goto done;
    do {if(!ReadFile(file,buffer,sizeof(buffer),&got,NULL))goto done;
        if(got&&BCryptHashData(h,buffer,got,0)<0)goto done;}while(got);
    if(BCryptFinishHash(h,value,sizeof(value),0)<0)goto done;
    for(i=0;i<32;++i)sprintf(out+i*2,"%02x",value[i]);
    out[64]=0;ok=1;
done:
    if(h)BCryptDestroyHash(h);
    if(alg)BCryptCloseAlgorithmProvider(alg,0);
    if(file!=INVALID_HANDLE_VALUE)CloseHandle(file);
    return ok;
}
static int input(const WCHAR *launcherRoot,const WCHAR *gameRoot) {
    WCHAR source[MAX_PATH],dest[MAX_PATH],backup[MAX_PATH],temp[MAX_PATH];char sha[65];
    if(!join(source,launcherRoot,L"Legacy-input\\XInput9_1_0.dll")||!join(dest,gameRoot,L"x64\\Release\\XInput9_1_0.dll"))return 0;
    if(!hash(source,sha)||strcmp(sha,DECRAFT_INPUT_SHA)){SetLastError(ERROR_CRC);fail(L"Bundled input DLL failed SHA-256 verification");return 0;}
    if(exists(dest)) {
        if(!hash(dest,sha))return 0;
        if(!strcmp(sha,DECRAFT_INPUT_SHA))return 1;
        if(strcmp(sha,"1835a87222ef077ba43515f52e5bba8d3a026b3ed29a3aa2292f8f66e490048e")) {
            SetLastError(ERROR_ALREADY_EXISTS);fail(L"Unrecognized input DLL preserved. Move it to a backup before installing this adapter");return 0;
        }
        if(wcslen(dest)+32>=MAX_PATH)return 0;
        swprintf(backup,MAX_PATH,L"%ls.backup-%lu",dest,GetCurrentProcessId());
        if(!CopyFileW(dest,backup,TRUE)){fail(L"Cannot preserve previous input DLL");return 0;}
        wprintf(L"Previous input DLL backed up: %ls\n",backup);
    }
    if(wcslen(dest)+32>=MAX_PATH)return 0;
    swprintf(temp,MAX_PATH,L"%ls.new-%lu",dest,GetCurrentProcessId());
    if(!CopyFileW(source,temp,TRUE))return 0;
    if(!hash(temp,sha)||strcmp(sha,DECRAFT_INPUT_SHA)){DeleteFileW(temp);SetLastError(ERROR_CRC);return 0;}
    if(!MoveFileExW(temp,dest,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){DeleteFileW(temp);return 0;}
    return 1;
}
int wmain(int argc,WCHAR **argv) {
    WCHAR launcherRoot[MAX_PATH],gameRoot[MAX_PATH],exe[MAX_PATH],working[MAX_PATH],path[MAX_PATH],command[MAX_PATH+16],log[MAX_PATH];
    DWORD n=GetModuleFileNameW(NULL,launcherRoot,MAX_PATH),code;int i,check=0;BOOL keepInput=FALSE;WCHAR *explicitRoot=NULL;
    STARTUPINFOW startup={0};PROCESS_INFORMATION process={0};SECURITY_ATTRIBUTES security={sizeof(security),NULL,TRUE};HANDLE stream;
    if(!n||n>=MAX_PATH)return 1;
    WCHAR *slash=wcsrchr(launcherRoot,L'\\');if(!slash)return 1;*slash=0;
    for(i=1;i<argc;++i) {
        if(!wcscmp(argv[i],L"--check"))check=1;
        else if(!wcscmp(argv[i],L"--keep-input"))keepInput=TRUE;
        else if(!wcscmp(argv[i],L"--root")&&i+1<argc)explicitRoot=argv[++i];
        else {fwprintf(stderr,L"Usage: Launch-Legacy.exe [--root extracted-minecraff2-folder] [--check] [--keep-input]\n");return 2;}
    }
    if(explicitRoot) {if(!GetFullPathNameW(explicitRoot,MAX_PATH,gameRoot,NULL))return 1;}
    else {
        if(!join(gameRoot,launcherRoot,L"runtime\\legacy"))return 1;
        if(!join(exe,gameRoot,L"x64\\Release\\Minecraft.Client.exe"))return 1;
        if(!exists(exe))wcscpy(gameRoot,launcherRoot);
    }
    if(!join(exe,gameRoot,L"x64\\Release\\Minecraft.Client.exe")||!join(working,gameRoot,L"Minecraft.Client"))return 1;
    if(!exists(exe)||!exists(working)) {SetLastError(ERROR_FILE_NOT_FOUND);fail(L"Native Legacy client missing. Use --root to select the extracted minecraff2 archive");return 1;}
    if(!join(path,working,L"Common\\Media")||!exists(path)){SetLastError(ERROR_PATH_NOT_FOUND);fail(L"Missing Legacy UI assets");return 1;}
    if(!join(path,working,L"Common\\res")||!exists(path)){SetLastError(ERROR_PATH_NOT_FOUND);fail(L"Missing Legacy textures");return 1;}
    if(!keepInput&&!input(launcherRoot,gameRoot)){fail(L"Input installation failed; existing saves and executable are preserved");return 1;}
    wprintf(L"Legacy client: %ls\nWorking folder: %ls\n",exe,working);
    wprintf(L"Xbox uses the game's original controls. Mod source/model ports are not linked into this baseline client yet.\n");
    if(check){wprintf(L"Legacy launch dependencies checked.\n");return 0;}
    if(!join(path,gameRoot,L"legacy-logs"))return 1;
    if(!CreateDirectoryW(path,NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS)return 1;
    if(wcslen(path)+48>=MAX_PATH)return 1;
    swprintf(log,MAX_PATH,L"%ls\\client-%lu-%llu.log",path,GetCurrentProcessId(),(unsigned long long)GetTickCount64());
    stream=CreateFileW(log,GENERIC_WRITE,FILE_SHARE_READ,&security,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
    if(stream==INVALID_HANDLE_VALUE){fail(L"Cannot create client launch log");return 1;}
    startup.cb=sizeof(startup);startup.dwFlags=STARTF_USESTDHANDLES;startup.hStdOutput=startup.hStdError=stream;startup.hStdInput=GetStdHandle(STD_INPUT_HANDLE);
    swprintf(command,MAX_PATH+16,L"\"%ls\" 1",exe);wprintf(L"Client log: %ls\n",log);fflush(stdout);
    if(!CreateProcessW(exe,command,NULL,NULL,TRUE,0,NULL,working,&startup,&process)){fail(L"Windows could not start the native client");CloseHandle(stream);return 1;}
    wprintf(L"Owned client Windows PID: %lu\n",process.dwProcessId);fflush(stdout);
    CloseHandle(process.hThread);WaitForSingleObject(process.hProcess,INFINITE);
    if(!GetExitCodeProcess(process.hProcess,&code))code=1;
    CloseHandle(process.hProcess);CloseHandle(stream);
    wprintf(L"Native client exited with code %lu. Log retained: %ls\n",code,log);
    return (int)code;
}
