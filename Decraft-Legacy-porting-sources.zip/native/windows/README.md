# Native Legacy Xbox forwarding and keyboard controller

This adapter lets the supplied controller-only native Minecraft client receive keyboard and mouse input through its existing XInput interface. It is input glue, not the requested fused game.

## Use with the supplied client

1. Put `XInput9_1_0.dll` beside `x64/Release/Minecraft.Client.exe` in your extracted Minecraft archive. Preserve any existing DLL of that name before replacing it.
2. Start `Minecraft.Client.exe` with its working directory set to `Minecraft.Client`. The supplied `Start-native-client.cmd` can be placed at the archive root to do this.
3. Enter or Space selects menu options. Arrow keys navigate. The original in-game action mappings remain in control.

| Keyboard / mouse | Controller input |
| --- | --- |
| Enter / Space | A: select / jump |
| Backspace / R | B: cancel / drop |
| Q | X: crafting |
| E | Y: inventory |
| WASD | Left stick: movement |
| IJKL | Right stick: look |
| Arrow keys | D-pad |
| Left / right mouse | Right / left trigger |
| `[` / `]` | Left / right shoulder: hotbar |
| Escape | Start: pause |
| Tab | Back |
| F5 / C | Left / right stick press |

The adapter exposes one keyboard controller, accepts input only while this process has foreground focus, and has no keyboard vibration output. Connected system XInput controllers now take precedence and are forwarded unchanged, including analog state and vibration. The keyboard occupies slot zero only when no real controller occupies that slot. Physical Xbox hardware remains untested.

## Validation and build

The DLL was compiled for Windows x64 with warnings treated as errors. It passed menu navigation, world creation, world entry, movement, camera rotation and inventory checks with the supplied client under Wine, including terrain and the original HUD. Native Windows execution, combat and save/reload parity remain unverified.

Rebuild in this workspace with `python tools/build_keyboard_adapter.py`, or compile the source and exports file with a Windows x64 MinGW toolchain:

```sh
x86_64-w64-mingw32-gcc -std=c11 -O2 -Wall -Wextra -Werror -shared -static-libgcc keyboard_xinput.c keyboard_xinput.def -luser32 -o XInput9_1_0.dll
```

The original executable, assets and simulation code are retained. The build tool does not install into the original extraction. The runtime checker deploys the DLL only in its private client copy and removes it when its check finishes.

The new compiled native launcher and current test evidence are documented in [LEGACY_PORTING.md](../../fusion/LEGACY_PORTING.md). Earlier gameplay tests apply to the old keyboard-only DLL; current forwarding and native-client checks have separate receipts.
