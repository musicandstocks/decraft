/* Forward real Xbox controllers first; keyboard fallback for Legacy player one. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <string.h>

typedef struct { WORD buttons; BYTE left_trigger, right_trigger; SHORT lx,ly,rx,ry; } Pad;
typedef struct { DWORD packet; Pad pad; } State;
typedef struct { WORD left,right; } Vibration;
typedef struct { BYTE type,subtype; WORD flags; Pad pad; Vibration vibration; } Capabilities;
_Static_assert(sizeof(Pad)==12 && sizeof(State)==16 && sizeof(Capabilities)==20,"XInput ABI");
static SRWLOCK lock=SRWLOCK_INIT;
static Pad previous;
static DWORD packet;
static volatile LONG enabled=1;
typedef DWORD (WINAPI *GetStateFn)(DWORD,State*);
typedef DWORD (WINAPI *SetStateFn)(DWORD,Vibration*);
typedef DWORD (WINAPI *GetCapabilitiesFn)(DWORD,DWORD,Capabilities*);
typedef void (WINAPI *EnableFn)(BOOL);
static INIT_ONCE system_once=INIT_ONCE_STATIC_INIT;
static GetStateFn real_get;
static SetStateFn real_set;
static GetCapabilitiesFn real_caps;
static EnableFn real_enable;
static BOOL CALLBACK load_system(PINIT_ONCE once,PVOID param,PVOID *context) {
    HMODULE module=NULL;
    WCHAR path[MAX_PATH];
    const WCHAR *names[]={L"xinput1_4.dll",L"xinput1_3.dll",L"xinput9_1_0.dll"};
    unsigned int i;
    (void)once;(void)param;(void)context;
#ifdef DECRAFT_XINPUT_TEST
    /* Test build only: production always resolves an absolute system path. */
    if (GetEnvironmentVariableW(L"DECRAFT_TEST_XINPUT",path,MAX_PATH))
        module=LoadLibraryW(path);
#else
    for (i=0;i<sizeof(names)/sizeof(names[0]) && !module;++i) {
        UINT length=GetSystemDirectoryW(path,MAX_PATH);
        if (!length || length+1+wcslen(names[i])>=MAX_PATH) continue;
        path[length]=L'\\';path[length+1]=0;
        wcscat(path,names[i]);
        module=LoadLibraryW(path);
    }
#endif
    (void)i;(void)names;
    if (module) {
        /* memcpy avoids casting between incompatible C function types. */
        FARPROC proc=GetProcAddress(module,"XInputGetState");
        memcpy(&real_get,&proc,sizeof(real_get));
        proc=GetProcAddress(module,"XInputSetState");
        memcpy(&real_set,&proc,sizeof(real_set));
        proc=GetProcAddress(module,"XInputGetCapabilities");
        memcpy(&real_caps,&proc,sizeof(real_caps));
        proc=GetProcAddress(module,"XInputEnable");
        memcpy(&real_enable,&proc,sizeof(real_enable));
    }
    return TRUE;
}
static void system_ready(void) { InitOnceExecuteOnce(&system_once,load_system,NULL,NULL); }
static int down(int key) { return (GetAsyncKeyState(key)&0x8000)!=0; }
static SHORT axis(int positive,int negative) { return (SHORT)((down(positive)-down(negative))*32767); }
DWORD WINAPI XInputGetState(DWORD index,State *out) {
    DWORD pid=0,result; Pad pad={0};
    if (!out) return ERROR_BAD_ARGUMENTS;
    system_ready();
    if (real_get) {
        result=real_get(index,out);
        if (result!=ERROR_DEVICE_NOT_CONNECTED) return result;
    }
    if (index) { memset(out,0,sizeof(*out)); return ERROR_DEVICE_NOT_CONNECTED; }
    GetWindowThreadProcessId(GetForegroundWindow(),&pid);
    if (enabled && pid==GetCurrentProcessId()) {
        if (down(VK_UP)) pad.buttons|=0x0001;
        if (down(VK_DOWN)) pad.buttons|=0x0002;
        if (down(VK_LEFT)) pad.buttons|=0x0004;
        if (down(VK_RIGHT)) pad.buttons|=0x0008;
        if (down(VK_ESCAPE)) pad.buttons|=0x0010;
        if (down(VK_TAB)) pad.buttons|=0x0020;
        if (down(VK_F5)) pad.buttons|=0x0040;
        if (down('C')) pad.buttons|=0x0080;
        if (down(VK_OEM_4)) pad.buttons|=0x0100;
        if (down(VK_OEM_6)) pad.buttons|=0x0200;
        if (down(VK_RETURN)||down(VK_SPACE)) pad.buttons|=0x1000;
        if (down(VK_BACK)||down('R')) pad.buttons|=0x2000;
        if (down('Q')) pad.buttons|=0x4000;
        if (down('E')) pad.buttons|=0x8000;
        pad.lx=axis('D','A');pad.ly=axis('W','S');
        pad.rx=axis('L','J');pad.ry=axis('I','K');
        pad.left_trigger=down(VK_RBUTTON)?255:0;
        pad.right_trigger=down(VK_LBUTTON)?255:0;
    }
    AcquireSRWLockExclusive(&lock);
    if (memcmp(&pad,&previous,sizeof(pad))) { ++packet; previous=pad; }
    out->packet=packet;out->pad=pad;
    ReleaseSRWLockExclusive(&lock);
    return ERROR_SUCCESS;
}
DWORD WINAPI XInputSetState(DWORD index,Vibration *value) {
    DWORD result;
    if (!value) return ERROR_BAD_ARGUMENTS;
    system_ready();
    if (real_set) {
        result=real_set(index,value);
        if (result!=ERROR_DEVICE_NOT_CONNECTED) return result;
    }
    return index?ERROR_DEVICE_NOT_CONNECTED:ERROR_SUCCESS;
}
DWORD WINAPI XInputGetCapabilities(DWORD index,DWORD flags,Capabilities *out) {
    DWORD result;
    if (!out) return ERROR_BAD_ARGUMENTS;
    system_ready();
    if (real_caps) {
        result=real_caps(index,flags,out);
        if (result!=ERROR_DEVICE_NOT_CONNECTED) return result;
    }
    memset(out,0,sizeof(*out));
    if (index) return ERROR_DEVICE_NOT_CONNECTED;
    out->type=1;out->subtype=1;out->pad.buttons=0xf3ff;
    out->pad.left_trigger=out->pad.right_trigger=255;
    out->pad.lx=out->pad.ly=out->pad.rx=out->pad.ry=32767;
    return ERROR_SUCCESS;
}
void WINAPI XInputEnable(BOOL active) {
    system_ready();
    InterlockedExchange(&enabled,active!=0);
    if (real_enable) real_enable(active);
}
