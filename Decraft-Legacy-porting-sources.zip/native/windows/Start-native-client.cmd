@echo off
setlocal
if not exist "%~dp0Minecraft.Client\" (
  echo Place this file at the extracted archive root beside Minecraft.Client and x64.
  exit /b 1
)
if not exist "%~dp0x64\Release\Minecraft.Client.exe" (
  echo Minecraft.Client.exe was not found in x64\Release.
  exit /b 1
)
cd /d "%~dp0Minecraft.Client"
"%~dp0x64\Release\Minecraft.Client.exe" 1
