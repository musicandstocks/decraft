"""Windows launch preparation checks; actual executable smoke tests run under Wine."""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import launch_windows as windows


class WindowsLaunchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='windows-launch-test-')
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_extracts_game_dependencies_without_long_recovered_source_paths(self):
        archive = self.root / 'host.zip'
        with zipfile.ZipFile(archive, 'w') as package:
            for name in ['runtime/host/saves/New World/level.dat', 'tools/fusion.py',
                         'assets/original-data/halo2/damage-table.bin',
                         'build/fusion/windows/decraft_fusion.dll',
                         'original-sources/modpack/' + 'long-source-path/' * 25 + 'Source.java']:
                package.writestr(name, name.encode())
        destination = self.root / 'game'
        with mock.patch.object(windows, 'HOST_SHA256', windows.digest(archive)):
            windows.extract_host(archive, destination)
        self.assertEqual((destination / 'runtime/host/saves/New World/level.dat').read_bytes(),
                         b'runtime/host/saves/New World/level.dat')
        self.assertTrue((destination / 'build/fusion/windows/decraft_fusion.dll').is_file())
        self.assertFalse((destination / 'original-sources').exists())

    def test_existing_game_and_saved_progress_are_preserved(self):
        game = self.root / 'game'
        game.mkdir()
        save = game / 'level.dat'
        save.write_bytes(b'user saved progress')
        with self.assertRaisesRegex(RuntimeError, 'Existing game directory preserved'):
            windows.extract_host(self.root / 'missing.zip', game)
        self.assertEqual(save.read_bytes(), b'user saved progress')

    def test_corrupt_download_never_creates_a_game(self):
        archive = self.root / 'host.zip'
        archive.write_bytes(b'partial download')
        with self.assertRaisesRegex(ValueError, 'incomplete'):
            windows.extract_host(archive, self.root / 'game')
        self.assertFalse((self.root / 'game').exists())

    def test_unsafe_archive_paths_are_rejected(self):
        for name in ['../runtime/saves/level.dat', '/runtime/file', 'C:/runtime/file',
                     'runtime/../../file', 'runtime\\..\\file']:
            with self.subTest(name=name), self.assertRaises(ValueError):
                windows.game_member(name)

    def test_java_17_and_32_bit_java_are_rejected(self):
        for output in ['java.version = 17.0.1\nsun.arch.data.model = 64',
                       'java.version = 1.8.0_504\nsun.arch.data.model = 32']:
            probe = subprocess.CompletedProcess([], 0, '', output)
            with mock.patch.object(windows.subprocess, 'run', return_value=probe):
                with self.assertRaisesRegex(RuntimeError, '64-bit Java 8'):
                    windows.prepare_java(self.root, self.root / 'java.exe')

    def test_windows_config_retains_linux_config_and_uses_original_dlls(self):
        runtime = self.root / 'runtime'
        natives = runtime / 'host/bin/natives'
        natives.mkdir(parents=True)
        for name in ['lwjgl64.dll', 'OpenAL64.dll', 'jinput-dx8_64.dll', 'jinput-raw_64.dll']:
            (natives / name).write_bytes(b'dll')
        java = self.root / 'java.exe'
        java.write_bytes(b'java')
        kernel = self.root / 'build/fusion/windows/decraft_fusion.dll'
        kernel.parent.mkdir(parents=True)
        kernel.write_bytes(b'kernel')
        config = {'java': 'java/linux/bin/java', 'game_directory': 'host',
                  'natives': 'natives/linux', 'classpath': ['host/bin/natives/lwjgl64.dll'],
                  'main_class': 'net.minecraft.launchwrapper.Launch',
                  'arguments': ['--gameDir', 'host', '--assetsDir', 'assets']}
        original = json.dumps(config).encode()
        (runtime / 'forge-launch.json').write_bytes(original)
        result = windows.prepare_config(self.root, java)
        self.assertEqual((runtime / 'forge-launch.json').read_bytes(), original)
        self.assertEqual(result['java'], str(java))
        self.assertEqual(result['natives'], str(natives))
        self.assertTrue((runtime / 'forge-launch-windows.json').is_file())

    def test_find_game_reuses_existing_extracted_host(self):
        root = self.root / 'Already extracted game'
        (root / 'runtime').mkdir(parents=True)
        (root / 'tools').mkdir()
        (root / 'runtime/forge-launch.json').write_text('{}')
        (root / 'tools/fusion.py').write_text('')
        self.assertEqual(windows.find_game(self.root), root)
        self.assertEqual(windows.find_game(root), root)


if __name__ == '__main__':
    unittest.main()
