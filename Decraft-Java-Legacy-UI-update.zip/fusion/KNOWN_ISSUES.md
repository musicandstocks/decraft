# Known issues

The selected game base is now Java Forge 1.7.10 with Legacy-style presentation. Native Legacy build requirements below apply only to the preserved alternative. The current Java update is a presentation/controller/hub update; full original cross-game campaigns and newer-mod ports remain incomplete. Physical Xbox and native Windows desktop testing are unavailable; Windows checks use actual Windows executables under Wine.

The source/runtime SDK and Linux original-host launch package are not the complete unified game or a fused Windows game executable.

- VoxelMap 1.6.17 crashes while creating a death waypoint before its waypoint renderer initializes when reopening the saved dead test player. The private host uses its supported `Deathpoints:0` setting; minimap/HUD and OpenBlocks grave inventory remain enabled. `voxelmap-reload-fix.json` records the workaround and live verification status.

- The six hub gates and five destination dimensions are implemented. The new dimensions are limited imports/adaptations: Flash room connectivity, a Minecraft training landscape, bounded Armory collision geometry, an authored exploration domain and a 3D lawn grid. They do not implement full original campaigns, NPCs or game-specific combat. `PORTALS.md` distinguishes each world's exact scope.

- The original supplied Isaac SWF/timelines are reconstructed and decompiled. Its tested numeric routines agree with the existing port, and a source-derived room-connectivity import is available. Full Flash execution, asset/timeline adaptation and the 3D original campaign remain unimplemented. Repentance remains excluded; full original-build parity is not established by numeric comparisons.
- Halo maps are supplied, but both XBEs differ from the decompilation's exact retail hash. Compatible native Xbox build support and a playable mission host are unavailable here. Rendering, full movement collision, AI, vehicles, scripts, objectives and checkpoints are not integrated.
- Native Minecraft's compatible MSVC v110 source build and cross-game world/entity/render/HUD/save adapters are incomplete. The native Windows client baseline and the Java modpack diagnostic are separate references, not a fused implementation.
- Two Scala continuations artifacts remain excluded because they do not match the original launcher pins. Full-pack parity is unverified despite observed terrain, movement, inventory and save-to-title in the limited diagnostic.
- The original modpack logs report a Twilight Forest biome-ID conflict, unresolved Flan equipment references and NEI identifier warnings. These need content-specific investigation. Network update/profile checks also fail in this restricted environment; their failures are recorded separately from the verified local controls.
- The first extended Forge run crashed in Java's native ZIP reader. Disabling ZIP memory mapping avoided that crash. A later black-world display was resolved in the combined bounded-thread/framebuffer-disabled diagnostic configuration; individual rendering causes were not isolated. Subsequent combined launches restored the saved position exactly and passed six physical gate checks, saved-home return and normal exit.
- An initial portal build failed HelpFixer's private anonymous command comparison probe before player entry. The reflection accessibility fix passed the focused Java ABI regression and the subsequent real-world launch. Original player inventory and position were preserved.
- The initial destination entry let JustAnotherSpawner inject host monsters and kill the test player. The corrected build denies living-mob joins/spawn checks only in the five destination dimensions. Original inventory recovery and corrected world checks are tracked in `world-spawn-failure.json`; original Minecraft spawning is unchanged.
- Full BT3 and Digimon gameplay/resource adaptation, universal item conversions, complete original campaign saves and 3D Isaac progression remain incomplete. Physical travel preserves the same Minecraft player/inventory and dimension chunks. This does not supply game-specific inventory/HUD rules or original campaign progression.
- Complete original asset/disc trees remain in the cloud input workspace; the SDK includes code, selected compiled components, pinned slices, manifests, reference art and evidence. It does not duplicate the full game installation data.

Evidence and next requirements are tracked in `DEVELOPMENT_LEDGER.md`, `ASSETS_NEEDED.md`, `content-completeness.json` and individual validation receipts. No autonomous process continues after the active environment/turn stops.

## Java presentation limitations

The theme is Legacy-inspired rather than pixel-identical. Custom mod icon buttons on the pause screen can appear as unlabeled beveled buttons; their original actions remain registered. Physical Xbox hardware and native Windows desktop behavior remain untested. Current main/options/creative inventory/HUD, standard pause Hub action, save/reload and normal exit passed with actual Windows executables under Wine.

## Preserved native Legacy alternative

The native baseline launcher is separate from the earlier Java host. Native hub/world travel, Forge mod behaviors, texture/entity binding and Gecko animation/Molang execution are not implemented. Matching MSVC v110 toolchain is absent. Two new JAR uploads exceed the 32 MiB transfer tool limit. See LEGACY_PORTING.md and legacy-mod-port-status.json.

Bounded native world test shutdown through WM_CLOSE returned exit 2138. The client rendered terrain/HUD and responded to camera/inventory; this result does not verify normal Save and Quit or save/reload parity.
