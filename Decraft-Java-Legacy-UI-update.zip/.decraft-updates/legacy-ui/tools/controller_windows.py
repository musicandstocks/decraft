#!/usr/bin/env python3
"""Xbox/XInput controls for the owned Minecraft window; no driver installation."""
import argparse
import ctypes as C
import math
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path

DPAD_UP, DPAD_DOWN, DPAD_LEFT, DPAD_RIGHT = 1, 2, 4, 8
START, BACK, LEFT_STICK, RIGHT_STICK = 16, 32, 64, 128
LEFT_BUMPER, RIGHT_BUMPER = 256, 512
A, B, X, Y = 4096, 8192, 16384, 32768
SCANS = {'w': 0x11, 'a': 0x1e, 's': 0x1f, 'd': 0x20, 'space': 0x39,
         'shift': 0x2a, 'ctrl': 0x1d, 'e': 0x12, 'q': 0x10,
         'escape': 0x01, 'f5': 0x3f, 'f6': 0x40, 'f2': 0x3c,
         'up': 0x148, 'down': 0x150, 'left': 0x14b, 'right': 0x14d}


class Pad(C.Structure):
    _fields_ = [('buttons', C.c_uint16), ('lt', C.c_uint8), ('rt', C.c_uint8),
                ('lx', C.c_int16), ('ly', C.c_int16), ('rx', C.c_int16), ('ry', C.c_int16)]


class State(C.Structure):
    _fields_ = [('packet', C.c_uint32), ('pad', Pad)]


class Mouse(C.Structure):
    _fields_ = [('dx', C.c_int32), ('dy', C.c_int32), ('data', C.c_uint32),
                ('flags', C.c_uint32), ('time', C.c_uint32), ('extra', C.c_uint64)]


class Keyboard(C.Structure):
    _fields_ = [('vk', C.c_uint16), ('scan', C.c_uint16), ('flags', C.c_uint32),
                ('time', C.c_uint32), ('extra', C.c_uint64)]


class Hardware(C.Structure):
    _fields_ = [('message', C.c_uint32), ('low', C.c_uint16), ('high', C.c_uint16)]


class Payload(C.Union):
    _fields_ = [('mouse', Mouse), ('key', Keyboard), ('hardware', Hardware)]


class Input(C.Structure):
    _fields_ = [('type', C.c_uint32), ('value', Payload)]


@dataclass(frozen=True)
class Plan:
    keys: frozenset = frozenset()
    mouse: frozenset = frozenset()
    dx: float = 0.0
    dy: float = 0.0
    wheel: int = 0
    menu: bool = True


def stick(x, y, deadzone):
    x, y = max(-1.0, x / 32767.0), max(-1.0, y / 32767.0)
    size = math.hypot(x, y)
    if size <= deadzone:
        return 0.0, 0.0
    scale = (min(size, 1.0) - deadzone) / (1.0 - deadzone)
    return x / size * scale, y / size * scale


def plan(pad, previous, mode, seconds, focused=True):
    """Map one pad sample; edges prevent repeated pause/inventory toggles."""
    if pad is None or not focused:
        return Plan(menu=mode != 'game')
    keys, mouse = set(), set()
    buttons = pad.buttons
    pressed = buttons & ~previous
    menu = mode != 'game'
    lx, ly = stick(pad.lx, pad.ly, .24)
    rx, ry = stick(pad.rx, pad.ry, .22)
    if menu:
        for flag,key in [(DPAD_UP,'up'),(DPAD_DOWN,'down'),(DPAD_LEFT,'left'),(DPAD_RIGHT,'right')]:
            if buttons & flag: keys.add(key)
        vx, vy = (rx, ry) if rx or ry else (lx, ly)
        dx, dy = vx * 650, -vy * 650
        if buttons & A or pad.rt > 40:
            mouse.add('left')
        if pad.lt > 40:
            mouse.add('right')
        if buttons & X:
            keys.add('shift'); mouse.add('left')
        if pressed & (B | Y):
            keys.add('escape')
    else:
        dx = math.copysign(abs(rx) ** 1.6, rx) * 1200
        dy = -math.copysign(abs(ry) ** 1.6, ry) * 1200
        if ly > .15: keys.add('w')
        if ly < -.15: keys.add('s')
        if lx > .15: keys.add('d')
        if lx < -.15: keys.add('a')
        if buttons & A: keys.add('space')
        if buttons & RIGHT_STICK: keys.add('shift')
        if buttons & LEFT_STICK: keys.add('ctrl')
        if pressed & (X | Y): keys.add('e')
        if pressed & B: keys.add('q')
        if pressed & DPAD_UP: keys.add('f5')
        if pressed & DPAD_DOWN: keys.add('f2')
        if pad.rt > 40: mouse.add('left')
        if pad.lt > 40: mouse.add('right')
    if pressed & START: keys.add('escape')
    if pressed & BACK: keys.add('f6')
    wheel = (120 if pressed & (LEFT_BUMPER | (0 if menu else DPAD_LEFT)) else 0)
    wheel -= (120 if pressed & (RIGHT_BUMPER | (0 if menu else DPAD_RIGHT)) else 0)
    dt = max(0.0, min(seconds, .05))
    return Plan(frozenset(keys), frozenset(mouse), dx * dt, dy * dt, wheel, menu)


class WindowsOutput:
    def __init__(self, pid):
        if os.name != 'nt' or C.sizeof(C.c_void_p) != 8:
            raise RuntimeError('Controller support requires Windows x64')
        if C.sizeof(Input) != 40 or C.sizeof(State) != 16:
            raise RuntimeError('Incompatible Windows input ABI')
        self.pid = pid
        self.user = C.WinDLL('user32', use_last_error=True)
        self.kernel = C.WinDLL('kernel32', use_last_error=True)
        self.user.GetForegroundWindow.restype = C.c_void_p
        self.user.GetWindowThreadProcessId.argtypes = [C.c_void_p, C.POINTER(C.c_uint32)]
        self.user.SendInput.argtypes = [C.c_uint32, C.POINTER(Input), C.c_int]
        self.user.SendInput.restype = C.c_uint32
        self.user.GetClientRect.argtypes = [C.c_void_p, C.c_void_p]
        self.user.ClientToScreen.argtypes = [C.c_void_p, C.c_void_p]
        self.kernel.OpenProcess.argtypes = [C.c_uint32, C.c_int, C.c_uint32]
        self.kernel.OpenProcess.restype = C.c_void_p
        self.kernel.GetExitCodeProcess.argtypes = [C.c_void_p, C.POINTER(C.c_uint32)]
        self.kernel.CloseHandle.argtypes = [C.c_void_p]
        self.process = self.kernel.OpenProcess(0x1000, False, pid)
        if not self.process:
            raise RuntimeError('Minecraft process is unavailable')
        self.keys, self.mouse = set(), set()
        self.remainder = [0.0, 0.0]

    def alive(self):
        code = C.c_uint32()
        return bool(self.kernel.GetExitCodeProcess(self.process, C.byref(code))) and code.value == 259

    def foreground(self):
        window = self.user.GetForegroundWindow()
        pid = C.c_uint32()
        self.user.GetWindowThreadProcessId(window, C.byref(pid))
        return window if pid.value == self.pid else None

    def send(self, inputs):
        if not inputs: return
        raw = (Input * len(inputs))(*inputs)
        count = self.user.SendInput(len(inputs), raw, C.sizeof(Input))
        if count != len(inputs):
            raise RuntimeError('Windows blocked game-controller input (SendInput error ' +
                               str(C.get_last_error()) + ')')

    @staticmethod
    def key(name, down):
        result = Input(); result.type = 1
        result.value.key.scan = SCANS[name] & 0xff
        result.value.key.flags = 0x8 | (0x1 if SCANS[name]>0xff else 0) | (0 if down else 0x2)
        return result

    @staticmethod
    def click(name, down):
        result = Input(); result.type = 0
        result.value.mouse.flags = (0x2 if down else 0x4) if name == 'left' else (0x8 if down else 0x10)
        return result

    def apply(self, target):
        events = [self.key(k, False) for k in self.keys - target.keys]
        events += [self.click(b, False) for b in self.mouse - target.mouse]
        events += [self.key(k, True) for k in target.keys - self.keys]
        events += [self.click(b, True) for b in target.mouse - self.mouse]
        self.send(events)
        self.keys, self.mouse = set(target.keys), set(target.mouse)
        window = self.foreground()
        if window:
            self.remainder[0] += target.dx; self.remainder[1] += target.dy
            dx, dy = int(self.remainder[0]), int(self.remainder[1])
            self.remainder[0] -= dx; self.remainder[1] -= dy
            if dx or dy:
                if target.menu:
                    point = (C.c_int32 * 2)(); origin = (C.c_int32 * 2)(); rect = (C.c_int32 * 4)()
                    if (self.user.GetCursorPos(C.byref(point)) and self.user.GetClientRect(window, C.byref(rect))
                            and self.user.ClientToScreen(window, C.byref(origin))):
                        self.user.SetCursorPos(max(origin[0] + 2, min(point[0] + dx, origin[0] + rect[2] - 3)),
                                               max(origin[1] + 2, min(point[1] + dy, origin[1] + rect[3] - 3)))
                else:
                    event = Input(); event.value.mouse.dx = dx; event.value.mouse.dy = dy
                    event.value.mouse.flags = 1
                    self.send([event])
            if target.wheel:
                event = Input(); event.value.mouse.flags = 0x800
                event.value.mouse.data = target.wheel & 0xffffffff
                self.send([event])
        else:
            self.remainder[:] = [0.0, 0.0]

    def close(self):
        try: self.apply(Plan())
        finally: self.kernel.CloseHandle(self.process)


class XInput:
    def __init__(self):
        self.library = None
        for name in ['xinput1_4.dll', 'xinput1_3.dll', 'xinput9_1_0.dll']:
            try:
                self.library = C.WinDLL(name, winmode=0x800)
                break
            except OSError: pass
        if self.library is None: raise RuntimeError('Windows XInput is unavailable')
        self.library.XInputGetState.argtypes = [C.c_uint32, C.POINTER(State)]
        self.library.XInputGetState.restype = C.c_uint32

    def poll(self):
        for index in range(4):
            state = State()
            if self.library.XInputGetState(index, C.byref(state)) == 0:
                return index, state.pad
        return None, None

class SharedContext:
    """Read Java's atomic context file with Windows delete sharing enabled."""
    def __init__(self):
        self.kernel=C.WinDLL('kernel32',use_last_error=True)
        self.kernel.CreateFileW.argtypes=[C.c_wchar_p,C.c_uint32,C.c_uint32,C.c_void_p,C.c_uint32,C.c_uint32,C.c_void_p]
        self.kernel.CreateFileW.restype=C.c_void_p
        self.kernel.ReadFile.argtypes=[C.c_void_p,C.c_void_p,C.c_uint32,C.POINTER(C.c_uint32),C.c_void_p]
        self.kernel.CloseHandle.argtypes=[C.c_void_p]
    def read(self,path):
        handle=self.kernel.CreateFileW(str(path),0x80000000,7,None,3,0x80,None)
        if handle in (None,C.c_void_p(-1).value):return 'menu'
        try:
            data=C.create_string_buffer(32);length=C.c_uint32()
            if not self.kernel.ReadFile(handle,data,32,C.byref(length),None):return 'menu'
            value=data.raw[:length.value].decode('ascii').strip()
            return value if value in {'game','menu'} else 'menu'
        except UnicodeError:return 'menu'
        finally:self.kernel.CloseHandle(handle)

def run(pid, status, stop):
    output, device, context = WindowsOutput(pid), XInput(), SharedContext()
    previous, connected, focused = 0, None, False
    last = time.monotonic()
    print('Xbox controls ready. View: portal hub; Menu: pause; sticks: move/look; Y: inventory.', flush=True)
    try:
        while output.alive() and not stop.exists():
            now = time.monotonic(); dt = now - last; last = now
            index, pad = device.poll()
            if index != connected:
                print('Xbox controller connected: ' + str(index) if index is not None else 'Xbox controller disconnected.', flush=True)
                connected = index
            active = bool(output.foreground())
            mode=context.read(status)
            old = previous if active and focused else (pad.buttons if pad is not None else 0)
            output.apply(plan(pad, old, mode, dt, active))
            previous = pad.buttons if pad is not None else 0
            focused = active
            time.sleep(.015)
    finally:
        output.close()
        print('Controller stopped; all controller-held keys and mouse buttons released.', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pid', required=True, type=int)
    parser.add_argument('--status', required=True, type=Path)
    parser.add_argument('--stop', required=True, type=Path)
    args = parser.parse_args()
    try: run(args.pid, args.status, args.stop)
    except KeyboardInterrupt: pass
    except (OSError, RuntimeError) as error:
        print('CONTROLLER ERROR: ' + str(error), file=sys.stderr, flush=True)
        sys.exit(1)
