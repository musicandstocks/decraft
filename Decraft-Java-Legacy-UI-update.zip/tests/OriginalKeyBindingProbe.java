package decraft.probe;
/** Verify queue delivery using the unchanged, signed supplied Minecraft bytecode. */
public final class OriginalKeyBindingProbe {
    public static void main(String[] args) throws Exception {
        Class<?> type=Class.forName("bal");
        Object stream=type.getConstructor(String.class,int.class,String.class).newInstance("key.streamStartStop",64,"misc");
        type.getMethod("b",int.class).invoke(stream,0);
        Object hub=type.getConstructor(String.class,int.class,String.class).newInstance("key.decraft.hub",64,"decraft");
        type.getMethod("b").invoke(null);
        type.getMethod("a",int.class).invoke(null,64);
        if(!((Boolean)type.getMethod("f").invoke(hub))||((Boolean)type.getMethod("f").invoke(stream))||((Boolean)type.getMethod("f").invoke(hub)))throw new AssertionError("Hub pulse/conflict handling failed");
        System.out.println("PASS: actual Minecraft KeyBinding queues F6 exclusively to the hub and consumes one pulse");
    }
}
