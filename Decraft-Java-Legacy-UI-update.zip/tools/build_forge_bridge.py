#!/usr/bin/env python3
"""Compile the bridge against the supplied, unmodified Forge binary."""
import hashlib
import json
import subprocess
import shutil
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
JDK = Path('/workspace/runtime-tools/java8/jdk8u504-b01/bin')
FORGE = Path('/workspace/modpack-decompile/extracted/Not The 1.7.10 Pack/minecraft/bin/modpack.jar')
if not JDK.exists() and shutil.which('javac'):JDK=Path(shutil.which('javac')).resolve().parent
if (PROJECT/'references/forge/modpack.jar').exists():FORGE=PROJECT/'references/forge/modpack.jar'

def build():
    output = PROJECT/'build/fusion/forge'
    classes = output/'classes'
    classes.mkdir(parents=True,exist_ok=True)
    source = PROJECT/'bridge/forge/src/main/java/decraft/bridge/FusionBridge.java'
    sources = sorted(source.parent.glob('*.java'))
    resources=PROJECT/'bridge/forge/src/main/resources'
    asm=Path('/workspace/runtime-tools/forge-libraries/org/ow2/asm/asm-all/5.0.3/asm-all-5.0.3.jar')
    if (PROJECT/'references/forge/asm-all-5.0.3.jar').exists():asm=PROJECT/'references/forge/asm-all-5.0.3.jar'
    receipt_path=PROJECT/'fusion/forge-bridge-build.json'
    prior=json.loads(receipt_path.read_text()) if receipt_path.exists() else {}
    subprocess.run([str(JDK/'javac'),'-source','8','-target','8','-encoding','UTF-8',
                    '-cp',str(FORGE)+':'+str(asm),'-d',str(classes),*[str(p) for p in sources]],check=True)
    shutil.copytree(resources,classes,dirs_exist_ok=True)
    (classes/'mcmod.info').write_text(json.dumps([{
        'modid':'decraftbridge','name':'Decraft Source Runtime Bridge','version':'0.1.0',
        'mcversion':'1.7.10','description':'Asynchronous original tick observation for the shared source runtime; game fusion incomplete.'
    }])+'\n')
    jar = output/'decraft-bridge-0.1.0.jar'
    subprocess.run([str(JDK/'jar'),'cf',str(jar),'-C',str(classes),'.'],check=True)
    report = {'artifact':str(jar),'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),
              'forge_reference':str(FORGE),'forge_sha256':hashlib.sha256(FORGE.read_bytes()).hexdigest(),
              'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
              'sources':[{ 'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],
              'prior_owned_bridge_sha256':list(dict.fromkeys(prior.get('prior_owned_bridge_sha256',[])+([prior['sha256']] if prior.get('sha256') else []))),
              'source_compilation':'passed','original_mods_modified':False,
              'runtime_validation':'Compare this artifact hash with the separate combined-host and portal-host live verification receipts',
              'world_layouts':json.loads((PROJECT/'fusion/world-layout-build.json').read_text()),
              'asm_reference':str(asm),'asm_sha256':hashlib.sha256(asm.read_bytes()).hexdigest(),
              'scope':'Original server tick transport, six physical gates and five persistent imported/adapted dimensions; full original campaigns remain incomplete.'}
    (PROJECT/'fusion/forge-bridge-build.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))

if __name__=='__main__':
    build()
