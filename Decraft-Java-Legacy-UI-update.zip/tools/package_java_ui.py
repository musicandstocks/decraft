#!/usr/bin/env python3
"""Package the verified Java presentation update for an existing Decraft host."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STAGE = ROOT / 'build/java-legacy-ui-update'
PAYLOAD = STAGE / '.decraft-updates/legacy-ui'


def stage():
    for name in ['tools/launch_windows.py', 'tools/launch_combined.py',
                 'tools/controller_windows.py', 'fusion/forge-bridge-build.json',
                 'build/fusion/forge/decraft-bridge-0.1.0.jar']:
        target = PAYLOAD / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / name, target)
    shutil.copy2(ROOT / 'fusion/JAVA_LEGACY_UI.md', STAGE / 'README-UI-update.md')


def package():
    stage()
    receipt = json.loads((ROOT / 'fusion/java-legacy-ui-validation.json').read_text())
    build = json.loads((ROOT / 'fusion/forge-bridge-build.json').read_text())
    if receipt['bridge_sha256'] != build['sha256'] or not receipt['menu_verified']:
        raise RuntimeError('Live verification must match the packaged bridge')
    entries = {str(p.relative_to(STAGE)): p for p in STAGE.rglob('*') if p.is_file()}
    for parent in ['bridge/forge/src/main/java/decraft/bridge',
                   'bridge/forge/src/main/resources']:
        entries.update({str(p.relative_to(ROOT)): p for p in (ROOT / parent).rglob('*') if p.is_file()})
    for name in ['fusion/java-legacy-ui-validation.json', 'fusion/JAVA_LEGACY_UI.md',
                 'fusion/java-background-profiling.json', 'fusion/java-pause-menu-config.json',
                 'fusion/content-completeness.json',
                 'fusion/KNOWN_ISSUES.md', 'fusion/DEVELOPMENT_LEDGER.md',
                 'tools/package_java_ui.py', 'tools/build_forge_bridge.py',
                 'tests/OriginalKeyBindingProbe.java',
                 'logs/java-legacy-ui-final-regression.log', 'logs/java-legacy-ui-transport.log',
                 'logs/java-controller-sharing.log', 'logs/java-original-keybinding.log',
                 'logs/java-xbox-menu-input.log',
                 'logs/java-legacy-ui-staged-updater.log']:
        entries[name] = ROOT / name
    for name in receipt.get('screenshots', []):
        entries['verification/' + Path(name).name] = Path(name)
    for evidence in receipt.get('additional_evidence_files', []):
        entries[evidence['archive_name']] = Path(evidence['path'])
    destination = ROOT / 'build/Decraft-Java-Legacy-UI-update.zip'
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, source in sorted(entries.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, source.read_bytes())
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('Update archive failed its CRC check')
        actual = hashlib.sha256(archive.read('.decraft-updates/legacy-ui/build/fusion/forge/decraft-bridge-0.1.0.jar')).hexdigest()
        if actual != build['sha256']:
            raise RuntimeError('Packaged bridge differs from verified bridge')
    result = {'archive': str(destination), 'bytes': destination.stat().st_size,
              'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
              'bridge_sha256': actual, 'crc_verified': True, 'full_fusion_ready': False}
    (ROOT / 'fusion/java-legacy-ui-package.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    package()
