package decraft.bridge;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;

/** Observe original server ticks; simulation stays owned by the original pack. */
@Mod(modid="decraftbridge", name="Decraft Source Runtime Bridge", version="0.1.0",
     acceptedMinecraftVersions="[1.7.10]")
public final class FusionBridge {
    private final Logger log = Logger.getLogger("decraft.bridge");
    private final AtomicReference<String> pending = new AtomicReference<String>();
    private ScheduledExecutorService sender;
    private URI endpoint;
    private long ticks;
    private PortalHost portals;

    @Mod.EventHandler
    public void preInitialize(FMLPreInitializationEvent event) {
        try { WorldHost.register(); }
        catch(Exception error) { throw new IllegalStateException("Failed to register saved destination worlds",error); }
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new DestinationRules());
    }

    @Mod.EventHandler
    public void initialize(FMLInitializationEvent event) {
        if(FMLCommonHandler.instance().getSide().isClient()) {
            ClientControls controls=new ClientControls();
            FMLCommonHandler.instance().bus().register(controls);
            net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(controls);
            LegacyUI legacy=new LegacyUI(controls);
            FMLCommonHandler.instance().bus().register(legacy);
            net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(legacy);
        }
        String address = System.getProperty("decraft.bridge.url", "");
        if (address.length() == 0) {
            log.info("Decraft bridge loaded; configure -Ddecraft.bridge.url to connect the shared runtime.");
            return;
        }
        try {
            endpoint = new URI(address);
            if (!"http".equals(endpoint.getScheme()) || !"127.0.0.1".equals(endpoint.getHost())
                    || !"/v1/events".equals(endpoint.getPath()) || endpoint.getUserInfo() != null
                    || endpoint.getQuery() != null || endpoint.getFragment() != null) {
                throw new IllegalArgumentException("Expected http://127.0.0.1:PORT/v1/events");
            }
        } catch (Exception error) {
            throw new IllegalArgumentException("Invalid local Decraft bridge address", error);
        }
        sender = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "Decraft bridge transport");
            thread.setDaemon(true);
            return thread;
        });
        sender.scheduleWithFixedDelay(() -> transmit(), 0, 1, TimeUnit.SECONDS);
        portals = new PortalHost(endpoint, sender);
        FMLCommonHandler.instance().bus().register(this);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> sender.shutdownNow()));
        log.info("Decraft bridge initialized; original server ticks will be reported asynchronously.");
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) throws Exception {
        if (portals != null) portals.register(event);
    }

    @SubscribeEvent
    public void serverTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (portals != null) portals.tick();
        ++ticks;
        if (ticks % 20 == 0) {
            pending.set("{\"module\":\"modpack\",\"event\":\"server_tick\",\"ticks\":" + ticks + "}");
        }
    }

    private void transmit() {
        String message = pending.getAndSet(null);
        if (message == null) return;
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) endpoint.toURL().openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(500);
            connection.setReadTimeout(500);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            byte[] bytes = message.getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream output = connection.getOutputStream()) { output.write(bytes); }
            if (connection.getResponseCode() != 202) log.fine("Decraft runtime did not accept the tick event.");
        } catch (Exception error) {
            log.fine("Decraft runtime is unavailable: " + error.getClass().getSimpleName());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
