package decraft.bridge;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.logging.Logger;

/** Physical gates, saved destination dimensions and exact overworld return. */
final class PortalHost {
    static final String[] IDS = {"minecraft", "isaac", "bt3", "halo2", "digimon", "pvz"};
    static final String[] LABELS = {"MINECRAFT", "ISAAC FLASH", "DBZ BT3", "HALO 2", "DIGIMON WORLD 2", "PVZ"};
    private static final int[] COLORS = {5, 3, 1, 11, 10, 13};
    private final URI endpoint;
    private final ScheduledExecutorService sender;
    private final Logger log = Logger.getLogger("decraft.portals");
    private final WeakHashMap<Object, Integer> cooldown = new WeakHashMap<Object, Integer>();
    private final WeakHashMap<Object, Boolean> automaticHubAttempted = new WeakHashMap<Object, Boolean>();
    private final ConcurrentLinkedQueue<Runnable> replies = new ConcurrentLinkedQueue<Runnable>();
    private int ticks;

    PortalHost(URI events, ScheduledExecutorService sender) {
        endpoint = events.resolve("/v1/portals/enter"); this.sender = sender;
    }

    // Reflection uses the original 1.7.10 SRG ABI. It avoids recompiling or
    // shipping substitute Minecraft class definitions with this add-on.
    private static Object invoke(Object value, String name, Object... args) throws Exception {return WorldHost.call(value,name,args);}
    private static Object field(Object value, String name) throws Exception {
        Field field = value.getClass().getField(name); field.setAccessible(true); return field.get(value);
    }
    private static Object server() throws Exception {
        return invoke(FMLCommonHandler.instance(), "getMinecraftServerInstance");
    }
    private static void chat(Object player, String text) throws Exception {
        Object component = Class.forName("net.minecraft.util.ChatComponentText").getConstructor(String.class).newInstance(text);
        invoke(player, "func_145747_a", component);
    }
    private static Path stateFile(Object world) throws Exception {
        Object save = invoke(world, "func_72860_G");
        java.io.File directory = (java.io.File) invoke(save, "func_75765_b");
        return directory.toPath().resolve("decraft-portals.properties");
    }
    private static Properties read(Object world) throws Exception {
        Properties state = new Properties(); Path path = stateFile(world);
        if (Files.exists(path)) try (InputStream input = Files.newInputStream(path)) { state.load(input); }
        return state;
    }
    private static void write(Object world, Properties state) throws Exception {
        Path target = stateFile(world); Path temporary = Files.createTempFile(target.getParent(), "decraft-portals-", ".tmp");
        try {
            try (OutputStream output = Files.newOutputStream(temporary)) { state.store(output, "Decraft original-host gates and saved return positions"); }
            Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } finally { Files.deleteIfExists(temporary); }
    }
    private static String identity(Object player) throws Exception { return invoke(player, "func_110124_au").toString(); }
    private static double coordinate(Object player, String name) throws Exception { return ((Number)field(player, name)).doubleValue(); }
    private static int dimension(Object world) throws Exception { return ((Number)field(field(world, "field_73011_w"), "field_76574_g")).intValue(); }
    private static double[] home(Properties state, Object player) throws Exception {
        String record = state.getProperty("home." + identity(player));
        if (record == null) return null;
        String[] parts = record.split(",");
        if (parts.length != 4) throw new IllegalArgumentException("Invalid saved portal home");
        double[] position = new double[4];
        for (int i=0; i<4; i++) { position[i] = Double.parseDouble(parts[i]); if (!Double.isFinite(position[i])) throw new IllegalArgumentException("Invalid saved home coordinate"); }
        return position;
    }
    private static void remember(Properties state, Object player, Object world) throws Exception {
        String key = "home." + identity(player);
        if (!state.containsKey(key)) state.setProperty(key, dimension(world) + "," + coordinate(player, "field_70165_t") + ","
            + coordinate(player, "field_70163_u") + "," + coordinate(player, "field_70161_v"));
    }

    void register(FMLServerStartingEvent event) throws Exception {
        Class<?> command = Class.forName("net.minecraft.command.ICommand");
        Object proxy = Proxy.newProxyInstance(command.getClassLoader(), new Class<?>[]{command}, (object, method, args) -> {
            String name = method.getName();
            if (name.equals("func_71517_b")) return "decraft";
            if (name.equals("func_71518_a")) return "/decraft gates | gate <minecraft|isaac|bt3|halo2|digimon|pvz> | hub | home";
            if (name.equals("func_71514_a")) return Collections.emptyList();
            if (name.equals("func_71519_b")) return (Boolean)invoke(server(), "func_71264_H");
            if (name.equals("func_71516_a")) return Arrays.asList(IDS);
            if (name.equals("func_82358_a")) return false;
            if (name.equals("compareTo")) return "decraft".compareTo((String)invoke(args[0], "func_71517_b"));
            if (name.equals("hashCode")) return System.identityHashCode(object);
            if (name.equals("equals")) return object == args[0];
            if (name.equals("toString")) return "Decraft portal command";
            if (name.equals("func_71515_b")) {
                try { command(args[0], (String[])args[1]); }
                catch (Exception error) { chat(args[0], "Decraft gate action failed safely: " + error.getClass().getSimpleName()); log.warning(error.toString()); }
                return null;
            }
            throw new UnsupportedOperationException("Unknown original command ABI: " + name);
        });
        for (Method method : event.getClass().getMethods()) if (method.getName().equals("registerServerCommand")) {
            method.invoke(event, proxy); log.info("Physical portal command registered for all six game destinations."); return;
        }
        throw new NoSuchMethodException("registerServerCommand");
    }

    private void command(Object player, String[] args) throws Exception {
        Object world = field(player, "field_70170_p");
        if(args.length==1 && args[0].equals("returngate")) {
            int index=WorldHost.index(dimension(world));if(index<=0){chat(player,"Visit a destination world first.");return;}
            int[] a=WorldHost.layout(index).gate;cooldown.put(player,0);
            invoke(player,"func_70634_a",a[0]+2.,a[1]+1.,a[2]-.2);return;
        }
        if(args.length==1 && (args[0].equals("hub")||args[0].equals("home"))) {
            if(args[0].equals("hub") && dimension(world)==0 && !read(world).containsKey("anchor")) {
                build(player,world);return;
            }
            if(WorldHost.index(dimension(world))<0){chat(player,"Use these return controls from a Decraft destination.");return;}
            returnToHost(player,world,args[0].equals("home"));return;
        }
        if(dimension(world)!=0 && args.length==2 && args[0].equals("gate")) {
            if(WorldHost.index(dimension(world))<0){chat(player,"Visit gates from the Minecraft hub.");return;}
            returnToHost(player,world,false);world=field(player,"field_70170_p");
        }
        if (dimension(world) != 0) { chat(player, "Create the gate hub from the original overworld."); return; }
        if (args.length == 1 && args[0].equals("gates")) { build(player, world); return; }
        if (args.length == 2 && args[0].equals("gate")) {
            int gate = Arrays.asList(IDS).indexOf(args[1]);
            Properties state = read(world);
            if (gate < 0 || !state.containsKey("anchor")) { chat(player, "Use /decraft gates first. Destinations: " + String.join(", ", IDS)); return; }
            remember(state, player, world); write(world, state);
            int[] anchor = anchor(state);
            cooldown.put(player, 0);
            invoke(player, "func_70634_a", anchor[0] + gate*6 + 2.0, anchor[1] + 1.0, anchor[2] - .2);
            return;
        }
        chat(player, "/decraft gate <game> visits a gate; returngate visits a destination return frame; hub or home returns to Minecraft.");
    }

    private static int[] anchor(Properties state) {
        String[] words = state.getProperty("anchor").split(",");
        if (words.length != 3) throw new IllegalArgumentException("Invalid gate anchor");
        return new int[]{Integer.parseInt(words[0]), Integer.parseInt(words[1]), Integer.parseInt(words[2])};
    }
    private static Object block(String name) throws Exception {
        Class<?> type = Class.forName("net.minecraft.block.Block");
        return type.getMethod("func_149684_b", String.class).invoke(null, "minecraft:" + name);
    }
    private static void place(Object world, int x, int y, int z, Object block, int meta) throws Exception {
        if (!((Boolean)invoke(world, "func_147465_d", x, y, z, block, meta, 3))) throw new IllegalStateException("Original host rejected a gate block");
    }
    private void build(Object player, Object world) throws Exception {
        Properties state = read(world);
        if (state.containsKey("anchor")) { chat(player, "The six saved gates already exist. Use /decraft gate <game>."); return; }
        int x = (int)Math.floor(coordinate(player, "field_70165_t")) - 17;
        int z = (int)Math.floor(coordinate(player, "field_70161_v")) + 5;
        int bottom = (int)Math.floor(coordinate(player, "field_70163_u")) + 6;
        int y = -1;
        for (int candidate=bottom; candidate<=Math.min(bottom+20, 245); candidate++) {
            boolean clear = true;
            outer: for (int dx=0;dx<36;dx++) for (int dz=-5;dz<=3;dz++) for (int dy=0;dy<=5;dy++) {
                if (!((Boolean)invoke(world, "func_147437_c", x+dx, candidate+dy, z+dz))) { clear=false; break outer; }
            }
            if (clear) { y=candidate; break; }
        }
        if (y < 0) { chat(player, "No empty space above this location. Existing terrain was preserved."); return; }
        Object stone=block("stone"), obsidian=block("obsidian"), glass=block("stained_glass"), sign=block("standing_sign"), air=block("air");
        List<int[]> placed = new ArrayList<int[]>();
        try {
            for (int dx=0;dx<36;dx++) for (int dz=-5;dz<=3;dz++) {
                place(world,x+dx,y,z+dz,stone,0); placed.add(new int[]{x+dx,y,z+dz});
            }
            for (int gate=0;gate<IDS.length;gate++) {
                int left=x+gate*6;
                for (int dx=0;dx<4;dx++) for (int dy=1;dy<=4;dy++) {
                    if (dx==0 || dx==3 || dy==4) {
                        place(world,left+dx,y+dy,z,obsidian,0); placed.add(new int[]{left+dx,y+dy,z});
                    } else {
                        place(world,left+dx,y+dy,z+1,glass,COLORS[gate]); placed.add(new int[]{left+dx,y+dy,z+1});
                    }
                }
                place(world,left+1,y+1,z-2,sign,8); placed.add(new int[]{left+1,y+1,z-2});
                Object tile=invoke(world,"func_147438_o",left+1,y+1,z-2);
                String[] lines=(String[])field(tile,"field_145915_a");
                lines[0]="DECRAFT GATE";lines[1]=LABELS[gate];
                lines[2]=gate==0?"Saved home":"Saved dimension";lines[3]=gate==0?"Enter to return":"Enter to explore";
                invoke(tile,"func_70296_d");invoke(world,"func_147471_g",left+1,y+1,z-2);
            }
            remember(state,player,world);state.setProperty("anchor",x+","+y+","+z);state.setProperty("routes",String.join(",",IDS));write(world,state);
        } catch (Exception error) {
            for (int[] p:placed) invoke(world,"func_147465_d",p[0],p[1],p[2],air,0,3);
            throw error;
        }
        cooldown.put(player,100);
        invoke(player,"func_70634_a",x+20.0,y+1.0,z-4.0);
        chat(player,"Six physical gates created. Destination worlds are open; original campaigns are still incomplete.");
        log.info("Created six physical gates at " + x + "," + y + "," + z + "; existing blocks preserved.");
    }

    void tick() {
        try {
            Runnable reply; while ((reply=replies.poll()) != null) reply.run();
            if (++ticks % 5 != 0) return;
            Object manager=invoke(server(),"func_71203_ab");
            List<?> players=(List<?>)field(manager,"field_72404_b");
            for (Object player:players) {
                int wait=cooldown.containsKey(player)?cooldown.get(player):0;
                if (wait>0) { cooldown.put(player,wait-5);continue; }
                Object world=field(player,"field_70170_p"); int worldIndex=WorldHost.index(dimension(world));
                if(worldIndex>0) {
                    int[] a=WorldHost.layout(worldIndex).gate;
                    double px=coordinate(player,"field_70165_t"),py=coordinate(player,"field_70163_u"),pz=coordinate(player,"field_70161_v");
                    if(py>=a[1]+.9 && py<=a[1]+4 && Math.abs(pz-a[2])<=.75 && px>a[0]+.8 && px<a[0]+3.2) {
                        cooldown.put(player,200);returnToHost(player,world,false);
                    }
                    continue;
                }
                if(worldIndex!=0)continue;
                Properties state=read(world);
                if (!state.containsKey("anchor")) {
                    // Only the local single-player host receives an automatic
                    // hub. Never replace terrain or recreate a saved hub.
                    if(!automaticHubAttempted.containsKey(world) &&
                            !stateFile(world).getParent().getFileName().toString().equals("mystcraft_profiling") &&
                            (Boolean)invoke(server(),"func_71264_H") &&
                            (Boolean)invoke(player,"func_70089_S")) {
                        automaticHubAttempted.put(world,true);build(player,world);
                    }
                    continue;
                }
                if(!"1".equals(state.getProperty("destination.worlds.version"))) {
                    int[] a=anchor(state);
                    for(int gate=1;gate<IDS.length;gate++) {
                        Object tile=invoke(world,"func_147438_o",a[0]+gate*6+1,a[1]+1,a[2]-2);
                        if(tile!=null) {String[] lines=(String[])field(tile,"field_145915_a");lines[2]="Saved dimension";lines[3]="Enter to explore";
                            invoke(tile,"func_70296_d");invoke(world,"func_147471_g",a[0]+gate*6+1,a[1]+1,a[2]-2);}
                    }
                    state.setProperty("destination.worlds.version","1");write(world,state);
                }
                int[] a=anchor(state);
                double px=coordinate(player,"field_70165_t"),py=coordinate(player,"field_70163_u"),pz=coordinate(player,"field_70161_v");
                if (py<a[1]+.9 || py>a[1]+4 || Math.abs(pz-a[2])>.75) continue;
                for (int gate=0;gate<IDS.length;gate++) if (px>a[0]+gate*6+.8 && px<a[0]+gate*6+3.2) {
                    double[] saved=home(state,player);cooldown.put(player,200);request(player,world,gate,saved);break;
                }
            }
        } catch (Exception error) { if (ticks%200==0) log.warning("Portal host check: " + error.toString()); }
    }
    private void request(Object player,Object world,int gate,double[] saved) {
        sender.execute(() -> {
            boolean available=saved!=null && saved[0]==0;String message="Destination request rejected; player state preserved.";boolean back=false;
            HttpURLConnection connection=null;
            try {
                connection=(HttpURLConnection)endpoint.toURL().openConnection();connection.setRequestMethod("POST");
                connection.setConnectTimeout(500);connection.setReadTimeout(500);connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type","application/json");
                byte[] raw=("{\"destination\":\""+IDS[gate]+"\",\"host_home_available\":"+available+",\"host_worlds_ready\":"+(gate>0 && WorldHost.layout(gate)!=null)+"}").getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(raw.length);
                try (OutputStream output=connection.getOutputStream()) { output.write(raw); }
                back=available && connection.getResponseCode()==200;
                if (back) message=gate==0?"Returned to your saved Minecraft home; inventory and progress preserved.":"Entered a saved destination world. Full original campaign gameplay remains incomplete. Walk into its return gate or use /decraft hub.";
                else if (connection.getResponseCode()!=409) message="Portal request rejected; player state preserved.";
            } catch (Exception error) { message="Shared runtime unavailable; travel cancelled and player state preserved."; }
            finally { if(connection!=null)connection.disconnect(); }
            final boolean returning=back;final String text=message;
            replies.add(() -> {
                try {
                    if (field(player,"field_70170_p")!=world) { chat(player,"Portal request cancelled after world change.");return; }
                    Properties current=read(world);int[] a=anchor(current);
                    double px=coordinate(player,"field_70165_t"),pz=coordinate(player,"field_70161_v");
                    if (!(px>a[0]+gate*6+.8 && px<a[0]+gate*6+3.2 && Math.abs(pz-a[2])<=.75)) { chat(player,"Portal request cancelled after leaving the gate.");return; }
                    if(returning) {
                        if(gate==0)WorldHost.transfer(player,0,new double[]{saved[1],saved[2],saved[3]});
                        else enterWorld(player,world,gate);
                    }
                    chat(player,LABELS[gate]+": "+text);log.info("Gate "+IDS[gate]+": "+(returning?(gate==0?"saved home restored":"destination entered "+WorldHost.DIMENSIONS[gate]):"blocked; state preserved"));
                } catch(Exception error) { log.log(java.util.logging.Level.WARNING,"Portal response failed",error); }
            });
        });
    }
    private void enterWorld(Object player,Object original,int gate) throws Exception {
        Object world=WorldHost.world(WorldHost.DIMENSIONS[gate]);WorldLayout plan=WorldHost.layout(gate);
        Properties state=read(original);
        if(!"1".equals(state.getProperty("world."+IDS[gate]+".return-gate"))) {
            int[] a=plan.gate;Object obsidian=block("obsidian"),glass=block("stained_glass"),sign=block("standing_sign");
            // Only initialize the reserved gate cells once, before this world is
            // first accessible. On later visits, saved blocks are never rebuilt.
            for(int x=0;x<4;x++)for(int y=1;y<=4;y++) {
                if(x==0||x==3||y==4)place(world,a[0]+x,a[1]+y,a[2],obsidian,0);
                else place(world,a[0]+x,a[1]+y,a[2]+1,glass,5);
            }
            place(world,a[0]+1,a[1]+1,a[2]-2,sign,8);
            Object tile=invoke(world,"func_147438_o",a[0]+1,a[1]+1,a[2]-2);String[] lines=(String[])field(tile,"field_145915_a");
            lines[0]="MINECRAFT HUB";lines[1]="Return gate";lines[2]="Enter to return";lines[3]="/decraft hub";
            invoke(tile,"func_70296_d");invoke(world,"func_147471_g",a[0]+1,a[1]+1,a[2]-2);
            state.setProperty("world."+IDS[gate]+".return-gate","1");write(original,state);
        }
        double[] position=plan.spawn;
        String checkpoint=state.getProperty("checkpoint."+identity(player)+"."+IDS[gate]);
        if(checkpoint!=null) {
            String[] values=checkpoint.split(",");if(values.length!=3)throw new IllegalArgumentException("Invalid world checkpoint");
            double[] candidate={Double.parseDouble(values[0]),Double.parseDouble(values[1]),Double.parseDouble(values[2])};
            if(!Double.isFinite(candidate[0])||!Double.isFinite(candidate[1])||!Double.isFinite(candidate[2]))throw new IllegalArgumentException("Invalid checkpoint coordinates");
            // A player can build over a checkpoint. Fall back to the reserved
            // arrival position instead of tunneling through saved construction.
            boolean clear=true;for(int dy=0;dy<2;dy++)clear&=(Boolean)invoke(world,"func_147437_c",(int)Math.floor(candidate[0]),(int)Math.floor(candidate[1])+dy,(int)Math.floor(candidate[2]));
            if(clear)position=candidate;
        }
        WorldHost.transfer(player,WorldHost.DIMENSIONS[gate],position);cooldown.put(player,100);
        state.setProperty("visited."+identity(player)+"."+IDS[gate],"true");write(original,state);
    }
    private void returnToHost(Object player,Object world,boolean originalHome) throws Exception {
        Object overworld=WorldHost.world(0);Properties state=read(overworld);double[] position;
        if(originalHome) {double[] p=home(state,player);if(p==null||p[0]!=0)throw new IllegalStateException("No saved Minecraft home");position=new double[]{p[1],p[2],p[3]};}
        else {int[] a=anchor(state);position=new double[]{a[0]+17.5,a[1]+1.,a[2]-4.};}
        int index=WorldHost.index(dimension(world));
        if(index>0) {
            double x=coordinate(player,"field_70165_t"),y=coordinate(player,"field_70163_u"),z=coordinate(player,"field_70161_v");
            int[] a=WorldHost.layout(index).gate;
            boolean inside=x>a[0]+.8 && x<a[0]+3.2 && Math.abs(z-a[2])<=.75;
            // Returning inside a gate must not create a reentry checkpoint loop.
            double[] p=inside?WorldHost.layout(index).spawn:new double[]{x,y,z};
            state.setProperty("checkpoint."+identity(player)+"."+IDS[index],p[0]+","+p[1]+","+p[2]);write(overworld,state);
        }
        WorldHost.transfer(player,0,position);cooldown.put(player,100);
        chat(player,"Returned to Minecraft; destination chunks, inventory and checkpoints preserved.");
        log.info("Return from "+(index>0?IDS[index]:"minecraft")+": saved overworld restored");
    }
}
