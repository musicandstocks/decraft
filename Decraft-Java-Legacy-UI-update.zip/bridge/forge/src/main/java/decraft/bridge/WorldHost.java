package decraft.bridge;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

/** Persistent imported/adapted worlds inside the unmodified original Forge host. */
public final class WorldHost implements Opcodes {
    public static final int[] DIMENSIONS={0,26001,26002,26003,26004,26005};
    private static final Map<Integer,WorldLayout> layouts=new HashMap<Integer,WorldLayout>();
    private static final Map<String,Object> blocks=new HashMap<String,Object>();
    private static final ThreadLocal<double[]> target=new ThreadLocal<double[]>();
    private static Class<?> teleporter;
    private static final Logger log=Logger.getLogger("decraft.worlds");
    private static final class Loader extends ClassLoader {
        Loader(ClassLoader parent) {super(parent);}
        Class<?> define(String name,byte[] raw) {return defineClass(name,raw,0,raw.length);}
    }
    private static Method method(Class<?> type,String name) throws Exception {
        for(Class<?> c=type;c!=null;c=c.getSuperclass()) for(Method m:c.getDeclaredMethods())
            if(m.getName().equals(name)) {m.setAccessible(true);return m;}
        throw new NoSuchMethodException(type.getName()+"."+name);
    }
    static Object call(Object object,String name,Object... args) throws Exception {
        Class<?> type=object instanceof Class?(Class<?>)object:object.getClass();
        outer:for(Method m:type.getMethods()) {
            if(!m.getName().equals(name) || m.getParameterTypes().length!=args.length)continue;
            Class<?>[] parameters=m.getParameterTypes();
            for(int i=0;i<args.length;i++) {
                Class<?> p=parameters[i];
                if(p.isPrimitive()) p=p==int.class?Integer.class:p==long.class?Long.class:p==boolean.class?Boolean.class:
                    p==float.class?Float.class:p==double.class?Double.class:p==byte.class?Byte.class:p==short.class?Short.class:Character.class;
                if(args[i]!=null && !p.isInstance(args[i])) continue outer;
            }
            m.setAccessible(true);
            try {return m.invoke(object instanceof Class?null:object,args);}
            catch(java.lang.reflect.InvocationTargetException error) {
                Throwable cause=error.getCause();if(cause instanceof Exception)throw (Exception)cause;
                if(cause instanceof Error)throw (Error)cause;throw error;
            }
        }
        throw new NoSuchMethodException(type.getName()+"."+name);
    }
    static Object get(Object object,String name) throws Exception {Field f=object.getClass().getField(name);f.setAccessible(true);return f.get(object);}
    static void set(Object object,String name,Object value) throws Exception {Field f=object.getClass().getField(name);f.setAccessible(true);f.set(object,value);}
    public static int index(int dimension) {for(int i=0;i<DIMENSIONS.length;i++)if(DIMENSIONS[i]==dimension)return i;return -1;}
    public static WorldLayout layout(int index) {return layouts.get(DIMENSIONS[index]);}
    public static void register() throws Exception {
        if(!layouts.isEmpty())return;
        Class<?> provider=Class.forName("net.minecraft.world.WorldProvider");
        Class<?> manager=Class.forName("net.minecraftforge.common.DimensionManager");
        Loader loader=new Loader(WorldHost.class.getClassLoader());
        // Construct actual subclasses of the loaded original ABI. No substitute
        // Minecraft definitions, remapped binaries, or copied host classes.
        for(int i=1;i<PortalHost.IDS.length;i++) {
            int id=DIMENSIONS[i];
            if((Boolean)call(manager,"isDimensionRegistered",id)) throw new IllegalStateException("Destination dimension collision: "+id);
            WorldLayout plan=new WorldLayout(WorldHost.class.getResourceAsStream("/decraft/worlds/"+PortalHost.IDS[i]+".dwld"));
            String name="decraft.bridge.generated.World_"+PortalHost.IDS[i];
            ClassWriter cw=new ClassWriter(ClassWriter.COMPUTE_MAXS);
            cw.visit(V1_8,ACC_PUBLIC,name.replace('.','/'),null,Type.getInternalName(provider),null);
            MethodVisitor ctor=cw.visitMethod(ACC_PUBLIC,"<init>","()V",null,null);ctor.visitCode();
            ctor.visitVarInsn(ALOAD,0);ctor.visitMethodInsn(INVOKESPECIAL,Type.getInternalName(provider),"<init>","()V",false);
            ctor.visitInsn(RETURN);ctor.visitMaxs(0,0);ctor.visitEnd();
            Method nameMethod=method(provider,"func_80007_l");
            MethodVisitor mv=cw.visitMethod(ACC_PUBLIC,nameMethod.getName(),Type.getMethodDescriptor(nameMethod),null,null);
            mv.visitCode();mv.visitLdcInsn(PortalHost.LABELS[i]);mv.visitInsn(ARETURN);mv.visitMaxs(0,0);mv.visitEnd();
            delegate(cw,method(provider,"func_76556_a"),"configureProvider",void.class);
            delegate(cw,method(provider,"func_76555_c"),"chunkProvider",Object.class);
            delegate(cw,method(provider,"func_76554_h"),"spawnCoordinates",Object.class);
            for(String bool:new String[]{"func_76567_e","func_76569_d"}) {
                Method m=method(provider,bool);mv=cw.visitMethod(ACC_PUBLIC,m.getName(),Type.getMethodDescriptor(m),null,null);
                mv.visitCode();mv.visitInsn(bool.equals("func_76569_d")?ICONST_1:ICONST_0);mv.visitInsn(IRETURN);mv.visitMaxs(0,0);mv.visitEnd();
            }
            cw.visitEnd();Class<?> generated=loader.define(name,cw.toByteArray());
            if(!((Boolean)call(manager,"registerProviderType",id,generated,false)))throw new IllegalStateException("Provider ID collision: "+id);
            call(manager,"registerDimension",id,id);layouts.put(id,plan);
            log.info("Registered "+PortalHost.IDS[i]+" destination dimension "+id+"; "+plan.scope);
        }
        Class<?> original=Class.forName("net.minecraft.world.Teleporter");
        String name="decraft.bridge.generated.ExactTeleporter";
        ClassWriter cw=new ClassWriter(ClassWriter.COMPUTE_MAXS);
        cw.visit(V1_8,ACC_PUBLIC,name.replace('.','/'),null,Type.getInternalName(original),null);
        Constructor<?> constructor=original.getConstructors()[0];String desc=Type.getConstructorDescriptor(constructor);
        MethodVisitor mv=cw.visitMethod(ACC_PUBLIC,"<init>",desc,null,null);mv.visitCode();mv.visitVarInsn(ALOAD,0);mv.visitVarInsn(ALOAD,1);
        mv.visitMethodInsn(INVOKESPECIAL,Type.getInternalName(original),"<init>",desc,false);mv.visitInsn(RETURN);mv.visitMaxs(0,0);mv.visitEnd();
        Method place=method(original,"func_77185_a");mv=cw.visitMethod(ACC_PUBLIC,place.getName(),Type.getMethodDescriptor(place),null,null);
        mv.visitCode();mv.visitVarInsn(ALOAD,1);mv.visitMethodInsn(INVOKESTATIC,Type.getInternalName(WorldHost.class),"placeEntity","(Ljava/lang/Object;)V",false);
        mv.visitInsn(RETURN);mv.visitMaxs(0,0);mv.visitEnd();cw.visitEnd();teleporter=loader.define(name,cw.toByteArray());
    }
    private static void delegate(ClassWriter cw,Method original,String helper,Class<?> returned) {
        MethodVisitor mv=cw.visitMethod(ACC_PUBLIC,original.getName(),Type.getMethodDescriptor(original),null,null);mv.visitCode();mv.visitVarInsn(ALOAD,0);
        mv.visitMethodInsn(INVOKESTATIC,Type.getInternalName(WorldHost.class),helper,"(Ljava/lang/Object;)"+Type.getDescriptor(returned),false);
        if(returned==void.class)mv.visitInsn(RETURN);
        else {mv.visitTypeInsn(CHECKCAST,Type.getInternalName(original.getReturnType()));mv.visitInsn(ARETURN);}
        mv.visitMaxs(0,0);mv.visitEnd();
    }
    public static void configureProvider(Object provider) throws Exception {
        Class<?> biome=Class.forName("net.minecraft.world.biome.BiomeGenBase");
        Object plains=biome.getField("field_76772_c").get(null);
        Object chunkManager=Class.forName("net.minecraft.world.biome.WorldChunkManagerHell").getConstructor(biome,float.class).newInstance(plains,.5f);
        set(provider,"field_76578_c",chunkManager);set(provider,"field_76575_d",false);set(provider,"field_76576_e",false);
    }
    public static Object spawnCoordinates(Object provider) throws Exception {
        WorldLayout plan=layouts.get(((Number)get(provider,"field_76574_g")).intValue());
        return Class.forName("net.minecraft.util.ChunkCoordinates").getConstructor(int.class,int.class,int.class)
            .newInstance((int)Math.floor(plan.spawn[0]),(int)plan.spawn[1],(int)Math.floor(plan.spawn[2]));
    }
    private static Object block(String id) throws Exception {
        Object b=blocks.get(id);if(b==null){b=call(Class.forName("net.minecraft.block.Block"),"func_149684_b","minecraft:"+id);if(b==null)throw new IllegalArgumentException(id);blocks.put(id,b);}return b;
    }
    public static Object chunkProvider(Object provider) throws Exception {
        final Object world=get(provider,"field_76579_a");final WorldLayout plan=layouts.get(((Number)get(provider,"field_76574_g")).intValue());
        if(plan==null)throw new IllegalStateException("Unknown imported dimension");
        Class<?> abi=Class.forName("net.minecraft.world.chunk.IChunkProvider");
        return Proxy.newProxyInstance(abi.getClassLoader(),new Class<?>[]{abi},(proxy,m,args)->{
            String n=m.getName();
            if(n.equals("func_73154_d")||n.equals("func_73158_c"))return chunk(world,plan,(Integer)args[0],(Integer)args[1]);
            if(n.equals("func_73149_a")||n.equals("func_73151_a")||n.equals("func_73157_c"))return true;
            if(n.equals("func_73156_b"))return false;
            if(n.equals("func_73148_d")||n.equals("toString"))return "Decraft imported world";
            if(n.equals("func_73155_a"))return Collections.emptyList();
            if(n.equals("func_147416_a"))return null;
            if(n.equals("func_73152_e"))return 0;
            if(n.equals("hashCode"))return System.identityHashCode(proxy);
            if(n.equals("equals"))return proxy==args[0];
            if(m.getReturnType()==void.class)return null;
            throw new UnsupportedOperationException("Original chunk ABI: "+n);
        });
    }
    private static Object chunk(Object world,WorldLayout plan,int cx,int cz) throws Exception {
        Class<?> type=Class.forName("net.minecraft.block.Block");Object ids=Array.newInstance(type,32768);byte[] metadata=new byte[32768];
        Arrays.fill((Object[])ids,block("air"));
        for(WorldLayout.Box b:plan.chunk(cx,cz)) {
            Object id=block(b.block);
            for(int x=Math.max(b.x0,cx*16);x<=Math.min(b.x1,cx*16+15);x++)
                for(int z=Math.max(b.z0,cz*16);z<=Math.min(b.z1,cz*16+15);z++) for(int y=b.y0;y<=b.y1;y++) {
                    int offset=((x&15)*16+(z&15))*128+y;Array.set(ids,offset,id);metadata[offset]=(byte)b.meta;
                }
        }
        Class<?> chunk=Class.forName("net.minecraft.world.chunk.Chunk");
        Object result=chunk.getConstructor(Class.forName("net.minecraft.world.World"),ids.getClass(),byte[].class,int.class,int.class).newInstance(world,ids,metadata,cx,cz);
        Arrays.fill((byte[])call(result,"func_76605_m"),(byte)1);call(result,"func_76603_b");return result;
    }
    public static Object world(int dimension) throws Exception {
        Class<?> manager=Class.forName("net.minecraftforge.common.DimensionManager");Object world=call(manager,"getWorld",dimension);
        if(world==null){call(manager,"initDimension",dimension);world=call(manager,"getWorld",dimension);}
        if(world==null)throw new IllegalStateException("Destination world did not initialize");return world;
    }
    public static void placeEntity(Object entity) throws Exception {
        double[] p=target.get();if(p==null)throw new IllegalStateException("Missing exact travel position");
        call(entity,"func_70012_b",p[0],p[1],p[2],((Number)get(entity,"field_70177_z")).floatValue(),((Number)get(entity,"field_70125_A")).floatValue());
        set(entity,"field_70143_R",0f);
    }
    public static void transfer(Object player,int dimension,double[] position) throws Exception {
        if(!(Boolean)call(player,"func_70089_S"))throw new IllegalStateException("Cannot travel while dead");
        if(get(player,"field_70154_o")!=null)throw new IllegalStateException("Dismount before portal travel");
        Object world=world(dimension);
        // Destination chunk and collision checked before changing player world.
        call(world,"func_72964_e",((int)Math.floor(position[0]))>>4,((int)Math.floor(position[2]))>>4);
        for(int dy=0;dy<2;dy++)if(!(Boolean)call(world,"func_147437_c",(int)Math.floor(position[0]),(int)Math.floor(position[1])+dy,(int)Math.floor(position[2])))
            throw new IllegalStateException("Saved destination obstructed; travel cancelled");
        if(((Number)get(player,"field_71093_bK")).intValue()!=dimension) {
            Object server=call(cpw.mods.fml.common.FMLCommonHandler.instance(),"getMinecraftServerInstance");
            Object manager=call(server,"func_71203_ab");Object tele=teleporter.getConstructors()[0].newInstance(world);
            target.set(position);try {call(manager,"transferPlayerToDimension",player,dimension,tele);}finally{target.remove();}
        }
        call(player,"func_70634_a",position[0],position[1],position[2]);set(player,"field_70143_R",0f);
        log.info("Travel committed: "+dimension+" at "+Arrays.toString(position));
    }
}
