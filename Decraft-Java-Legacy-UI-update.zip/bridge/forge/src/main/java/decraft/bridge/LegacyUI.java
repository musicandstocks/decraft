package decraft.bridge;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.eventhandler.EventPriority;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/** Legacy presentation over the original Java screens and their real actions. */
public final class LegacyUI {
    private static final Map<String,Method> methods=new HashMap<String,Method>();
    private static final Map<String,Field> fields=new HashMap<String,Field>();
    private boolean up,down,accept;
    private boolean warned;
    private Object lastGui;
    private int lastWidth,lastHeight;
    private final ClientControls controls;
    private boolean previousClick;
    public LegacyUI(ClientControls controls){this.controls=controls;}
    private final Logger log=Logger.getLogger("decraft.legacyui");
    private static boolean enabled(){return !"false".equals(System.getProperty("decraft.legacyUI","true"));}
    private static Object mc() throws Exception {return call(Class.forName("net.minecraft.client.Minecraft"),"func_71410_x");}
    private static Object field(Object o,String name) throws Exception {
        String key=o.getClass().getName()+"."+name;Field f=fields.get(key);
        if(f==null)for(Class<?> c=o.getClass();c!=null;c=c.getSuperclass())try {
            f=c.getDeclaredField(name);f.setAccessible(true);fields.put(key,f);break;
        }catch(NoSuchFieldException ignored){}
        if(f==null)throw new NoSuchFieldException(key);return f.get(o);
    }
    private static void set(Object o,String name,Object value) throws Exception {
        field(o,name);fields.get(o.getClass().getName()+"."+name).set(o,value);
    }
    private static Object call(Object o,String name,Object... args) throws Exception {
        Class<?> type=o instanceof Class?(Class<?>)o:o.getClass();String key=type.getName()+"."+name+"/"+args.length;
        Method m=methods.get(key);
        if(m==null)for(Class<?> c=type;c!=null && m==null;c=c.getSuperclass())for(Method candidate:c.getDeclaredMethods())
            if(candidate.getName().equals(name)&&candidate.getParameterTypes().length==args.length){m=candidate;m.setAccessible(true);methods.put(key,m);break;}
        if(m==null)throw new NoSuchMethodException(key);return m.invoke(o instanceof Class?null:o,args);
    }
    private static int number(Object o,String name) throws Exception{return ((Number)field(o,name)).intValue();}
    private static boolean is(Object o,String name) throws Exception{return Class.forName("net.minecraft.client.gui."+name).isInstance(o);}
    private static boolean main(Object gui) throws Exception {
        String n=gui.getClass().getSimpleName();
        return is(gui,"GuiMainMenu")||n.equals("GSGuiMainMenu")||n.equals("GuiMainMenuOld")||n.equals("GuiMainMenuNBT")||n.equals("GuiMainMenuVanilla")||n.equals("GuiMainMenuVoxelBox");
    }
    @SuppressWarnings("unchecked")
    private static List<Object> buttons(Object gui) throws Exception{return (List<Object>)field(gui,"field_146292_n");}
    private static void rect(int x,int y,int w,int h,int color) throws Exception {
        if(w>0&&h>0)call(Class.forName("net.minecraft.client.gui.Gui"),"func_73734_a",x,y,x+w,y+h,color);
    }
    private static Object font() throws Exception{return field(mc(),"field_71466_p");}
    private static int textWidth(String text) throws Exception{return ((Number)call(font(),"func_78256_a",text)).intValue();}
    private static void text(String label,int x,int y,int color) throws Exception{call(font(),"func_78261_a",label,x,y,color);}
    private static void badge(String letter,String label,int x,int y,int color) throws Exception {
        rect(x,y,9,9,0xFF101010);rect(x+1,y+1,7,7,color);text(letter,x+2,y+1,0xFFFFFFFF);text(label,x+13,y+1,0xFFFFFFFF);
    }
    private void warning(Exception e){if(!warned){log.warning("Legacy UI: "+e);warned=true;}}

    @SubscribeEvent(priority=EventPriority.LOWEST)
    public void layout(GuiScreenEvent.InitGuiEvent.Post event) {
        if(!enabled())return;
        try {
            Object gui=field(event,"gui");int width=number(gui,"field_146294_l"),height=number(gui,"field_146295_m");
            if(main(gui)) {
                int[] order={1,2,14,0,6,4};String[] names={"Play Game","Join Game","Minecraft Realms","Help & Options","Mods","Quit Game"};
                List<Object> list=buttons(gui);int count=0;
                for(int id:order)for(Object b:list)if(number(b,"field_146127_k")==id)++count;
                int h=height<230?18:20,gap=4,start=Math.max(85,height/2-18),w=Math.min(220,width-40);
                if(start+count*(h+gap)>height-19)start=height-19-count*(h+gap);
                int row=0;
                for(int i=0;i<order.length;i++)for(Object b:list)if(number(b,"field_146127_k")==order[i]) {
                    set(b,"field_146128_h",width/2-w/2);set(b,"field_146129_i",start+row++*(h+gap));
                    set(b,"field_146120_f",w);set(b,"field_146121_g",h);set(b,"field_146126_j",names[i]);
                }
                for(Object b:list)if(number(b,"field_146127_k")==5){set(b,"field_146128_h",6);set(b,"field_146129_i",height-38);}
            } else if(is(gui,"GuiIngameMenu")) {
                int[] order={4,26006,0,5,6,7,1};int row=0,w=Math.min(220,width-40),start=Math.max(55,height/2-65);
                for(int id:order)for(Object b:buttons(gui))if(number(b,"field_146127_k")==id) {
                    set(b,"field_146128_h",width/2-w/2);set(b,"field_146129_i",start+row++*22);
                    set(b,"field_146120_f",w);set(b,"field_146121_g",20);
                    if(id==26006)set(b,"field_146126_j","Portal Hub");
                }
            }
            log.fine("Styled "+gui.getClass().getSimpleName());
        }catch(Exception e){warning(e);}
    }

    @SubscribeEvent(priority=EventPriority.LOWEST)
    public void draw(GuiScreenEvent.DrawScreenEvent.Post event) {
        if(!enabled())return;
        try {
            Object gui=field(event,"gui");int width=number(gui,"field_146294_l"),height=number(gui,"field_146295_m");
            for(Object b:buttons(gui)) {
                // Preserve textured controls supplied by other mods and icon buttons.
                String type=b.getClass().getSimpleName();
                if((!b.getClass().getName().equals("net.minecraft.client.gui.GuiButton")&&!type.equals("GuiOptionButton")&&!main(gui)&&!is(gui,"GuiIngameMenu"))||!((Boolean)field(b,"field_146125_m")))continue;
                if(type.contains("Slider"))continue;
                int x=number(b,"field_146128_h"),y=number(b,"field_146129_i"),w=number(b,"field_146120_f"),h=number(b,"field_146121_g");
                if(w<35||h<12)continue;
                boolean active=(Boolean)field(b,"field_146124_l"),hover=event.mouseX>=x&&event.mouseX<x+w&&event.mouseY>=y&&event.mouseY<y+h;
                rect(x-1,y-1,w+2,h+2,0xFF161616);rect(x,y,w,h,active&&hover?0xFF9999C7:0xFFBDBDBD);
                rect(x+1,y+1,w-2,h-2,active&&hover?0xFF666699:0xFF7D7D7D);
                rect(x+2,y+2,w-4,(h-4)/2,active&&hover?0xFF7777AA:0xFF929292);
                String label=(String)field(b,"field_146126_j");text(label,x+(w-textWidth(label))/2,y+(h-8)/2,active?(hover?0xFFFFFF55:0xFFFFFFFF):0xFFA0A0A0);
            }
            boolean main=main(gui),pause=is(gui,"GuiIngameMenu");
            if(main){String label="DECRAFT  -  LEGACY UI";text(label,(width-textWidth(label))/2,69,0xFFFFFFFF);}
            if(main||pause){rect(0,height-17,width,17,0xAA000000);badge("A","Select",7,height-13,0xFF388238);if(pause)badge("B","Back",86,height-13,0xFFA13636);else text("D-pad: Navigate",86,height-12,0xFFFFFFFF);}
            if(Class.forName("net.minecraft.client.gui.inventory.GuiContainer").isInstance(gui)) {
                int left=number(gui,"field_147003_i"),top=number(gui,"field_147009_r"),w=number(gui,"field_146999_f"),h=number(gui,"field_147000_g");
                rect(left-2,top-2,w+4,2,0xFFDFDFDF);rect(left-2,top,2,h,0xFFDFDFDF);
                rect(left+w,top,2,h+2,0xFF202020);rect(left-2,top+h,w+4,2,0xFF202020);
                int y=Math.min(height-12,top+h+5);badge("A","Take / Place",Math.max(4,left),y,0xFF388238);
                badge("X","Quick Move",Math.max(4,left)+96,y,0xFF315AA7);
            }
        }catch(Exception e){warning(e);}
    }

    @SubscribeEvent
    public void hud(RenderGameOverlayEvent.Post event) {
        if(!enabled()||event.type!=RenderGameOverlayEvent.ElementType.ALL)return;
        try {
            Object resolution=field(event,"resolution");int w=((Number)call(resolution,"func_78326_a")).intValue(),h=((Number)call(resolution,"func_78328_b")).intValue();
            if(field(mc(),"field_71462_r")!=null)return;
            // Leave the original hotbar, health, hunger and mod HUD intact.
            badge("Y","Inventory",5,h-29,0xFFAC9622);badge("A","Jump",5,h-15,0xFF388238);
            String hub="View / F6: Hub";text(hub,w-textWidth(hub)-5,h-14,0xFFFFFFFF);
        }catch(Exception e){warning(e);}
    }

    @SubscribeEvent(priority=EventPriority.LOWEST)
    public void frame(TickEvent.RenderTickEvent event) {
        if(!enabled()||event.phase!=TickEvent.Phase.END)return;
        Class<?> gl;
        boolean pushed=false;
        try {
            Object client=mc(),gui=field(client,"field_71462_r");
            Class<?> mouse=Class.forName("org.lwjgl.input.Mouse");boolean clicked=(Boolean)call(mouse,"isButtonDown",0),press=clicked&&!previousClick;previousClick=clicked;
            if(gui==null){lastGui=null;return;}
            int width=number(gui,"field_146294_l"),height=number(gui,"field_146295_m");
            if(width<=0||height<=0)return;
            if(gui!=lastGui||width!=lastWidth||height!=lastHeight) {
                GuiScreenEvent.InitGuiEvent.Post init=(GuiScreenEvent.InitGuiEvent.Post)GuiScreenEvent.InitGuiEvent.Post.class.getConstructors()[0].newInstance(gui,buttons(gui));
                controls.menu(init);layout(init);
                lastGui=gui;lastWidth=width;lastHeight=height;
                log.info("Legacy presentation active on "+gui.getClass().getName());
            }
            gl=Class.forName("org.lwjgl.opengl.GL11");
            call(gl,"glPushAttrib",0x000FFFFF);call(gl,"glMatrixMode",5889);call(gl,"glPushMatrix");call(gl,"glMatrixMode",5888);call(gl,"glPushMatrix");pushed=true;
            call(field(client,"field_71460_t"),"func_78478_c");call(gl,"glDisable",3089);call(gl,"glDisable",2929);
            int dw=number(client,"field_71443_c"),dh=number(client,"field_71440_d");
            int x=((Number)call(mouse,"getX")).intValue()*width/dw,y=height-((Number)call(mouse,"getY")).intValue()*height/dh-1;
            if(press&&is(gui,"GuiIngameMenu"))for(Object b:buttons(gui))if(number(b,"field_146127_k")==26006&&x>=number(b,"field_146128_h")&&x<number(b,"field_146128_h")+number(b,"field_146120_f")&&y>=number(b,"field_146129_i")&&y<number(b,"field_146129_i")+number(b,"field_146121_g"))ClientControls.openHub();
            draw((GuiScreenEvent.DrawScreenEvent.Post)GuiScreenEvent.DrawScreenEvent.Post.class.getConstructors()[0].newInstance(gui,x,y,event.renderTickTime));
        }catch(Exception e){warning(e);}
        finally {
            if(pushed)try {
                gl=Class.forName("org.lwjgl.opengl.GL11");call(gl,"glMatrixMode",5888);call(gl,"glPopMatrix");call(gl,"glMatrixMode",5889);call(gl,"glPopMatrix");call(gl,"glPopAttrib");call(gl,"glMatrixMode",5888);
            }catch(Exception e){warning(e);}
        }
    }

    @SubscribeEvent
    public void navigation(TickEvent.ClientTickEvent event) {
        if(!enabled()||event.phase!=TickEvent.Phase.END)return;
        try {
            Class<?> keyboard=Class.forName("org.lwjgl.input.Keyboard");
            boolean u=(Boolean)call(keyboard,"isKeyDown",200),d=(Boolean)call(keyboard,"isKeyDown",208),a=(Boolean)call(keyboard,"isKeyDown",28);
            Object gui=field(mc(),"field_71462_r");
            if(gui!=null&&(main(gui)||is(gui,"GuiIngameMenu")||is(gui,"GuiOptions"))) {
                List<Object> list=new ArrayList<Object>();
                for(Object b:buttons(gui))if((Boolean)field(b,"field_146125_m")&&(Boolean)field(b,"field_146124_l")&&number(b,"field_146120_f")>=35)list.add(b);
                list.sort((x,y)->{try{return Integer.compare(number(x,"field_146129_i"),number(y,"field_146129_i"));}catch(Exception e){throw new IllegalStateException(e);}});
                if(!list.isEmpty()) {
                    int width=number(gui,"field_146294_l"),height=number(gui,"field_146295_m"),dw=number(mc(),"field_71443_c"),dh=number(mc(),"field_71440_d");
                    Class<?> mouse=Class.forName("org.lwjgl.input.Mouse");int mx=((Number)call(mouse,"getX")).intValue()*width/dw,my=height-((Number)call(mouse,"getY")).intValue()*height/dh-1,index=0;
                    for(int i=0;i<list.size();i++){Object b=list.get(i);if(mx>=number(b,"field_146128_h")&&mx<number(b,"field_146128_h")+number(b,"field_146120_f")&&my>=number(b,"field_146129_i")&&my<number(b,"field_146129_i")+number(b,"field_146121_g"))index=i;}
                    if((u&&!up)||(d&&!down)) {
                        index=(index+(u?-1:1)+list.size())%list.size();Object b=list.get(index);
                        call(mouse,"setCursorPosition",(number(b,"field_146128_h")+number(b,"field_146120_f")/2)*dw/width,dh-(number(b,"field_146129_i")+number(b,"field_146121_g")/2)*dh/height-1);
                    }
                    if(a&&!accept) {
                        Object button=list.get(index);GuiScreenEvent.ActionPerformedEvent.Pre pre=(GuiScreenEvent.ActionPerformedEvent.Pre)GuiScreenEvent.ActionPerformedEvent.Pre.class.getConstructors()[0].newInstance(gui,button,buttons(gui));
                        if(!net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(pre)) {
                            call(gui,"func_146284_a",field(pre,"button"));
                            net.minecraftforge.common.MinecraftForge.EVENT_BUS.post((GuiScreenEvent.ActionPerformedEvent.Post)GuiScreenEvent.ActionPerformedEvent.Post.class.getConstructors()[0].newInstance(gui,field(pre,"button"),buttons(gui)));
                        }
                    }
                }
            }
            up=u;down=d;accept=a;
        }catch(Exception e){warning(e);}
    }
}
