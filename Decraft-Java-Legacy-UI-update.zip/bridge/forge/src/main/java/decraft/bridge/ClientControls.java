package decraft.bridge;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.logging.Logger;

/** Original-client pause-menu access and controller menu/game context. */
public final class ClientControls {
    private static final int HUB_BUTTON=26006;
    private final Logger log=Logger.getLogger("decraft.controls");
    private boolean previousHubKey;
    private long lastStatus;
    private String lastContext;
    private boolean warned;
    private Object hubKey;

    private void keyBinding(Object mc) throws Exception {
        if(hubKey!=null)return;
        Class<?> type=Class.forName("net.minecraft.client.settings.KeyBinding");
        Object settings=field(mc,"field_71474_y");
        for(Object binding:(Object[])field(settings,"field_74324_K")) {
            String description=(String)WorldHost.call(binding,"func_151464_g");
            if(description.toLowerCase(java.util.Locale.ROOT).contains("stream")&&((Number)WorldHost.call(binding,"func_151463_i")).intValue()==64)
                WorldHost.call(binding,"func_151462_b",0);
        }
        hubKey=type.getConstructor(String.class,int.class,String.class).newInstance("key.decraft.hub",64,"key.categories.decraft");
        WorldHost.call(Class.forName("cpw.mods.fml.client.registry.ClientRegistry"),"registerKeyBinding",hubKey);
        WorldHost.call(type,"func_74508_b");
    }

    private static Object client() throws Exception {
        return WorldHost.call(Class.forName("net.minecraft.client.Minecraft"),"func_71410_x");
    }
    private static Object field(Object value,String name) throws Exception {return WorldHost.get(value,name);}
    static void openHub() throws Exception {
        Object mc=client(),player=field(mc,"field_71439_g");
        if(player==null)return;
        WorldHost.call(mc,"func_147108_a",new Object[]{null});
        WorldHost.call(player,"func_71165_d","/decraft hub");
    }
    private void warning(Exception error) {
        if(!warned){log.warning("Decraft client controls: "+error.toString());warned=true;}
    }

    @SubscribeEvent
    @SuppressWarnings("unchecked")
    public void menu(GuiScreenEvent.InitGuiEvent.Post event) {
        try {
            Object gui=field(event,"gui");
            if(!Class.forName("net.minecraft.client.gui.GuiIngameMenu").isInstance(gui))return;
            List<Object> buttons=(List<Object>)field(event,"buttonList");
            for(Object button:buttons)if(((Number)field(button,"field_146127_k")).intValue()==HUB_BUTTON)return;
            int width=((Number)field(gui,"field_146294_l")).intValue();
            int height=((Number)field(gui,"field_146295_m")).intValue();
            Object button=Class.forName("net.minecraft.client.gui.GuiButton")
                .getConstructor(int.class,int.class,int.class,int.class,int.class,String.class)
                .newInstance(HUB_BUTTON,width/2-100,height-24,200,20,"Portal Hub (View / F6)");
            buttons.add(button);
        } catch(Exception error){warning(error);}
    }

    @SubscribeEvent
    public void action(GuiScreenEvent.ActionPerformedEvent.Pre event) {
        try {
            if(((Number)field(field(event,"button"),"field_146127_k")).intValue()!=HUB_BUTTON)return;
            event.setCanceled(true);openHub();
        } catch(Exception error){warning(error);}
    }

    @SubscribeEvent
    public void tick(TickEvent.ClientTickEvent event) {
        if(event.phase!=TickEvent.Phase.END)return;
        try {
            Object mc=client(),player=field(mc,"field_71439_g"),gui=field(mc,"field_71462_r");
            keyBinding(mc);
            boolean key=(Boolean)WorldHost.call(Class.forName("org.lwjgl.input.Keyboard"),"isKeyDown",64);
            boolean queued=(Boolean)WorldHost.call(hubKey,"func_151468_f");
            if((queued||(key && !previousHubKey))&&player!=null)openHub();
            previousHubKey=key;
            String status=System.getProperty("decraft.controller.state","");
            long now=System.currentTimeMillis();
            if(!status.isEmpty() && now-lastStatus>=250) {
                String context=player!=null && gui==null?"game":"menu";
                lastStatus=now;
                if(context.equals(lastContext))return;
                Path target=Paths.get(status),temporary=target.resolveSibling(target.getFileName()+".pending");
                Files.write(temporary,context.getBytes(StandardCharsets.US_ASCII));
                try {Files.move(temporary,target,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);lastContext=context;}
                catch(java.nio.file.AccessDeniedException busy) { /* Retry the mode change next tick; keep the previous complete context. */ }
                finally {Files.deleteIfExists(temporary);}
            }
        } catch(Exception error){warning(error);}
    }
}
