package decraft.bridge;

import cpw.mods.fml.common.eventhandler.Event;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingSpawnEvent;

/** Host biome spawners must not inject unported monsters into destination imports. */
public final class DestinationRules {
    private static boolean destination(Object world) throws Exception {
        if(world==null)return false;
        return WorldHost.index(((Number)WorldHost.get(WorldHost.get(world,"field_73011_w"),"field_76574_g")).intValue())>0;
    }
    @SubscribeEvent
    public void checkSpawn(LivingSpawnEvent.CheckSpawn event) throws Exception {
        if(destination(WorldHost.get(event,"world")))event.setResult(Event.Result.DENY);
    }
    @SubscribeEvent
    public void entityJoin(EntityJoinWorldEvent event) throws Exception {
        if(destination(WorldHost.get(event,"world")) && Class.forName("net.minecraft.entity.EntityLiving").isInstance(WorldHost.get(event,"entity")))
            event.setCanceled(true);
        // Players, dropped items, projectiles and original inventories are not
        // mobs and remain handled by the original host. Future campaign actors
        // require an explicit owned adapter rather than host-biome injection.
    }
}
