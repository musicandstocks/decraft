package decraft.bridge;

import java.io.DataInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Immutable, bounded world import. Existing Anvil chunks always take priority. */
public final class WorldLayout {
    public final String scope;
    public final double[] spawn;
    public final int[] gate;
    public final List<Box> boxes = new ArrayList<Box>();
    private final Map<Long,List<Box>> chunks = new HashMap<Long,List<Box>>();
    public static final class Box {
        public final int x0,y0,z0,x1,y1,z1,meta;
        public final String block;
        Box(DataInputStream in) throws IOException {
            x0=in.readInt(); y0=in.readInt(); z0=in.readInt();
            x1=in.readInt(); y1=in.readInt(); z1=in.readInt();
            block=in.readUTF(); meta=in.readUnsignedByte();
            if (x0>x1 || y0>y1 || z0>z1 || y0<0 || y1>127 ||
                Math.abs((long)x0)>4096 || Math.abs((long)x1)>4096 ||
                Math.abs((long)z0)>4096 || Math.abs((long)z1)>4096 ||
                x1-x0>512 || z1-z0>512 || meta>15 || !block.matches("[a-z_]+"))
                throw new IOException("Invalid world import box");
        }
    }
    public WorldLayout(InputStream raw) throws IOException {
        if(raw==null) throw new IOException("Missing destination layout");
        try(DataInputStream in=new DataInputStream(raw)) {
            if(in.readInt()!=0x44575231) throw new IOException("Unknown world layout version");
            scope=in.readUTF(); spawn=new double[]{in.readDouble(),in.readDouble(),in.readDouble()};
            gate=new int[]{in.readInt(),in.readInt(),in.readInt()};
            if(!Double.isFinite(spawn[0]) || !Double.isFinite(spawn[1]) || !Double.isFinite(spawn[2]) ||
                spawn[1]<1 || spawn[1]>125 || Math.abs(spawn[0])>4096 || Math.abs(spawn[2])>4096 ||
                gate[1]<1 || gate[1]>121 || Math.abs((long)gate[0])>4096 || Math.abs((long)gate[2])>4096)
                throw new IOException("Invalid destination spawn");
            int count=in.readInt(); if(count<1 || count>1000000) throw new IOException("Invalid world import size");
            for(int i=0;i<count;i++) {
                Box b=new Box(in); boxes.add(b);
                for(int x=b.x0>>4;x<=b.x1>>4;x++) for(int z=b.z0>>4;z<=b.z1>>4;z++) {
                    long key=key(x,z); List<Box> list=chunks.get(key);
                    if(list==null) {list=new ArrayList<Box>();chunks.put(key,list);} list.add(b);
                }
            }
            if(in.read()!=-1) throw new IOException("Trailing world import data");
        }
    }
    private static long key(int x,int z) {return ((long)x<<32) ^ (z&0xffffffffL);}
    public List<Box> chunk(int x,int z) {
        List<Box> list=chunks.get(key(x,z)); return list==null?java.util.Collections.<Box>emptyList():list;
    }
}
